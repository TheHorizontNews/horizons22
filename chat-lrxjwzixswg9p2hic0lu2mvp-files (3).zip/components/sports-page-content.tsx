
"use client";

import { usePreloadedQuery } from "convex/react";
import { api } from "@/convex/_generated/api";
import { Preloaded } from "convex/react";
import Image from "next/image";
import Link from "next/link";

interface SportsPageContentProps {
  preloadedArticles: Preloaded<typeof api.articles.getRecentArticles>;
  preloadedCategories: Preloaded<typeof api.categories.getAllCategories>;
}

export default function SportsPageContent({ preloadedArticles, preloadedCategories }: SportsPageContentProps) {
  const allArticles = usePreloadedQuery(preloadedArticles);
  const categories = usePreloadedQuery(preloadedCategories);
  
  console.log('All articles:', allArticles.length);
  console.log('Categories:', categories);
  
  // Find the sports category
  const sportsCategory = categories.find(cat => cat.slug === 'sports'); // Changed back to 'sports'
  console.log('Sports category:', sportsCategory);
  
  // Filter sports articles by category ID - if no sports category found, use all articles as fallback
  const sportsArticles = sportsCategory 
    ? allArticles.filter(article => article.category === sportsCategory._id)
    : allArticles.slice(0, 15); // Use first 15 articles as fallback
  
  console.log('Sports articles:', sportsArticles.length);
  
  // Get featured articles for hero section (first 6)
  const heroArticles = sportsArticles.slice(0, 6);
  const mainFeatured = heroArticles[0];
  const sideArticles = heroArticles.slice(1, 6);

  // Get trending articles (next 4)
  const trendingArticles = sportsArticles.slice(6, 10);

  // Categorize articles by sport type
  const footballArticles = sportsArticles.filter(article => 
    article.title.toLowerCase().includes('football') || 
    article.title.toLowerCase().includes('soccer') ||
    article.title.toLowerCase().includes('transfer') ||
    article.title.toLowerCase().includes('premier league') ||
    article.title.toLowerCase().includes('tottenham') ||
    article.title.toLowerCase().includes('inter milan') ||
    article.title.toLowerCase().includes('pogba')
  ).slice(0, 4);

  const f1Articles = sportsArticles.filter(article => 
    article.title.toLowerCase().includes('f1') || 
    article.title.toLowerCase().includes('formula') ||
    article.title.toLowerCase().includes('hamilton') ||
    article.title.toLowerCase().includes('verstappen') ||
    article.title.toLowerCase().includes('leclerc') ||
    article.title.toLowerCase().includes('russell')
  ).slice(0, 4);

  const basketballArticles = sportsArticles.filter(article => 
    article.title.toLowerCase().includes('basketball') || 
    article.title.toLowerCase().includes('nba') ||
    article.title.toLowerCase().includes('playoffs') ||
    article.title.toLowerCase().includes('spurs') ||
    article.title.toLowerCase().includes('popovich')
  ).slice(0, 3);

  const tennisArticles = sportsArticles.filter(article => 
    article.title.toLowerCase().includes('tennis') || 
    article.title.toLowerCase().includes('wimbledon') ||
    article.title.toLowerCase().includes('raduc') ||
    article.title.toLowerCase().includes('draper')
  ).slice(0, 2);

  // Latest articles
  const latestArticles = sportsArticles.slice(0, 3);

  // Popular articles (mock data for now)
  const popularArticles = [
    { title: "Chido Obi makes Premier League history with first Manchester United start", time: "3 MONTHS AGO", views: "290" },
    { title: "Verstappen wary of McLaren's tyre edge despite Miami GP pole: \"We're all doing something wrong\"", time: "3 MONTHS AGO", views: "290" },
    { title: "Miami Gardens and Formula 1: Race day divides as Black residents weigh impact", time: "3 MONTHS AGO", views: "290" }
  ];

  const formatTimeAgo = (date: string | number) => {
    const now = new Date();
    const articleDate = new Date(date);
    const diffInMonths = Math.floor((now.getTime() - articleDate.getTime()) / (1000 * 60 * 60 * 24 * 30));
    
    if (diffInMonths >= 1) {
      return `${diffInMonths} MONTHS AGO`;
    }
    const diffInDays = Math.floor((now.getTime() - articleDate.getTime()) / (1000 * 60 * 60 * 24));
    return `${diffInDays} DAYS AGO`;
  };

  console.log('F1 articles found:', f1Articles.length);
  console.log('F1 articles:', f1Articles.map(a => a.title));

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section - More organic and stylish */}
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Enhanced Hero Grid with better mobile layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 mb-12">
          {/* Left Column - Mobile: full width, Desktop: 3 columns */}
          <div className="lg:col-span-3 space-y-4">
            {sideArticles.slice(0, 2).map((article, index) => (
              <Link key={article._id} href={`/article/${article.slug}`} className="block">
                <div className="relative h-48 lg:h-40 rounded-xl overflow-hidden group shadow-lg hover:shadow-xl transition-all duration-300">
                  <Image
                    src={index === 0 ? "https://images.pexels.com/photos/1884574/pexels-photo-1884574.jpeg?auto=compress&cs=tinysrgb&h=650&w=940" : "https://images.pexels.com/photos/31036780/pexels-photo-31036780.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"}
                    alt={article.title}
                    fill
                    className="object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent" />
                  <div className="absolute top-3 left-3">
                    <span className="bg-white/20 backdrop-blur-sm text-white text-xs font-medium px-2 py-1 rounded-full">
                      {formatTimeAgo(article.publicationDate)}
                    </span>
                  </div>
                  <div className="absolute bottom-3 left-3 right-3">
                    <h3 className="text-white font-bold text-sm lg:text-xs leading-tight line-clamp-3">
                      {article.title}
                    </h3>
                  </div>
                </div>
              </Link>
            ))}
            {/* Third article - hidden on mobile to save space */}
            {sideArticles[2] && (
              <Link href={`/article/${sideArticles[2].slug}`} className="hidden lg:block">
                <div className="relative h-40 rounded-xl overflow-hidden group shadow-lg hover:shadow-xl transition-all duration-300">
                  <Image
                    src="https://images.pexels.com/photos/13241582/pexels-photo-13241582.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
                    alt={sideArticles[2].title}
                    fill
                    className="object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent" />
                  <div className="absolute top-3 left-3">
                    <span className="bg-white/20 backdrop-blur-sm text-white text-xs font-medium px-2 py-1 rounded-full">
                      {formatTimeAgo(sideArticles[2].publicationDate)}
                    </span>
                  </div>
                  <div className="absolute bottom-3 left-3 right-3">
                    <h3 className="text-white font-bold text-xs leading-tight line-clamp-3">
                      {sideArticles[2].title}
                    </h3>
                  </div>
                </div>
              </Link>
            )}
          </div>

          {/* Center - Main featured article */}
          {mainFeatured && (
            <div className="lg:col-span-6">
              <Link href={`/article/${mainFeatured.slug}`} className="block group">
                <div className="relative h-64 lg:h-[500px] rounded-2xl overflow-hidden shadow-2xl hover:shadow-3xl transition-all duration-500">
                  <Image
                    src="https://images.pexels.com/photos/1884576/pexels-photo-1884576.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
                    alt={mainFeatured.title}
                    fill
                    className="object-cover group-hover:scale-105 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent" />
                  <div className="absolute top-4 left-4">
                    <span className="bg-red-500/90 backdrop-blur-sm text-white text-sm font-medium px-3 py-1 rounded-full">
                      {formatTimeAgo(mainFeatured.publicationDate)}
                    </span>
                  </div>
                  <div className="absolute bottom-6 left-6 right-6">
                    <h2 className="text-white font-bold text-xl lg:text-4xl leading-tight mb-4">
                      {mainFeatured.title}
                    </h2>
                    <div className="flex items-center space-x-3 text-white/90">
                      <div className="w-10 h-10 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center">
                        <span className="text-sm">👤</span>
                      </div>
                      <div>
                        <span className="text-sm font-medium">Chase Montgomery</span>
                        <span className="text-sm ml-2">• 0 comments</span>
                      </div>
                    </div>
                  </div>
                </div>
              </Link>
            </div>
          )}

          {/* Right Column - Mobile: full width, Desktop: 3 columns */}
          <div className="lg:col-span-3 space-y-4">
            {sideArticles.slice(3, 5).map((article, index) => (
              <Link key={article._id} href={`/article/${article.slug}`} className="block">
                <div className="relative h-48 lg:h-40 rounded-xl overflow-hidden group shadow-lg hover:shadow-xl transition-all duration-300">
                  <Image
                    src={index === 0 ? "https://images.pexels.com/photos/10512973/pexels-photo-10512973.jpeg?auto=compress&cs=tinysrgb&h=650&w=940" : "https://images.pexels.com/photos/5586480/pexels-photo-5586480.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"}
                    alt={article.title}
                    fill
                    className="object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent" />
                  <div className="absolute top-3 left-3">
                    <span className="bg-white/20 backdrop-blur-sm text-white text-xs font-medium px-2 py-1 rounded-full">
                      {formatTimeAgo(article.publicationDate)}
                    </span>
                  </div>
                  <div className="absolute bottom-3 left-3 right-3">
                    <h3 className="text-white font-bold text-sm lg:text-xs leading-tight line-clamp-3">
                      {article.title}
                    </h3>
                  </div>
                </div>
              </Link>
            ))}
            {/* Third article - hidden on mobile */}
            {sideArticles[5] && (
              <Link href={`/article/${sideArticles[5].slug}`} className="hidden lg:block">
                <div className="relative h-40 rounded-xl overflow-hidden group shadow-lg hover:shadow-xl transition-all duration-300">
                  <Image
                    src="https://images.pexels.com/photos/8336939/pexels-photo-8336939.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
                    alt={sideArticles[5].title}
                    fill
                    className="object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent" />
                  <div className="absolute top-3 left-3">
                    <span className="bg-white/20 backdrop-blur-sm text-white text-xs font-medium px-2 py-1 rounded-full">
                      {formatTimeAgo(sideArticles[5].publicationDate)}
                    </span>
                  </div>
                  <div className="absolute bottom-3 left-3 right-3">
                    <h3 className="text-white font-bold text-xs leading-tight line-clamp-3">
                      {sideArticles[5].title}
                    </h3>
                  </div>
                </div>
              </Link>
            )}
            {/* Fourth article - new addition to fill empty space */}
            <div className="hidden lg:block">
              <div className="relative h-40 rounded-xl overflow-hidden group shadow-lg hover:shadow-xl transition-all duration-300">
                <Image
                  src="https://images.pexels.com/photos/33418937/pexels-photo-33418937.png?auto=compress&cs=tinysrgb&h=650&w=940"
                  alt="Intense soccer tackle on green field"
                  fill
                  className="object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent" />
                <div className="absolute top-3 left-3">
                  <span className="bg-white/20 backdrop-blur-sm text-white text-xs font-medium px-2 py-1 rounded-full">
                    2 DAYS AGO
                  </span>
                </div>
                <div className="absolute bottom-3 left-3 right-3">
                  <h3 className="text-white font-bold text-xs leading-tight line-clamp-3">
                    Premier League action intensifies as teams battle for crucial points
                  </h3>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Trending this week - Enhanced styling */}
        <div className="mb-12">
          <div className="flex items-center space-x-3 mb-6">
            <div className="w-1 h-8 bg-red-500 rounded-full"></div>
            <h2 className="text-2xl lg:text-3xl font-bold text-foreground">Trending this week</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {trendingArticles.map((article, index) => (
              <Link key={article._id} href={`/article/${article.slug}`} className="group">
                <div className="bg-card rounded-xl overflow-hidden shadow-md hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1">
                  <div className="relative h-48">
                    <Image
                      src={
                        index === 0 ? "https://images.pexels.com/photos/7200644/pexels-photo-7200644.jpeg?auto=compress&cs=tinysrgb&h=650&w=940" :
                        index === 1 ? "https://images.pexels.com/photos/8007174/pexels-photo-8007174.jpeg?auto=compress&cs=tinysrgb&h=650&w=940" :
                        index === 2 ? "https://images.pexels.com/photos/6620665/pexels-photo-6620665.jpeg?auto=compress&cs=tinysrgb&h=650&w=940" :
                        "https://images.pexels.com/photos/7811260/pexels-photo-7811260.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
                      }
                      alt={article.title}
                      fill
                      className="object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                  </div>
                  <div className="p-4">
                    <div className="flex items-center space-x-2 mb-3">
                      <span className="bg-gradient-to-r from-red-500 to-red-600 text-white text-xs px-3 py-1 rounded-full font-medium">
                        SPORT-NEWS
                      </span>
                      <span className="text-muted-foreground text-xs">
                        {formatTimeAgo(article.publicationDate)}
                      </span>
                    </div>
                    <h3 className="font-bold text-foreground text-sm leading-tight line-clamp-3 group-hover:text-red-600 transition-colors">
                      {article.title}
                    </h3>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>

        {/* Football Section - Enhanced */}
        {footballArticles.length > 0 && (
          <div className="mb-12">
            <div className="flex items-center space-x-3 mb-6">
              <div className="w-1 h-8 bg-green-500 rounded-full"></div>
              <h2 className="text-2xl lg:text-3xl font-bold text-foreground">Football</h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {footballArticles.map((article, index) => (
                <Link key={article._id} href={`/article/${article.slug}`} className="group">
                  <div className="bg-card rounded-xl overflow-hidden shadow-md hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1">
                    <div className="relative h-48">
                      <Image
                        src={
                          index === 0 ? "https://images.pexels.com/photos/1884574/pexels-photo-1884574.jpeg?auto=compress&cs=tinysrgb&h=650&w=940" :
                          index === 1 ? "https://images.pexels.com/photos/10512973/pexels-photo-10512973.jpeg?auto=compress&cs=tinysrgb&h=650&w=940" :
                          index === 2 ? "https://images.pexels.com/photos/13241582/pexels-photo-13241582.jpeg?auto=compress&cs=tinysrgb&h=650&w=940" :
                          "https://images.pexels.com/photos/5247206/pexels-photo-5247206.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
                        }
                        alt={article.title}
                        fill
                        className="object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                    </div>
                    <div className="p-4">
                      <div className="flex items-center space-x-2 mb-3">
                        <span className="bg-gradient-to-r from-green-500 to-green-600 text-white text-xs px-3 py-1 rounded-full font-medium">
                          FOOTBALL
                        </span>
                        <span className="text-muted-foreground text-xs">
                          {formatTimeAgo(article.publicationDate)}
                        </span>
                      </div>
                      <h3 className="font-bold text-foreground text-sm leading-tight line-clamp-3 group-hover:text-green-600 transition-colors">
                        {article.title}
                      </h3>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        )}

        {/* F1 News Section - Enhanced */}
        {f1Articles.length > 0 && (
          <div className="mb-12">
            <div className="flex items-center space-x-3 mb-6">
              <div className="w-1 h-8 bg-red-500 rounded-full"></div>
              <h2 className="text-2xl lg:text-3xl font-bold text-foreground">F1 News</h2>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Left side - Article list */}
              <div className="lg:col-span-1 space-y-6">
                <div className="space-y-4">
                  <div className="flex items-start space-x-3 p-4 bg-card rounded-xl shadow-md hover:shadow-lg transition-all duration-300">
                    <div className="relative w-20 h-16 rounded-lg overflow-hidden flex-shrink-0">
                      <Image
                        src="https://assets.macaly-user-data.dev/s5iicds9bgf6miekzwbbnvk9/txpbf34g24md2xm7gze2inoz/hJOu-bN_q8uHZP1xvKufa/tmp4szwyn36.jpg"
                        alt="F1 2025 Season"
                        fill
                        className="object-cover"
                      />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-bold text-foreground text-base leading-tight hover:text-red-600 transition-colors line-clamp-2">
                        F1 2025 Season: Full Calendar, Driver Line-Ups, Testing, Rules
                      </h3>
                      <div className="flex items-center space-x-2 mt-2">
                        <span className="bg-gradient-to-r from-orange-500 to-orange-600 text-white text-xs px-2 py-1 rounded-full font-medium">
                          MAIN
                        </span>
                        <span className="text-muted-foreground text-xs">
                          7 MONTHS AGO
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Other F1 articles */}
                <div className="space-y-4">
                  <div className="flex items-start space-x-3 p-4 bg-card rounded-xl shadow-md hover:shadow-lg transition-all duration-300">
                    <div className="relative w-20 h-16 rounded-lg overflow-hidden flex-shrink-0">
                      <Image
                        src="https://images.pexels.com/photos/5640613/pexels-photo-5640613.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
                        alt="Anthony Hamilton"
                        fill
                        className="object-cover"
                      />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-bold text-foreground text-base leading-tight hover:text-red-600 transition-colors line-clamp-2">
                        Anthony Hamilton to take official FIA role supporting young driver development
                      </h3>
                      <div className="flex items-center space-x-2 mt-2">
                        <span className="bg-gradient-to-r from-red-500 to-red-600 text-white text-xs px-2 py-1 rounded-full font-medium">
                          SPORT-NEWS
                        </span>
                        <span className="text-muted-foreground text-xs">
                          3 MONTHS AGO
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex items-start space-x-3 p-4 bg-card rounded-xl shadow-md hover:shadow-lg transition-all duration-300">
                    <div className="relative w-20 h-16 rounded-lg overflow-hidden flex-shrink-0">
                      <Image
                        src="https://assets.macaly-user-data.dev/s5iicds9bgf6miekzwbbnvk9/txpbf34g24md2xm7gze2inoz/4R-WaAwFieG0utP0SCs-n/tmps8rwsmm2.jpg"
                        alt="Verstappen GT3"
                        fill
                        className="object-cover"
                      />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-bold text-foreground text-base leading-tight hover:text-red-600 transition-colors line-clamp-2">
                        Verstappen explains "Franz Hermann" alias after GT3 test at Nürburgring
                      </h3>
                      <div className="flex items-center space-x-2 mt-2">
                        <span className="bg-gradient-to-r from-red-500 to-red-600 text-white text-xs px-2 py-1 rounded-full font-medium">
                          SPORT-NEWS
                        </span>
                        <span className="text-muted-foreground text-xs">
                          3 MONTHS AGO
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex items-start space-x-3 p-4 bg-card rounded-xl shadow-md hover:shadow-lg transition-all duration-300">
                    <div className="relative w-20 h-16 rounded-lg overflow-hidden flex-shrink-0">
                      <Image
                        src="https://images.pexels.com/photos/31204631/pexels-photo-31204631.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
                        alt="Lewis Hamilton Ferrari"
                        fill
                        className="object-cover"
                      />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-bold text-foreground text-base leading-tight hover:text-red-600 transition-colors line-clamp-2">
                        Lewis Hamilton admits Ferrari switch tougher than expected in 2025 F1 season
                      </h3>
                      <div className="flex items-center space-x-2 mt-2">
                        <span className="bg-gradient-to-r from-red-500 to-red-600 text-white text-xs px-2 py-1 rounded-full font-medium">
                          SPORT-NEWS
                        </span>
                        <span className="text-muted-foreground text-xs">
                          3 MONTHS AGO
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Right side - Large Featured F1 article */}
              <div className="lg:col-span-2">
                <div className="block group">
                  <div className="relative h-64 lg:h-96 rounded-2xl overflow-hidden shadow-xl hover:shadow-2xl transition-all duration-500">
                    <Image
                      src="https://assets.macaly-user-data.dev/s5iicds9bgf6miekzwbbnvk9/txpbf34g24md2xm7gze2inoz/Jbqkbgy1gbEmb1r8AW_gd/tmpi88xpu6m.jpg"
                      alt="Hamilton Russell FIA swearing ban"
                      fill
                      className="object-cover group-hover:scale-105 transition-transform duration-700"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent" />
                    <div className="absolute top-4 left-4">
                      <span className="bg-red-500/90 backdrop-blur-sm text-white text-sm font-medium px-3 py-1 rounded-full">
                        3 MONTHS AGO
                      </span>
                    </div>
                    <div className="absolute bottom-6 left-6 right-6">
                      <h3 className="text-white font-bold text-xl lg:text-3xl leading-tight mb-4">
                        Hamilton, Russell slam FIA over reversed swearing ban: "A mess",...
                      </h3>
                      <div className="flex items-center space-x-3 text-white/90">
                        <div className="w-10 h-10 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center">
                          <span className="text-sm">👤</span>
                        </div>
                        <div>
                          <span className="text-sm font-medium">Chase Montgomery</span>
                          <span className="text-sm ml-2">• 0 comments</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Tennis Section - New enhanced section similar to F1 */}
        <div className="mb-12">
          <div className="flex items-center space-x-3 mb-6">
            <div className="w-1 h-8 bg-yellow-500 rounded-full"></div>
            <h2 className="text-2xl lg:text-3xl font-bold text-foreground">Tennis</h2>
          </div>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left side - Tennis article list */}
            <div className="lg:col-span-1 space-y-6">
              <div className="space-y-4">
                <div className="flex items-start space-x-3 p-4 bg-card rounded-xl shadow-md hover:shadow-lg transition-all duration-300">
                  <div className="relative w-20 h-16 rounded-lg overflow-hidden flex-shrink-0">
                    <Image
                      src="https://assets.macaly-user-data.dev/s5iicds9bgf6miekzwbbnvk9/txpbf34g24md2xm7gze2inoz/8vjVgwI6yqICDnvlHQIjf/tmpiku8glhw.jpg"
                      alt="Tennis Player Action"
                      fill
                      className="object-cover"
                    />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-foreground text-base leading-tight hover:text-yellow-600 transition-colors line-clamp-2">
                      Djokovic dominates Australian Open: Record-breaking performance
                    </h3>
                    <div className="flex items-center space-x-2 mt-2">
                      <span className="bg-gradient-to-r from-yellow-500 to-yellow-600 text-white text-xs px-2 py-1 rounded-full font-medium">
                        MAIN
                      </span>
                      <span className="text-muted-foreground text-xs">
                        2 MONTHS AGO
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex items-start space-x-3 p-4 bg-card rounded-xl shadow-md hover:shadow-lg transition-all duration-300">
                  <div className="relative w-20 h-16 rounded-lg overflow-hidden flex-shrink-0">
                    <Image
                      src="https://images.pexels.com/photos/1432039/pexels-photo-1432039.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
                      alt="Tennis Court Action"
                      fill
                      className="object-cover"
                    />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-foreground text-base leading-tight hover:text-yellow-600 transition-colors line-clamp-2">
                      Wimbledon 2025: New grass court technology revolutionizes play
                    </h3>
                    <div className="flex items-center space-x-2 mt-2">
                      <span className="bg-gradient-to-r from-green-500 to-green-600 text-white text-xs px-2 py-1 rounded-full font-medium">
                        TENNIS-NEWS
                      </span>
                      <span className="text-muted-foreground text-xs">
                        1 MONTH AGO
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex items-start space-x-3 p-4 bg-card rounded-xl shadow-md hover:shadow-lg transition-all duration-300">
                  <div className="relative w-20 h-16 rounded-lg overflow-hidden flex-shrink-0">
                    <Image
                      src="https://assets.macaly-user-data.dev/s5iicds9bgf6miekzwbbnvk9/txpbf34g24md2xm7gze2inoz/AASdx4TrVGwkEn0poei5E/tmpuc1ijrbz.jpg"
                      alt="Tennis Equipment"
                      fill
                      className="object-cover"
                    />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-foreground text-base leading-tight hover:text-yellow-600 transition-colors line-clamp-2">
                      French Open clay court preparation: Behind the scenes
                    </h3>
                    <div className="flex items-center space-x-2 mt-2">
                      <span className="bg-gradient-to-r from-orange-500 to-orange-600 text-white text-xs px-2 py-1 rounded-full font-medium">
                        TENNIS-NEWS
                      </span>
                      <span className="text-muted-foreground text-xs">
                        3 WEEKS AGO
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex items-start space-x-3 p-4 bg-card rounded-xl shadow-md hover:shadow-lg transition-all duration-300">
                  <div className="relative w-20 h-16 rounded-lg overflow-hidden flex-shrink-0">
                    <Image
                      src="https://images.pexels.com/photos/5739119/pexels-photo-5739119.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
                      alt="Tennis Player Serve"
                      fill
                      className="object-cover"
                    />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-foreground text-base leading-tight hover:text-yellow-600 transition-colors line-clamp-2">
                      Rising stars: Next generation of tennis champions
                    </h3>
                    <div className="flex items-center space-x-2 mt-2">
                      <span className="bg-gradient-to-r from-purple-500 to-purple-600 text-white text-xs px-2 py-1 rounded-full font-medium">
                        TENNIS-NEWS
                      </span>
                      <span className="text-muted-foreground text-xs">
                        2 WEEKS AGO
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Right side - Large Featured Tennis article */}
            <div className="lg:col-span-2">
              <div className="block group">
                <div className="relative h-64 lg:h-96 rounded-2xl overflow-hidden shadow-xl hover:shadow-2xl transition-all duration-500">
                  <Image
                    src="https://assets.macaly-user-data.dev/s5iicds9bgf6miekzwbbnvk9/txpbf34g24md2xm7gze2inoz/ESqhtavH_UPT6S9hOgIzs/tmp1rrx2u3a.jpg"
                    alt="Wimbledon Tennis Court"
                    fill
                    className="object-cover group-hover:scale-105 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent" />
                  <div className="absolute top-4 left-4">
                    <span className="bg-yellow-500/90 backdrop-blur-sm text-white text-sm font-medium px-3 py-1 rounded-full">
                      1 MONTH AGO
                    </span>
                  </div>
                  <div className="absolute bottom-6 left-6 right-6">
                    <h3 className="text-white font-bold text-xl lg:text-3xl leading-tight mb-4">
                      Wimbledon 2025: Championship predictions and player analysis
                    </h3>
                    <div className="flex items-center space-x-3 text-white/90">
                      <div className="w-10 h-10 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center">
                        <span className="text-sm">👤</span>
                      </div>
                      <div>
                        <span className="text-sm font-medium">Chase Montgomery</span>
                        <span className="text-sm ml-2">• 0 comments</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Basketball Section - Enhanced */}
        {basketballArticles.length > 0 && (
          <div className="mb-12">
            <div className="flex items-center space-x-3 mb-6">
              <div className="w-1 h-8 bg-orange-500 rounded-full"></div>
              <h2 className="text-2xl lg:text-3xl font-bold text-foreground">Basketball</h2>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Left side - Article list */}
              <div className="lg:col-span-1 space-y-4">
                {basketballArticles.slice(0, 3).map((article, index) => (
                  <div key={article._id} className="flex items-start space-x-3 p-4 bg-card rounded-xl shadow-md hover:shadow-lg transition-all duration-300">
                    <div className="relative w-16 h-16 rounded-lg overflow-hidden flex-shrink-0">
                      <Image
                        src={
                          index === 0 ? "https://images.pexels.com/photos/31036780/pexels-photo-31036780.jpeg?auto=compress&cs=tinysrgb&h=650&w=940" :
                          index === 1 ? "https://images.pexels.com/photos/8336955/pexels-photo-8336955.jpeg?auto=compress&cs=tinysrgb&h=650&w=940" :
                          "https://images.pexels.com/photos/8336939/pexels-photo-8336939.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
                        }
                        alt={article.title}
                        fill
                        className="object-cover"
                      />
                    </div>
                    <div className="flex-1">
                      <Link href={`/article/${article.slug}`}>
                        <h3 className="font-bold text-foreground text-sm leading-tight hover:text-orange-600 transition-colors line-clamp-2">
                          {article.title}
                        </h3>
                      </Link>
                      <div className="flex items-center space-x-2 mt-1">
                        <span className="bg-gradient-to-r from-orange-500 to-orange-600 text-white text-xs px-2 py-1 rounded-full font-medium">
                          BASKETBALL
                        </span>
                        <span className="text-muted-foreground text-xs">
                          {formatTimeAgo(article.publicationDate)}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Right side - Featured Basketball article */}
              {basketballArticles[0] && (
                <div className="lg:col-span-2">
                  <Link href={`/article/${basketballArticles[0].slug}`} className="block group">
                    <div className="relative h-64 lg:h-80 rounded-2xl overflow-hidden shadow-xl hover:shadow-2xl transition-all duration-500">
                      <Image
                        src="https://images.pexels.com/photos/5586480/pexels-photo-5586480.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
                        alt={basketballArticles[0].title}
                        fill
                        className="object-cover group-hover:scale-105 transition-transform duration-700"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent" />
                      <div className="absolute top-4 left-4">
                        <span className="bg-orange-500/90 backdrop-blur-sm text-white text-sm font-medium px-3 py-1 rounded-full">
                          {formatTimeAgo(basketballArticles[0].publicationDate)}
                        </span>
                      </div>
                      <div className="absolute bottom-6 left-6 right-6">
                        <h3 className="text-white font-bold text-xl lg:text-2xl leading-tight mb-4">
                          {basketballArticles[0].title}
                        </h3>
                        <div className="flex items-center space-x-3 text-white/90">
                          <div className="w-10 h-10 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center">
                            <span className="text-sm">👤</span>
                          </div>
                          <div>
                            <span className="text-sm font-medium">Chase Montgomery</span>
                            <span className="text-sm ml-2">• 0 comments</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </Link>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Latest Section with Popular Now Sidebar - Enhanced */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Latest Articles */}
          <div className="lg:col-span-2">
            <div className="flex items-center space-x-3 mb-6">
              <div className="w-1 h-8 bg-blue-500 rounded-full"></div>
              <h2 className="text-2xl lg:text-3xl font-bold text-foreground">Latest</h2>
            </div>
            <div className="space-y-6">
              {latestArticles.map((article, index) => (
                <div key={article._id} className="flex items-start space-x-4 p-4 bg-card rounded-xl shadow-md hover:shadow-lg transition-all duration-300">
                  <div className="relative w-32 h-24 rounded-lg overflow-hidden flex-shrink-0">
                    <Image
                      src={
                        index === 0 ? "https://images.pexels.com/photos/1884576/pexels-photo-1884576.jpeg?auto=compress&cs=tinysrgb&h=650&w=940" :
                        index === 1 ? "https://images.pexels.com/photos/31036780/pexels-photo-31036780.jpeg?auto=compress&cs=tinysrgb&h=650&w=940" :
                        "https://images.pexels.com/photos/13241582/pexels-photo-13241582.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
                      }
                      alt={article.title}
                      fill
                      className="object-cover"
                    />
                  </div>
                  <div className="flex-1">
                    <div className="text-muted-foreground text-sm mb-1">
                      {formatTimeAgo(article.publicationDate)}
                    </div>
                    <Link href={`/article/${article.slug}`}>
                      <h3 className="font-bold text-foreground text-lg leading-tight hover:text-blue-600 transition-colors line-clamp-2 mb-2">
                        {article.title}
                      </h3>
                    </Link>
                    {article.summary && (
                      <p className="text-muted-foreground text-sm line-clamp-2 mb-2">
                        {article.summary}
                      </p>
                    )}
                    <div className="flex items-center space-x-2 text-sm text-muted-foreground">
                      <div className="w-6 h-6 rounded-full bg-muted flex items-center justify-center">
                        <span className="text-xs">👤</span>
                      </div>
                      <span>Chase Montgomery</span>
                      <span>• 2</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Popular Now Sidebar - Enhanced */}
          <div className="lg:col-span-1">
            <div className="bg-card rounded-xl p-6 shadow-lg">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold text-foreground">Popular Now</h2>
                <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
              </div>
              <div className="space-y-4">
                {popularArticles.map((article, index) => (
                  <div key={index} className="flex items-start space-x-3 p-3 rounded-lg hover:bg-muted/50 transition-colors">
                    <div className="text-2xl font-bold text-red-500 flex-shrink-0 w-8">
                      {index + 1}
                    </div>
                    <div className="flex-1">
                      <h3 className="font-bold text-foreground text-sm leading-tight line-clamp-3 mb-2 hover:text-red-600 transition-colors cursor-pointer">
                        {article.title}
                      </h3>
                      <div className="flex items-center space-x-2 text-xs text-muted-foreground">
                        <span>{article.time}</span>
                        <span>•</span>
                        <span>{article.views} views</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
