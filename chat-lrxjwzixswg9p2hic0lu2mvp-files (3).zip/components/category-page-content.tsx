

"use client";

import { usePreloadedQuery } from "convex/react";
import { api } from "@/convex/_generated/api";
import { Preloaded } from "convex/react";
import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";

interface CategoryPageContentProps {
  categorySlug: string;
  preloadedCategories: Preloaded<typeof api.categories.getAllCategories>;
  preloadedArticles: Preloaded<typeof api.articles.getArticlesByCategorySlug>;
}

// Category-specific themes and configurations
const categoryThemes = {
  politics: {
    color: "blue",
    bgGradient: "from-blue-600 to-blue-800",
    accentColor: "bg-blue-600",
    hoverColor: "hover:bg-blue-700",
    textColor: "text-blue-600",
    icon: "🏛️",
    description: "Stay informed with the latest political developments, policy changes, and government news from around the world."
  },
  finance: {
    color: "green",
    bgGradient: "from-green-600 to-green-800",
    accentColor: "bg-green-600",
    hoverColor: "hover:bg-green-700",
    textColor: "text-green-600",
    icon: "💰",
    description: "Breaking financial news, market analysis, economic trends, and business insights to keep you ahead."
  },
  sports: {
    color: "orange",
    bgGradient: "from-orange-600 to-orange-800",
    accentColor: "bg-orange-600",
    hoverColor: "hover:bg-orange-700",
    textColor: "text-orange-600",
    icon: "⚽",
    description: "Latest sports news, scores, player updates, and analysis from football, basketball, soccer, and more."
  },
  tech: {
    color: "purple",
    bgGradient: "from-purple-600 to-purple-800",
    accentColor: "bg-purple-600",
    hoverColor: "hover:bg-purple-700",
    textColor: "text-purple-600",
    icon: "💻",
    description: "Breaking tech news, gadget reviews, innovation trends, and the latest in technology and digital transformation."
  },
  gaming: {
    color: "indigo",
    bgGradient: "from-indigo-600 to-indigo-800",
    accentColor: "bg-indigo-600",
    hoverColor: "hover:bg-indigo-700",
    textColor: "text-indigo-600",
    icon: "🎮",
    description: "Latest gaming news, reviews, industry updates, esports coverage, and entertainment from the gaming world."
  },
  fashion: {
    color: "pink",
    bgGradient: "from-pink-600 to-pink-800",
    accentColor: "bg-pink-600",
    hoverColor: "hover:bg-pink-700",
    textColor: "text-pink-600",
    icon: "👗",
    description: "Latest fashion trends, style news, designer collections, and industry updates from the world of fashion."
  },
  travel: {
    color: "teal",
    bgGradient: "from-teal-600 to-teal-800",
    accentColor: "bg-teal-600",
    hoverColor: "hover:bg-teal-700",
    textColor: "text-teal-600",
    icon: "✈️",
    description: "Travel news, destination guides, tourism updates, and tips to help you explore the world."
  },
  food: {
    color: "amber",
    bgGradient: "from-amber-600 to-amber-800",
    accentColor: "bg-amber-600",
    hoverColor: "hover:bg-amber-700",
    textColor: "text-amber-600",
    icon: "🍽️",
    description: "Latest food news, restaurant reviews, culinary trends, and delicious discoveries from around the globe."
  }
};

export default function CategoryPageContent({ 
  categorySlug, 
  preloadedCategories, 
  preloadedArticles 
}: CategoryPageContentProps) {
  const categories = usePreloadedQuery(preloadedCategories);
  const categoryArticles = usePreloadedQuery(preloadedArticles);

  // Find the category by slug
  const category = categories.find(cat => cat.slug === categorySlug);
  
  if (!category) {
    notFound();
  }

  // Get theme for this category
  const theme = categoryThemes[categorySlug as keyof typeof categoryThemes] || categoryThemes.politics;

  // Get featured article (first one)
  const featuredArticle = categoryArticles[0];
  
  // Get remaining articles for sidebar
  const sidebarArticles = categoryArticles.slice(1, 8); // Show up to 7 articles in sidebar

  return (
    <div className="min-h-screen bg-white">
      {/* Three Column Layout */}
      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="grid grid-cols-12 gap-6">
          
          {/* Left Sidebar - News List */}
          <div className="col-span-12 lg:col-span-3">
            <div className="bg-white">
              {/* News Header */}
              <div className="flex items-center space-x-2 mb-6">
                <div className="w-1 h-6 bg-orange-500"></div>
                <h2 className="text-xl font-bold text-gray-900">News</h2>
              </div>

              {/* News List */}
              <div className="space-y-6">
                {sidebarArticles.map((article, index) => (
                  <Link key={article._id} href={`/article/${article.slug}`} className="group block">
                    <div className="flex items-start space-x-3">
                      <div className="flex-shrink-0 text-center">
                        <div className="text-lg font-bold text-gray-900">
                          {Math.floor(Math.random() * 6) + 2}
                        </div>
                        <div className="text-xs text-gray-600 uppercase">
                          months
                        </div>
                        <div className="text-xs text-gray-600">
                          ago
                        </div>
                      </div>
                      <div className="flex-1 min-w-0">
                        <h3 className="text-sm font-medium text-gray-900 group-hover:text-orange-500 transition-colors line-clamp-3 leading-tight">
                          {article.title}
                        </h3>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          </div>

          {/* Center - Hero Article */}
          <div className="col-span-12 lg:col-span-6">
            {featuredArticle && (
              <div className="bg-white">
                {/* Category and Date */}
                <div className="flex items-center space-x-2 mb-4">
                  <span className="text-sm text-gray-600 font-medium">
                    main
                  </span>
                  <span className="text-sm text-gray-500">
                    | 2 months ago
                  </span>
                </div>

                {/* Main Article */}
                <Link href={`/article/${featuredArticle.slug}`} className="group block">
                  <h1 className="text-3xl lg:text-4xl font-bold text-gray-900 group-hover:text-orange-500 transition-colors mb-6 leading-tight">
                    {featuredArticle.title}
                  </h1>

                  {/* Hero Image */}
                  <div className="relative h-64 lg:h-96 mb-6 overflow-hidden rounded-lg">
                    <Image
                      src={featuredArticle.imageUrl || "/placeholder-hero.jpg"}
                      alt={featuredArticle.title}
                      fill
                      className="object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    {/* Navigation Dots */}
                    <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex space-x-2">
                      <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                      <div className="w-3 h-3 bg-gray-400 rounded-full"></div>
                      <div className="w-3 h-3 bg-gray-400 rounded-full"></div>
                      <div className="w-3 h-3 bg-gray-400 rounded-full"></div>
                      <div className="w-3 h-3 bg-gray-400 rounded-full"></div>
                      <div className="w-3 h-3 bg-gray-400 rounded-full"></div>
                    </div>
                  </div>

                  {/* Article Summary */}
                  {featuredArticle.summary && (
                    <p className="text-lg text-gray-700 leading-relaxed mb-4">
                      {featuredArticle.summary}
                    </p>
                  )}

                  {/* Author and Views */}
                  <div className="flex items-center justify-between text-sm text-gray-500">
                    <span>By Horizons Times</span>
                    <span>{featuredArticle.views || 0} views</span>
                  </div>
                </Link>
              </div>
            )}
          </div>

          {/* Right Sidebar */}
          <div className="col-span-12 lg:col-span-3">
            {/* Add top margin to align with main content */}
            <div className="mt-12 space-y-8">
              
              {/* Featured Story Card */}
              {categoryArticles[1] && (
                <div className="bg-white">
                  <div className="flex items-center space-x-2 mb-4">
                    <span className="text-sm font-medium text-gray-600">main</span>
                    <span className="text-sm text-gray-500">| 2 months ago</span>
                  </div>
                  
                  <Link href={`/article/${categoryArticles[1].slug}`} className="group block">
                    <h3 className="text-lg font-bold text-gray-900 group-hover:text-orange-500 transition-colors mb-3 leading-tight">
                      {categoryArticles[1].title}
                    </h3>
                    
                    <div className="relative h-32 mb-3 overflow-hidden rounded">
                      <Image
                        src={categoryArticles[1].imageUrl || "/placeholder-article.jpg"}
                        alt={categoryArticles[1].title}
                        fill
                        className="object-cover"
                      />
                    </div>
                  </Link>
                </div>
              )}

              {/* Second Featured Story */}
              {categoryArticles[2] && (
                <div className="bg-white">
                  <div className="flex items-center space-x-2 mb-4">
                    <span className="text-sm font-medium text-gray-600">political news</span>
                    <span className="text-sm text-gray-500">| 3 months ago</span>
                  </div>
                  
                  <Link href={`/article/${categoryArticles[2].slug}`} className="group block">
                    <h3 className="text-lg font-bold text-gray-900 group-hover:text-orange-500 transition-colors mb-3 leading-tight">
                      {categoryArticles[2].title}
                    </h3>
                    
                    <div className="relative h-32 mb-3 overflow-hidden rounded">
                      <Image
                        src={categoryArticles[2].imageUrl || "/placeholder-article.jpg"}
                        alt={categoryArticles[2].title}
                        fill
                        className="object-cover"
                      />
                    </div>
                  </Link>
                </div>
              )}

            </div>
          </div>

        </div>
      </div>

      {/* Europe Section */}
      {categorySlug === 'politics' && (
        <div className="max-w-7xl mx-auto px-4 py-8">
          {/* Europe Header */}
          <div className="flex items-center space-x-2 mb-6">
            <div className="w-1 h-6 bg-orange-500"></div>
            <h2 className="text-xl font-bold text-white bg-gray-900 px-3 py-1">Europe</h2>
          </div>

          {/* Europe Articles Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {/* Featured European Articles */}
            {categoryArticles.slice(3, 7).map((article, index) => (
              <Link key={article._id} href={`/article/${article.slug}`} className="group block">
                <div className="bg-white">
                  {/* Article Image */}
                  <div className="relative h-48 mb-3 overflow-hidden">
                    <Image
                      src={article.imageUrl || "/placeholder-article.jpg"}
                      alt={article.title}
                      fill
                      className="object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                  </div>

                  {/* Article Meta */}
                  <div className="flex items-center space-x-2 mb-2">
                    <span className="text-xs text-gray-600 font-medium">
                      political news
                    </span>
                    <span className="text-xs text-gray-500">
                      | 3 months ago
                    </span>
                  </div>

                  {/* Article Title */}
                  <h3 className="text-sm font-bold text-gray-900 group-hover:text-orange-500 transition-colors leading-tight line-clamp-3">
                    {article.title}
                  </h3>
                </div>
              </Link>
            ))}
          </div>
        </div>
      )}

      {/* USA, International, Great Britain Sections */}
      {categorySlug === 'politics' && (
        <div className="max-w-7xl mx-auto px-4 py-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            
            {/* USA Section */}
            <div>
              <div className="flex items-center space-x-2 mb-6">
                <div className="w-1 h-6 bg-orange-500"></div>
                <h2 className="text-xl font-bold text-gray-900">USA</h2>
              </div>

              {/* USA Featured Article */}
              {categoryArticles[7] && (
                <Link href={`/article/${categoryArticles[7].slug}`} className="group block mb-6">
                  <div className="bg-white">
                    <div className="relative h-48 mb-3 overflow-hidden">
                      <Image
                        src={categoryArticles[7].imageUrl || "/usa-politics.jpg"}
                        alt={categoryArticles[7].title}
                        fill
                        className="object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                    </div>
                    <div className="flex items-center space-x-2 mb-2">
                      <span className="text-xs text-gray-600 font-medium">political news</span>
                      <span className="text-xs text-gray-500">| 3 months ago</span>
                    </div>
                    <h3 className="text-lg font-bold text-gray-900 group-hover:text-orange-500 transition-colors leading-tight mb-2">
                      {categoryArticles[7].title}
                    </h3>
                  </div>
                </Link>
              )}

              {/* USA Article List */}
              <div className="space-y-4">
                {categoryArticles.slice(8, 11).map((article, index) => (
                  <Link key={article._id} href={`/article/${article.slug}`} className="group block">
                    <div className="flex items-start space-x-3">
                      <div className="flex-shrink-0 w-16 h-12 relative overflow-hidden">
                        <Image
                          src={article.imageUrl || "/usa-politics.jpg"}
                          alt={article.title}
                          fill
                          className="object-cover"
                        />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="text-sm font-medium text-gray-900 group-hover:text-orange-500 transition-colors line-clamp-2 leading-tight">
                          {article.title}
                        </h4>
                        <div className="flex items-center space-x-2 mt-1">
                          <span className="text-xs text-gray-500">3 months ago</span>
                        </div>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            </div>

            {/* International Section */}
            <div>
              <div className="flex items-center space-x-2 mb-6">
                <div className="w-1 h-6 bg-orange-500"></div>
                <h2 className="text-xl font-bold text-gray-900">International</h2>
              </div>

              {/* International Featured Article */}
              {categoryArticles[11] && (
                <Link href={`/article/${categoryArticles[11].slug}`} className="group block mb-6">
                  <div className="bg-white">
                    <div className="relative h-48 mb-3 overflow-hidden">
                      <Image
                        src={categoryArticles[11].imageUrl || "/international-politics.jpg"}
                        alt={categoryArticles[11].title}
                        fill
                        className="object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                    </div>
                    <div className="flex items-center space-x-2 mb-2">
                      <span className="text-xs text-gray-600 font-medium">political news</span>
                      <span className="text-xs text-gray-500">| 3 months ago</span>
                    </div>
                    <h3 className="text-lg font-bold text-gray-900 group-hover:text-orange-500 transition-colors leading-tight mb-2">
                      {categoryArticles[11].title}
                    </h3>
                  </div>
                </Link>
              )}

              {/* International Article List */}
              <div className="space-y-4">
                {categoryArticles.slice(12, 15).map((article, index) => (
                  <Link key={article._id} href={`/article/${article.slug}`} className="group block">
                    <div className="flex items-start space-x-3">
                      <div className="flex-shrink-0 w-16 h-12 relative overflow-hidden">
                        <Image
                          src={article.imageUrl || "/international-politics.jpg"}
                          alt={article.title}
                          fill
                          className="object-cover"
                        />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="text-sm font-medium text-gray-900 group-hover:text-orange-500 transition-colors line-clamp-2 leading-tight">
                          {article.title}
                        </h4>
                        <div className="flex items-center space-x-2 mt-1">
                          <span className="text-xs text-gray-500">3 months ago</span>
                        </div>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            </div>

            {/* Great Britain Section */}
            <div>
              <div className="flex items-center space-x-2 mb-6">
                <div className="w-1 h-6 bg-orange-500"></div>
                <h2 className="text-xl font-bold text-gray-900">Great Britain</h2>
              </div>

              {/* Great Britain Featured Article */}
              {categoryArticles[15] && (
                <Link href={`/article/${categoryArticles[15].slug}`} className="group block mb-6">
                  <div className="bg-white">
                    <div className="relative h-48 mb-3 overflow-hidden">
                      <Image
                        src={categoryArticles[15].imageUrl || "/uk-politics.jpg"}
                        alt={categoryArticles[15].title}
                        fill
                        className="object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                    </div>
                    <div className="flex items-center space-x-2 mb-2">
                      <span className="text-xs text-gray-600 font-medium">political news</span>
                      <span className="text-xs text-gray-500">| 3 months ago</span>
                    </div>
                    <h3 className="text-lg font-bold text-gray-900 group-hover:text-orange-500 transition-colors leading-tight mb-2">
                      {categoryArticles[15].title}
                    </h3>
                  </div>
                </Link>
              )}

              {/* Great Britain Article List */}
              <div className="space-y-4">
                {categoryArticles.slice(16, 19).map((article, index) => (
                  <Link key={article._id} href={`/article/${article.slug}`} className="group block">
                    <div className="flex items-start space-x-3">
                      <div className="flex-shrink-0 w-16 h-12 relative overflow-hidden">
                        <Image
                          src={article.imageUrl || "/uk-politics.jpg"}
                          alt={article.title}
                          fill
                          className="object-cover"
                        />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="text-sm font-medium text-gray-900 group-hover:text-orange-500 transition-colors line-clamp-2 leading-tight">
                          {article.title}
                        </h4>
                        <div className="flex items-center space-x-2 mt-1">
                          <span className="text-xs text-gray-500">3 months ago</span>
                        </div>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            </div>

          </div>
        </div>
      )}
    </div>
  );
}
