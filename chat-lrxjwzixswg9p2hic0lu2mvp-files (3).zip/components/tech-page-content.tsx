




"use client";

import { usePreloadedQuery } from "convex/react";
import { api } from "@/convex/_generated/api";
import { Preloaded } from "convex/react";
import Image from "next/image";
import Link from "next/link";

interface TechPageContentProps {
  preloadedData: Preloaded<typeof api.articles.getCategoryPageData>;
}

export default function TechPageContent({ preloadedData }: TechPageContentProps) {
  const { articles: categoryArticles, categories, category: techCategory } = usePreloadedQuery(preloadedData);
  
  // Remove console logs for better performance
  // Use the articles directly from the optimized query
  const allArticles = categoryArticles;
  
  // Remove console logs for better performance
  // console.log('All articles:', allArticles.length);
  // console.log('Categories:', categories);
  
  // Find the tech category
  const techCategorySlug = techCategory?.slug;
  
  // Filter tech articles by category ID - if no tech category found, use all articles as fallback
  const techArticles = techCategory 
    ? allArticles.filter(article => article.category === techCategory._id)
    : allArticles.slice(0, 15); // Use first 15 articles as fallback
  
  // console.log('Tech articles:', techArticles.length);
  
  // If we don't have enough tech articles, use fallback articles from other categories
  let articlesForDisplay = techArticles;
  if (techArticles.length < 15) { // Reduced from 20 to 15
    const otherArticles = allArticles.filter(article => article.category !== techCategory?._id);
    articlesForDisplay = [...techArticles, ...otherArticles].slice(0, 20); // Reduced from 30 to 20
  }
  
  // console.log('Articles for display:', articlesForDisplay.length);
  
  // Get featured articles for hero section (first 6)
  const heroArticles = articlesForDisplay.slice(0, 6);
  const mainFeatured = heroArticles[0];
  const sideArticles = heroArticles.slice(1, 6);

  // Get trending articles (next 4)
  const trendingArticles = articlesForDisplay.slice(6, 10);

  // Categorize articles by tech topics
  const aiArticles = articlesForDisplay.filter(article => 
    article.title.toLowerCase().includes('ai') || 
    article.title.toLowerCase().includes('artificial intelligence') ||
    article.title.toLowerCase().includes('machine learning') ||
    article.title.toLowerCase().includes('neural') ||
    article.title.toLowerCase().includes('chatgpt') ||
    article.title.toLowerCase().includes('openai')
  ).slice(0, 4);

  const softwareArticles = articlesForDisplay.filter(article => 
    article.title.toLowerCase().includes('software') || 
    article.title.toLowerCase().includes('app') ||
    article.title.toLowerCase().includes('programming') ||
    article.title.toLowerCase().includes('development') ||
    article.title.toLowerCase().includes('code') ||
    article.title.toLowerCase().includes('github')
  ).slice(0, 4);

  const hardwareArticles = articlesForDisplay.filter(article => 
    article.title.toLowerCase().includes('hardware') || 
    article.title.toLowerCase().includes('chip') ||
    article.title.toLowerCase().includes('processor') ||
    article.title.toLowerCase().includes('gpu') ||
    article.title.toLowerCase().includes('cpu') ||
    article.title.toLowerCase().includes('semiconductor')
  ).slice(0, 3);

  const startupArticles = articlesForDisplay.filter(article => 
    article.title.toLowerCase().includes('startup') || 
    article.title.toLowerCase().includes('venture') ||
    article.title.toLowerCase().includes('funding') ||
    article.title.toLowerCase().includes('innovation') ||
    article.title.toLowerCase().includes('tech company')
  ).slice(0, 2);

  // Latest articles
  const latestArticles = articlesForDisplay.slice(0, 3);

  // Popular articles (mock data for now)
  const popularArticles = [
    { title: "OpenAI releases GPT-5 with revolutionary capabilities", time: "1 MONTH AGO", views: "520" },
    { title: "Apple unveils next-generation M4 chip architecture", time: "2 WEEKS AGO", views: "480" },
    { title: "Quantum computing breakthrough promises faster processing", time: "3 WEEKS AGO", views: "410" }
  ];

  const formatTimeAgo = (date: string | number) => {
    const now = new Date();
    const articleDate = new Date(date);
    const diffInMonths = Math.floor((now.getTime() - articleDate.getTime()) / (1000 * 60 * 60 * 24 * 30));
    
    if (diffInMonths >= 1) {
      return `${diffInMonths} MONTHS AGO`;
    }
    const diffInDays = Math.floor((now.getTime() - articleDate.getTime()) / (1000 * 60 * 60 * 24));
    return `${diffInDays} DAYS AGO`;
  };

  console.log('AI articles found:', aiArticles.length);
  console.log('AI articles:', aiArticles.map(a => a.title));

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section - More organic and stylish */}
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Enhanced Hero Grid with better mobile layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 mb-12">
          {/* Left Column - Mobile: full width, Desktop: 3 columns */}
          <div className="lg:col-span-3 space-y-4">
            {sideArticles.slice(0, 2).map((article, index) => (
              <Link key={article._id} href={`/article/${article.slug}`} className="block">
                <div className="relative h-48 lg:h-40 rounded-xl overflow-hidden group shadow-lg hover:shadow-xl transition-all duration-300">
                  <Image
                    src={index === 0 ? "https://images.pexels.com/photos/3861969/pexels-photo-3861969.jpeg?auto=compress&cs=tinysrgb&h=650&w=940" : "https://images.pexels.com/photos/2599244/pexels-photo-2599244.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"}
                    alt={article.title}
                    fill
                    className="object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent" />
                  <div className="absolute top-3 left-3">
                    <span className="bg-white/20 backdrop-blur-sm text-white text-xs font-medium px-2 py-1 rounded-full">
                      {formatTimeAgo(article.publicationDate)}
                    </span>
                  </div>
                  <div className="absolute bottom-3 left-3 right-3">
                    <h3 className="text-white font-bold text-sm lg:text-xs leading-tight line-clamp-3">
                      {article.title}
                    </h3>
                  </div>
                </div>
              </Link>
            ))}
            {/* Third article - hidden on mobile to save space */}
            {sideArticles[2] && (
              <Link href={`/article/${sideArticles[2].slug}`} className="hidden lg:block">
                <div className="relative h-40 rounded-xl overflow-hidden group shadow-lg hover:shadow-xl transition-all duration-300">
                  <Image
                    src="https://images.pexels.com/photos/1181677/pexels-photo-1181677.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
                    alt={sideArticles[2].title}
                    fill
                    className="object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent" />
                  <div className="absolute top-3 left-3">
                    <span className="bg-white/20 backdrop-blur-sm text-white text-xs font-medium px-2 py-1 rounded-full">
                      {formatTimeAgo(sideArticles[2].publicationDate)}
                    </span>
                  </div>
                  <div className="absolute bottom-3 left-3 right-3">
                    <h3 className="text-white font-bold text-xs leading-tight line-clamp-3">
                      {sideArticles[2].title}
                    </h3>
                  </div>
                </div>
              </Link>
            )}
          </div>

          {/* Center - Main featured article */}
          {mainFeatured && (
            <div className="lg:col-span-6">
              <Link href={`/article/${mainFeatured.slug}`} className="block group">
                <div className="relative h-64 lg:h-[500px] rounded-2xl overflow-hidden shadow-2xl hover:shadow-3xl transition-all duration-500">
                  <Image
                    src="https://images.pexels.com/photos/3861969/pexels-photo-3861969.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
                    alt={mainFeatured.title}
                    fill
                    className="object-cover group-hover:scale-105 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent" />
                  <div className="absolute top-4 left-4">
                    <span className="bg-red-500/90 backdrop-blur-sm text-white text-sm font-medium px-3 py-1 rounded-full">
                      {formatTimeAgo(mainFeatured.publicationDate)}
                    </span>
                  </div>
                  <div className="absolute bottom-6 left-6 right-6">
                    <h2 className="text-white font-bold text-xl lg:text-4xl leading-tight mb-4">
                      {mainFeatured.title}
                    </h2>
                    <div className="flex items-center space-x-3 text-white/90">
                      <div className="w-10 h-10 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center">
                        <span className="text-sm">👤</span>
                      </div>
                      <div>
                        <span className="text-sm font-medium">Tech Reporter</span>
                        <span className="text-sm ml-2">• 0 comments</span>
                      </div>
                    </div>
                  </div>
                </div>
              </Link>
            </div>
          )}

          {/* Right Column - Mobile: full width, Desktop: 3 columns */}
          <div className="lg:col-span-3 space-y-4">
            {sideArticles.slice(3, 5).map((article, index) => (
              <Link key={article._id} href={`/article/${article.slug}`} className="block">
                <div className="relative h-48 lg:h-40 rounded-xl overflow-hidden group shadow-lg hover:shadow-xl transition-all duration-300">
                  <Image
                    src={index === 0 ? "https://images.pexels.com/photos/1181677/pexels-photo-1181677.jpeg?auto=compress&cs=tinysrgb&h=650&w=940" : "https://images.pexels.com/photos/3861969/pexels-photo-3861969.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"}
                    alt={article.title}
                    fill
                    className="object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent" />
                  <div className="absolute top-3 left-3">
                    <span className="bg-white/20 backdrop-blur-sm text-white text-xs font-medium px-2 py-1 rounded-full">
                      {formatTimeAgo(article.publicationDate)}
                    </span>
                  </div>
                  <div className="absolute bottom-3 left-3 right-3">
                    <h3 className="text-white font-bold text-sm lg:text-xs leading-tight line-clamp-3">
                      {article.title}
                    </h3>
                  </div>
                </div>
              </Link>
            ))}
            {/* Third article - hidden on mobile */}
            {sideArticles[5] && (
              <Link href={`/article/${sideArticles[5].slug}`} className="hidden lg:block">
                <div className="relative h-40 rounded-xl overflow-hidden group shadow-lg hover:shadow-xl transition-all duration-300">
                  <Image
                    src="https://images.pexels.com/photos/2599244/pexels-photo-2599244.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
                    alt={sideArticles[5].title}
                    fill
                    className="object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent" />
                  <div className="absolute top-3 left-3">
                    <span className="bg-white/20 backdrop-blur-sm text-white text-xs font-medium px-2 py-1 rounded-full">
                      {formatTimeAgo(sideArticles[5].publicationDate)}
                    </span>
                  </div>
                  <div className="absolute bottom-3 left-3 right-3">
                    <h3 className="text-white font-bold text-xs leading-tight line-clamp-3">
                      {sideArticles[5].title}
                    </h3>
                  </div>
                </div>
              </Link>
            )}
            {/* Fourth article - new addition to fill empty space */}
            <div className="hidden lg:block">
              <div className="relative h-40 rounded-xl overflow-hidden group shadow-lg hover:shadow-xl transition-all duration-300">
                <Image
                  src="https://images.pexels.com/photos/1181677/pexels-photo-1181677.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
                  alt="Latest tech innovation breakthrough"
                  fill
                  className="object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent" />
                <div className="absolute top-3 left-3">
                  <span className="bg-white/20 backdrop-blur-sm text-white text-xs font-medium px-2 py-1 rounded-full">
                    2 DAYS AGO
                  </span>
                </div>
                <div className="absolute bottom-3 left-3 right-3">
                  <h3 className="text-white font-bold text-xs leading-tight line-clamp-3">
                    Latest tech innovation breakthrough reshapes industry
                  </h3>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Trending this week - Enhanced styling */}
        <div className="mb-12">
          <div className="flex items-center space-x-3 mb-6">
            <div className="w-1 h-8 bg-red-500 rounded-full"></div>
            <h2 className="text-2xl lg:text-3xl font-bold text-foreground">Trending this week</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {trendingArticles.map((article, index) => (
              <Link key={article._id} href={`/article/${article.slug}`} className="group">
                <div className="bg-card rounded-xl overflow-hidden shadow-md hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1">
                  <div className="relative h-48">
                    <Image
                      src={
                        index === 0 ? "https://images.pexels.com/photos/3861969/pexels-photo-3861969.jpeg?auto=compress&cs=tinysrgb&h=650&w=940" :
                        index === 1 ? "https://images.pexels.com/photos/2599244/pexels-photo-2599244.jpeg?auto=compress&cs=tinysrgb&h=650&w=940" :
                        index === 2 ? "https://images.pexels.com/photos/1181677/pexels-photo-1181677.jpeg?auto=compress&cs=tinysrgb&h=650&w=940" :
                        "https://images.pexels.com/photos/3861969/pexels-photo-3861969.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
                      }
                      alt={article.title}
                      fill
                      className="object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                  </div>
                  <div className="p-4">
                    <div className="flex items-center space-x-2 mb-3">
                      <span className="bg-gradient-to-r from-red-500 to-red-600 text-white text-xs px-3 py-1 rounded-full font-medium">
                        TECH-NEWS
                      </span>
                      <span className="text-muted-foreground text-xs">
                        {formatTimeAgo(article.publicationDate)}
                      </span>
                    </div>
                    <h3 className="font-bold text-foreground text-sm leading-tight line-clamp-3 group-hover:text-red-600 transition-colors">
                      {article.title}
                    </h3>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>

        {/* AI & Machine Learning Section - Enhanced */}
        {aiArticles.length > 0 && (
          <div className="mb-12">
            <div className="flex items-center space-x-3 mb-6">
              <div className="w-1 h-8 bg-purple-500 rounded-full"></div>
              <h2 className="text-2xl lg:text-3xl font-bold text-foreground">AI & Machine Learning</h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {aiArticles.map((article, index) => (
                <Link key={article._id} href={`/article/${article.slug}`} className="group">
                  <div className="bg-card rounded-xl overflow-hidden shadow-md hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1">
                    <div className="relative h-48">
                      <Image
                        src={
                          index === 0 ? "https://images.pexels.com/photos/3861969/pexels-photo-3861969.jpeg?auto=compress&cs=tinysrgb&h=650&w=940" :
                          index === 1 ? "https://images.pexels.com/photos/2599244/pexels-photo-2599244.jpeg?auto=compress&cs=tinysrgb&h=650&w=940" :
                          index === 2 ? "https://images.pexels.com/photos/1181677/pexels-photo-1181677.jpeg?auto=compress&cs=tinysrgb&h=650&w=940" :
                          "https://images.pexels.com/photos/3861969/pexels-photo-3861969.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
                        }
                        alt={article.title}
                        fill
                        className="object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                    </div>
                    <div className="p-4">
                      <div className="flex items-center space-x-2 mb-3">
                        <span className="bg-gradient-to-r from-purple-500 to-purple-600 text-white text-xs px-3 py-1 rounded-full font-medium">
                          AI
                        </span>
                        <span className="text-muted-foreground text-xs">
                          {formatTimeAgo(article.publicationDate)}
                        </span>
                      </div>
                      <h3 className="font-bold text-foreground text-sm leading-tight line-clamp-3 group-hover:text-purple-600 transition-colors">
                        {article.title}
                      </h3>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        )}

        {/* Software Development Section - Enhanced */}
        {softwareArticles.length > 0 && (
          <div className="mb-12">
            <div className="flex items-center space-x-3 mb-6">
              <div className="w-1 h-8 bg-blue-500 rounded-full"></div>
              <h2 className="text-2xl lg:text-3xl font-bold text-foreground">Software Development</h2>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Left side - Article list */}
              <div className="lg:col-span-1 space-y-6">
                <div className="space-y-4">
                  <div className="flex items-start space-x-3 p-4 bg-card rounded-xl shadow-md hover:shadow-lg transition-all duration-300">
                    <div className="relative w-20 h-16 rounded-lg overflow-hidden flex-shrink-0">
                      <Image
                        src="https://images.pexels.com/photos/2599244/pexels-photo-2599244.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
                        alt="Software Development"
                        fill
                        className="object-cover"
                      />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-bold text-foreground text-base leading-tight hover:text-blue-600 transition-colors line-clamp-2">
                        Next.js 15 introduces revolutionary performance improvements
                      </h3>
                      <div className="flex items-center space-x-2 mt-2">
                        <span className="bg-gradient-to-r from-blue-500 to-blue-600 text-white text-xs px-2 py-1 rounded-full font-medium">
                          MAIN
                        </span>
                        <span className="text-muted-foreground text-xs">
                          1 WEEK AGO
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Other Software articles */}
                <div className="space-y-4">
                  <div className="flex items-start space-x-3 p-4 bg-card rounded-xl shadow-md hover:shadow-lg transition-all duration-300">
                    <div className="relative w-20 h-16 rounded-lg overflow-hidden flex-shrink-0">
                      <Image
                        src="https://images.pexels.com/photos/1181677/pexels-photo-1181677.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
                        alt="Programming"
                        fill
                        className="object-cover"
                      />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-bold text-foreground text-base leading-tight hover:text-blue-600 transition-colors line-clamp-2">
                        GitHub Copilot X transforms developer productivity
                      </h3>
                      <div className="flex items-center space-x-2 mt-2">
                        <span className="bg-gradient-to-r from-green-500 to-green-600 text-white text-xs px-2 py-1 rounded-full font-medium">
                          DEV-NEWS
                        </span>
                        <span className="text-muted-foreground text-xs">
                          2 WEEKS AGO
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex items-start space-x-3 p-4 bg-card rounded-xl shadow-md hover:shadow-lg transition-all duration-300">
                    <div className="relative w-20 h-16 rounded-lg overflow-hidden flex-shrink-0">
                      <Image
                        src="https://images.pexels.com/photos/3861969/pexels-photo-3861969.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
                        alt="Cloud Computing"
                        fill
                        className="object-cover"
                      />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-bold text-foreground text-base leading-tight hover:text-blue-600 transition-colors line-clamp-2">
                        Cloud-native development patterns gain mainstream adoption
                      </h3>
                      <div className="flex items-center space-x-2 mt-2">
                        <span className="bg-gradient-to-r from-purple-500 to-purple-600 text-white text-xs px-2 py-1 rounded-full font-medium">
                          DEV-NEWS
                        </span>
                        <span className="text-muted-foreground text-xs">
                          3 WEEKS AGO
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex items-start space-x-3 p-4 bg-card rounded-xl shadow-md hover:shadow-lg transition-all duration-300">
                    <div className="relative w-20 h-16 rounded-lg overflow-hidden flex-shrink-0">
                      <Image
                        src="https://images.pexels.com/photos/2599244/pexels-photo-2599244.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
                        alt="Open Source"
                        fill
                        className="object-cover"
                      />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-bold text-foreground text-base leading-tight hover:text-blue-600 transition-colors line-clamp-2">
                        Open source security tools evolve to meet enterprise needs
                      </h3>
                      <div className="flex items-center space-x-2 mt-2">
                        <span className="bg-gradient-to-r from-red-500 to-red-600 text-white text-xs px-2 py-1 rounded-full font-medium">
                          DEV-NEWS
                        </span>
                        <span className="text-muted-foreground text-xs">
                          1 WEEK AGO
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Right side - Large Featured Software article */}
              <div className="lg:col-span-2">
                <div className="block group">
                  <div className="relative h-64 lg:h-96 rounded-2xl overflow-hidden shadow-xl hover:shadow-2xl transition-all duration-500">
                    <Image
                      src="https://images.pexels.com/photos/1181677/pexels-photo-1181677.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
                      alt="Software Development Revolution"
                      fill
                      className="object-cover group-hover:scale-105 transition-transform duration-700"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent" />
                    <div className="absolute top-4 left-4">
                      <span className="bg-blue-500/90 backdrop-blur-sm text-white text-sm font-medium px-3 py-1 rounded-full">
                        1 WEEK AGO
                      </span>
                    </div>
                    <div className="absolute bottom-6 left-6 right-6">
                      <h3 className="text-white font-bold text-xl lg:text-3xl leading-tight mb-4">
                        Low-code platforms revolutionize enterprise development
                      </h3>
                      <div className="flex items-center space-x-3 text-white/90">
                        <div className="w-10 h-10 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center">
                          <span className="text-sm">👤</span>
                        </div>
                        <div>
                          <span className="text-sm font-medium">Tech Reporter</span>
                          <span className="text-sm ml-2">• 0 comments</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Hardware & Semiconductors Section - New enhanced section */}
        <div className="mb-12">
          <div className="flex items-center space-x-3 mb-6">
            <div className="w-1 h-8 bg-orange-500 rounded-full"></div>
            <h2 className="text-2xl lg:text-3xl font-bold text-foreground">Hardware & Semiconductors</h2>
          </div>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left side - Hardware article list */}
            <div className="lg:col-span-1 space-y-6">
              <div className="space-y-4">
                <div className="flex items-start space-x-3 p-4 bg-card rounded-xl shadow-md hover:shadow-lg transition-all duration-300">
                  <div className="relative w-20 h-16 rounded-lg overflow-hidden flex-shrink-0">
                    <Image
                      src="https://images.pexels.com/photos/3861969/pexels-photo-3861969.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
                      alt="Semiconductor Technology"
                      fill
                      className="object-cover"
                    />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-foreground text-base leading-tight hover:text-orange-600 transition-colors line-clamp-2">
                      TSMC announces breakthrough 2nm chip manufacturing process
                    </h3>
                    <div className="flex items-center space-x-2 mt-2">
                      <span className="bg-gradient-to-r from-orange-500 to-orange-600 text-white text-xs px-2 py-1 rounded-full font-medium">
                        MAIN
                      </span>
                      <span className="text-muted-foreground text-xs">
                        2 WEEKS AGO
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex items-start space-x-3 p-4 bg-card rounded-xl shadow-md hover:shadow-lg transition-all duration-300">
                  <div className="relative w-20 h-16 rounded-lg overflow-hidden flex-shrink-0">
                    <Image
                      src="https://images.pexels.com/photos/2599244/pexels-photo-2599244.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
                      alt="GPU Technology"
                      fill
                      className="object-cover"
                    />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-foreground text-base leading-tight hover:text-orange-600 transition-colors line-clamp-2">
                      NVIDIA's next-gen GPUs promise 10x AI performance boost
                    </h3>
                    <div className="flex items-center space-x-2 mt-2">
                      <span className="bg-gradient-to-r from-green-500 to-green-600 text-white text-xs px-2 py-1 rounded-full font-medium">
                        HARDWARE-NEWS
                      </span>
                      <span className="text-muted-foreground text-xs">
                        1 MONTH AGO
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex items-start space-x-3 p-4 bg-card rounded-xl shadow-md hover:shadow-lg transition-all duration-300">
                  <div className="relative w-20 h-16 rounded-lg overflow-hidden flex-shrink-0">
                    <Image
                      src="https://images.pexels.com/photos/1181677/pexels-photo-1181677.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
                      alt="Quantum Computing"
                      fill
                      className="object-cover"
                    />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-foreground text-base leading-tight hover:text-orange-600 transition-colors line-clamp-2">
                      Quantum computing chips reach commercial viability milestone
                    </h3>
                    <div className="flex items-center space-x-2 mt-2">
                      <span className="bg-gradient-to-r from-purple-500 to-purple-600 text-white text-xs px-2 py-1 rounded-full font-medium">
                        HARDWARE-NEWS
                      </span>
                      <span className="text-muted-foreground text-xs">
                        3 WEEKS AGO
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex items-start space-x-3 p-4 bg-card rounded-xl shadow-md hover:shadow-lg transition-all duration-300">
                  <div className="relative w-20 h-16 rounded-lg overflow-hidden flex-shrink-0">
                    <Image
                      src="https://images.pexels.com/photos/3861969/pexels-photo-3861969.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
                      alt="Mobile Processors"
                      fill
                      className="object-cover"
                    />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-foreground text-base leading-tight hover:text-orange-600 transition-colors line-clamp-2">
                      Apple's M4 chip sets new performance benchmarks
                    </h3>
                    <div className="flex items-center space-x-2 mt-2">
                      <span className="bg-gradient-to-r from-blue-500 to-blue-600 text-white text-xs px-2 py-1 rounded-full font-medium">
                        HARDWARE-NEWS
                      </span>
                      <span className="text-muted-foreground text-xs">
                        1 WEEK AGO
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Right side - Large Featured Hardware article */}
            <div className="lg:col-span-2">
              <div className="block group">
                <div className="relative h-64 lg:h-96 rounded-2xl overflow-hidden shadow-xl hover:shadow-2xl transition-all duration-500">
                  <Image
                    src="https://images.pexels.com/photos/2599244/pexels-photo-2599244.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
                    alt="Semiconductor Manufacturing"
                    fill
                    className="object-cover group-hover:scale-105 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent" />
                  <div className="absolute top-4 left-4">
                    <span className="bg-orange-500/90 backdrop-blur-sm text-white text-sm font-medium px-3 py-1 rounded-full">
                      2 WEEKS AGO
                    </span>
                  </div>
                  <div className="absolute bottom-6 left-6 right-6">
                    <h3 className="text-white font-bold text-xl lg:text-3xl leading-tight mb-4">
                      Global semiconductor shortage drives innovation in chip design
                    </h3>
                    <div className="flex items-center space-x-3 text-white/90">
                      <div className="w-10 h-10 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center">
                        <span className="text-sm">👤</span>
                      </div>
                      <div>
                        <span className="text-sm font-medium">Tech Reporter</span>
                        <span className="text-sm ml-2">• 0 comments</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Startups & Innovation Section - Enhanced */}
        {startupArticles.length > 0 && (
          <div className="mb-12">
            <div className="flex items-center space-x-3 mb-6">
              <div className="w-1 h-8 bg-green-500 rounded-full"></div>
              <h2 className="text-2xl lg:text-3xl font-bold text-foreground">Startups & Innovation</h2>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Left side - Article list */}
              <div className="lg:col-span-1 space-y-4">
                {startupArticles.slice(0, 3).map((article, index) => (
                  <div key={article._id} className="flex items-start space-x-3 p-4 bg-card rounded-xl shadow-md hover:shadow-lg transition-all duration-300">
                    <div className="relative w-16 h-16 rounded-lg overflow-hidden flex-shrink-0">
                      <Image
                        src={
                          index === 0 ? "https://images.pexels.com/photos/3861969/pexels-photo-3861969.jpeg?auto=compress&cs=tinysrgb&h=650&w=940" :
                          index === 1 ? "https://images.pexels.com/photos/1181677/pexels-photo-1181677.jpeg?auto=compress&cs=tinysrgb&h=650&w=940" :
                          "https://images.pexels.com/photos/2599244/pexels-photo-2599244.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
                        }
                        alt={article.title}
                        fill
                        className="object-cover"
                      />
                    </div>
                    <div className="flex-1">
                      <Link href={`/article/${article.slug}`}>
                        <h3 className="font-bold text-foreground text-sm leading-tight hover:text-green-600 transition-colors line-clamp-2">
                          {article.title}
                        </h3>
                      </Link>
                      <div className="flex items-center space-x-2 mt-1">
                        <span className="bg-gradient-to-r from-green-500 to-green-600 text-white text-xs px-2 py-1 rounded-full font-medium">
                          STARTUP
                        </span>
                        <span className="text-muted-foreground text-xs">
                          {formatTimeAgo(article.publicationDate)}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Right side - Featured Startup article */}
              <div className="lg:col-span-2">
                <div className="block group">
                  <div className="relative h-64 lg:h-80 rounded-2xl overflow-hidden shadow-xl hover:shadow-2xl transition-all duration-500">
                    <Image
                      src="https://images.pexels.com/photos/3861969/pexels-photo-3861969.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
                      alt="Tech Startup Innovation"
                      fill
                      className="object-cover group-hover:scale-105 transition-transform duration-700"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent" />
                    <div className="absolute top-4 left-4">
                      <span className="bg-green-500/90 backdrop-blur-sm text-white text-sm font-medium px-3 py-1 rounded-full">
                        3 WEEKS AGO
                      </span>
                    </div>
                    <div className="absolute bottom-6 left-6 right-6">
                      <h3 className="text-white font-bold text-xl lg:text-2xl leading-tight mb-4">
                        AI startups secure record $50B in venture funding this quarter
                      </h3>
                      <div className="flex items-center space-x-3 text-white/90">
                        <div className="w-10 h-10 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center">
                          <span className="text-sm">👤</span>
                        </div>
                        <div>
                          <span className="text-sm font-medium">Tech Reporter</span>
                          <span className="text-sm ml-2">• 0 comments</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Latest & Popular Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Latest Articles */}
          <div>
            <div className="flex items-center space-x-3 mb-6">
              <div className="w-1 h-8 bg-green-500 rounded-full"></div>
              <h2 className="text-2xl font-bold text-foreground">Latest</h2>
            </div>
            <div className="space-y-4">
              {latestArticles.map((article, index) => (
                <Link key={article._id} href={`/article/${article.slug}`} className="block group">
                  <div className="flex items-start space-x-4 p-4 bg-card rounded-xl shadow-md hover:shadow-lg transition-all duration-300">
                    <div className="relative w-20 h-16 rounded-lg overflow-hidden flex-shrink-0">
                      <Image
                        src={
                          index === 0 ? "https://images.pexels.com/photos/3861969/pexels-photo-3861969.jpeg?auto=compress&cs=tinysrgb&h=650&w=940" :
                          index === 1 ? "https://images.pexels.com/photos/2599244/pexels-photo-2599244.jpeg?auto=compress&cs=tinysrgb&h=650&w=940" :
                          "https://images.pexels.com/photos/1181677/pexels-photo-1181677.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
                        }
                        alt={article.title}
                        fill
                        className="object-cover"
                      />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-bold text-foreground text-base leading-tight group-hover:text-green-600 transition-colors line-clamp-2">
                        {article.title}
                      </h3>
                      <div className="flex items-center space-x-2 mt-2">
                        <span className="bg-gradient-to-r from-green-500 to-green-600 text-white text-xs px-2 py-1 rounded-full font-medium">
                          TECH
                        </span>
                        <span className="text-muted-foreground text-xs">
                          {formatTimeAgo(article.publicationDate)}
                        </span>
                      </div>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>

          {/* Popular Articles */}
          <div>
            <div className="flex items-center space-x-3 mb-6">
              <div className="w-1 h-8 bg-orange-500 rounded-full"></div>
              <h2 className="text-2xl font-bold text-foreground">Popular</h2>
            </div>
            <div className="space-y-4">
              {popularArticles.map((article, index) => (
                <div key={index} className="flex items-start space-x-4 p-4 bg-card rounded-xl shadow-md hover:shadow-lg transition-all duration-300 group cursor-pointer">
                  <div className="relative w-20 h-16 rounded-lg overflow-hidden flex-shrink-0">
                    <Image
                      src={
                        index === 0 ? "https://images.pexels.com/photos/3861969/pexels-photo-3861969.jpeg?auto=compress&cs=tinysrgb&h=650&w=940" :
                        index === 1 ? "https://images.pexels.com/photos/2599244/pexels-photo-2599244.jpeg?auto=compress&cs=tinysrgb&h=650&w=940" :
                        "https://images.pexels.com/photos/1181677/pexels-photo-1181677.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
                      }
                      alt={article.title}
                      fill
                      className="object-cover"
                    />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-foreground text-base leading-tight group-hover:text-orange-600 transition-colors line-clamp-2">
                      {article.title}
                    </h3>
                    <div className="flex items-center space-x-2 mt-2">
                      <span className="bg-gradient-to-r from-orange-500 to-orange-600 text-white text-xs px-2 py-1 rounded-full font-medium">
                        TECH
                      </span>
                      <span className="text-muted-foreground text-xs">
                        {article.time}
                      </span>
                      <span className="text-muted-foreground text-xs">
                        {article.views} views
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}








