"use client";
import { useQuery, useMutation } from "convex/react";
import { api } from "@/convex/_generated/api";
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export function DebugArticle({ slug }: { slug: string }) {
  const debug = useQuery(api.articles.getArticleForDebug, { slug });
  const findQuery = useQuery(api.articles.findArticlesContaining, { needle: "k17bxeyykjas7nnvz5374pt19x7nsp8f" });
  const fix = useMutation(api.articles.fixArticle);
  const [needle] = useState("k17bxeyykjas7nnvz5374pt19x7nsp8f");
  const [isFixing, setIsFixing] = useState(false);

  useEffect(() => {
    console.log("Debug component mounted, slug:", slug);
    console.log("Debug query result:", debug);
    console.log("Find query result:", findQuery);
  }, [debug, findQuery, slug]);

  if (debug === undefined) {
    console.log("Debug is undefined, still loading...");
    return <div>Loading debug info...</div>;
  }
  if (debug === null) {
    console.log("Debug is null, article not found");
    return <div>Article not found</div>;
  }

  const { article, featuredImageUrl, storageMeta } = debug;
  console.log("Article data:", article);
  console.log("Featured image URL:", featuredImageUrl);
  console.log("Storage meta:", storageMeta);

  async function handleSanitize() {
    setIsFixing(true);
    try {
      // Remove the random string from content and remove from tags
      const sanitized = (article.content || "").replaceAll(needle, "").trim();
      const newTags = Array.isArray(article.tags) ? article.tags.filter((t: string) => t !== needle) : [];
      await fix({ articleId: article._id, newTags, newContent: sanitized });
      window.location.reload();
    } catch (error) {
      console.error("Error fixing article:", error);
    } finally {
      setIsFixing(false);
    }
  }

  function handleFindAll() {
    if (findQuery) {
      alert(`Found ${findQuery.length} articles containing the problematic string`);
    }
  }

  return (
    <div className="space-y-6 p-6">
      <Card>
        <CardHeader>
          <CardTitle>Debug Article: {article.title}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <strong>Slug:</strong> {article.slug}
          </div>
          <div>
            <strong>Featured image URL:</strong> {featuredImageUrl ?? "null (missing)"}
          </div>
          <div>
            <strong>Storage metadata:</strong>
            <pre className="bg-gray-100 p-2 rounded text-sm overflow-auto">
              {JSON.stringify(storageMeta, null, 2)}
            </pre>
          </div>
          <div>
            <strong>Content (first 500 chars):</strong>
            <pre className="bg-gray-100 p-2 rounded text-sm overflow-auto">
              {(article.content || "").slice(0, 500)}
            </pre>
          </div>
          <div>
            <strong>Tags:</strong>
            <pre className="bg-gray-100 p-2 rounded text-sm">
              {JSON.stringify(article.tags)}
            </pre>
          </div>
          <div className="flex gap-2">
            <Button 
              onClick={handleSanitize} 
              disabled={isFixing}
              variant="destructive"
            >
              {isFixing ? "Fixing..." : "Remove problematic string from this article"}
            </Button>
            <Button onClick={handleFindAll} variant="outline">
              Find all affected articles
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

