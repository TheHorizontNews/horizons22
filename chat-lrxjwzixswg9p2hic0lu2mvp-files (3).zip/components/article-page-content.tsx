





"use client";

import { usePreloadedQuery } from "convex/react";
import { api } from "@/convex/_generated/api";
import { Preloaded } from "convex/react";
import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import ConvexImage from "./convex-image";

interface ArticlePageContentProps {
  preloadedData: Preloaded<typeof api.articles.getArticleWithExtras>;
}

export default function ArticlePageContent({ preloadedData }: ArticlePageContentProps) {
  const data = usePreloadedQuery(preloadedData);
  
  if (!data.article) {
    notFound();
  }

  const { article, related, prev, next, author } = data;

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-4xl mx-auto px-4 py-8">
        {/* Breadcrumb Navigation */}
        <nav className="flex items-center space-x-2 text-sm text-muted-foreground mb-6">
          <Link href="/" className="hover:text-primary transition-colors">Home</Link>
          <span>/</span>
          <span className="text-foreground">{article.title}</span>
        </nav>

        {/* Article Title */}
        <h1 className="text-4xl md:text-5xl font-bold text-foreground mb-6 leading-tight">
          {article.title}
        </h1>

        {/* Featured Image */}
        {article.featuredImageStorageId && (
          <div className="relative aspect-video mb-8 rounded-lg overflow-hidden">
            <ConvexImage
              storageId={article.featuredImageStorageId}
              alt={article.title}
              width={800}
              height={450}
              fill
              className="object-cover"
              priority
            />
          </div>
        )}

        {/* Article Summary/Subtitle */}
        {article.summary && (
          <div className="mb-8">
            <h2 className="text-2xl font-semibold text-foreground mb-4">
              {article.summary}
            </h2>
          </div>
        )}

        {/* Article Meta */}
        <div className="flex items-center space-x-4 text-sm text-muted-foreground mb-8 pb-6 border-b border-border">
          <span className="bg-primary text-primary-foreground px-3 py-1 rounded text-xs font-medium uppercase">
            {article.category === "k17bxeyykjas7nnvz5374pt19x7nsp8f" ? "Politics" : 
             article.category === "k171fvm68h6edtynm2b5fphgkx7ns212" ? "Finance" :
             article.category === "k1715g0yc21x31npv2g1yerwt57nrc31" ? "Sports" :
             article.category === "k177fen9hqrjhtrcbce7p2qac57nrkxe" ? "Tech" :
             article.category}
          </span>
          <span>{new Date(article.publicationDate).toLocaleDateString('en-US', { 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric' 
          })}</span>
          <span>By {author?.name || 'Horizons Times'}</span>
        </div>

        {/* Article Content */}
        <div className="prose prose-lg max-w-none mb-12 article-content">
          <div 
            className="text-foreground leading-relaxed space-y-6"
            dangerouslySetInnerHTML={{ __html: article.content }}
            style={{ 
              direction: 'ltr',
              textAlign: 'left',
              unicodeBidi: 'normal'
            }}
          />
        </div>

        {/* Tags and Share */}
        <div className="border-t border-border pt-6 mb-8">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div className="flex items-center space-x-2">
              <span className="text-sm text-muted-foreground">Tags:</span>
              {article.tags && article.tags.length > 0 ? (
                <div className="flex flex-wrap gap-2">
                  {article.tags.map((tag, index) => (
                    <span key={index} className="bg-muted text-muted-foreground px-3 py-1 rounded text-sm">
                      {tag}
                    </span>
                  ))}
                </div>
              ) : (
                <span className="bg-muted text-muted-foreground px-3 py-1 rounded text-sm">
                  {article.category === "k17bxeyykjas7nnvz5374pt19x7nsp8f" ? "politics" : 
                   article.category === "k171fvm68h6edtynm2b5fphgkx7ns212" ? "finance" :
                   article.category === "k1715g0yc21x31npv2g1yerwt57nrc31" ? "sports" :
                   article.category === "k177fen9hqrjhtrcbce7p2qac57nrkxe" ? "tech" :
                   "news"}
                </span>
              )}
            </div>
            <div className="flex items-center space-x-2">
              <span className="text-sm text-muted-foreground">Share:</span>
              <div className="flex space-x-2">
                <button className="text-blue-600 hover:text-blue-700 text-sm font-medium transition-colors">
                  Facebook
                </button>
                <button className="text-blue-400 hover:text-blue-500 text-sm font-medium transition-colors">
                  Twitter
                </button>
                <button className="text-blue-700 hover:text-blue-800 text-sm font-medium transition-colors">
                  LinkedIn
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Author Section */}
        <div className="bg-muted/50 rounded-lg p-6 mb-8">
          <div className="flex items-start space-x-4">
            <div className="relative w-16 h-16 rounded-full overflow-hidden bg-primary/10 flex-shrink-0">
              <div className="w-full h-full flex items-center justify-center text-primary font-bold text-xl">
                {(author?.name || 'HT').charAt(0).toUpperCase()}
              </div>
            </div>
            <div>
              <h4 className="font-semibold text-foreground text-lg mb-1">
                {author?.name || 'Horizons Times'}
              </h4>
              <p className="text-muted-foreground text-sm">
                Author in the field of digital and science.
              </p>
            </div>
          </div>
        </div>

        {/* Previous/Next Article Navigation */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
          {prev && (
            <Link 
              href={`/article/${prev.slug}`}
              className="group flex items-center space-x-4 p-4 rounded-lg border border-border hover:bg-muted/50 transition-colors"
            >
              <div className="relative w-20 h-16 flex-shrink-0 rounded overflow-hidden">
                {prev.featuredImageStorageId ? (
                  <ConvexImage
                    storageId={prev.featuredImageStorageId}
                    alt={prev.title}
                    width={80}
                    height={64}
                    fill
                    className="object-cover"
                  />
                ) : (
                  <Image
                    src="/placeholder-article.jpg"
                    alt={prev.title}
                    fill
                    className="object-cover"
                  />
                )}
              </div>
              <div className="flex-1">
                <p className="text-xs text-muted-foreground mb-1">Prev Article</p>
                <h3 className="font-semibold text-foreground group-hover:text-primary transition-colors line-clamp-2">
                  {prev.title}
                </h3>
              </div>
            </Link>
          )}
          
          {next && (
            <Link 
              href={`/article/${next.slug}`}
              className="group flex items-center space-x-4 p-4 rounded-lg border border-border hover:bg-muted/50 transition-colors"
            >
              <div className="flex-1 text-right">
                <p className="text-xs text-muted-foreground mb-1">Next Article</p>
                <h3 className="font-semibold text-foreground group-hover:text-primary transition-colors line-clamp-2">
                  {next.title}
                </h3>
              </div>
              <div className="relative w-20 h-16 flex-shrink-0 rounded overflow-hidden">
                {next.featuredImageStorageId ? (
                  <ConvexImage
                    storageId={next.featuredImageStorageId}
                    alt={next.title}
                    width={80}
                    height={64}
                    fill
                    className="object-cover"
                  />
                ) : (
                  <Image
                    src="/placeholder-article.jpg"
                    alt={next.title}
                    fill
                    className="object-cover"
                  />
                )}
              </div>
            </Link>
          )}
        </div>

        {/* Comments Section */}
        <div className="border-t border-border pt-8 mb-8">
          <h4 className="text-xl font-semibold text-foreground mb-6">Comments (0)</h4>
          
          <div className="bg-muted/30 rounded-lg p-6">
            <h5 className="font-medium text-foreground mb-4">Leave a Comment</h5>
            <form className="space-y-4">
              <div>
                <textarea 
                  placeholder="Write your comment here..."
                  className="w-full p-3 border border-border rounded-lg bg-background text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/50"
                  rows={4}
                />
              </div>
              <button 
                type="submit"
                className="bg-primary text-primary-foreground px-6 py-2 rounded-lg hover:bg-primary/90 transition-colors font-medium"
              >
                Send
              </button>
            </form>
          </div>
        </div>

        {/* Related Articles */}
        {related.length > 0 && (
          <div className="border-t border-border pt-8">
            <h2 className="text-2xl font-bold text-foreground mb-6">Related Articles</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {related.map((relatedArticle) => (
                <Link 
                  key={relatedArticle._id} 
                  href={`/article/${relatedArticle.slug}`}
                  className="group flex space-x-4 p-4 rounded-lg hover:bg-muted/50 transition-colors border border-border"
                >
                  <div className="relative w-24 h-16 flex-shrink-0 rounded overflow-hidden">
                    {relatedArticle.featuredImageStorageId ? (
                      <ConvexImage
                        storageId={relatedArticle.featuredImageStorageId}
                        alt={relatedArticle.title}
                        width={96}
                        height={64}
                        fill
                        className="object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                    ) : (
                      <Image
                        src="/placeholder-article.jpg"
                        alt={relatedArticle.title}
                        fill
                        className="object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                    )}
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold text-foreground group-hover:text-primary transition-colors line-clamp-2 mb-1">
                      {relatedArticle.title}
                    </h3>
                    <span className="text-sm text-muted-foreground">
                      {new Date(relatedArticle.publicationDate).toLocaleDateString()}
                    </span>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}


























