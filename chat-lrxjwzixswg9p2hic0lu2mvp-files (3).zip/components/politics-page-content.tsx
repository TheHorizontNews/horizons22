




"use client";

import { usePreloadedQuery } from "convex/react";
import { api } from "@/convex/_generated/api";
import { Preloaded } from "convex/react";
import Image from "next/image";
import Link from "next/link";

interface PoliticsPageContentProps {
  preloadedData: Preloaded<typeof api.articles.getCategoryPageData>;
}

export default function PoliticsPageContent({ preloadedData }: PoliticsPageContentProps) {
  const { articles: categoryArticles, categories, category: politicsCategory } = usePreloadedQuery(preloadedData);
  
  // Remove console logs for better performance
  // Use the articles directly from the optimized query
  const allArticles = categoryArticles;
  
  // Find the politics category
  // console.log('Politics category:', politicsCategory);
  
  // Filter politics articles by category ID - if no politics category found, use all articles as fallback
  const politicsArticles = politicsCategory 
    ? allArticles.filter(article => article.category === politicsCategory._id)
    : allArticles.slice(0, 15); // Use first 15 articles as fallback
  
  // console.log('Politics articles:', politicsArticles.length);
  
  // If we don't have enough politics articles, use all articles as fallback for secondary sections
  const fallbackArticles = politicsArticles.length < 10 ? allArticles : politicsArticles; // Reduced from 15 to 10
  
  // Get featured articles for hero section (first 6) - prioritize politics articles
  const heroArticles = politicsArticles.length >= 6 
    ? politicsArticles.slice(0, 6)
    : [...politicsArticles, ...allArticles.filter(a => !politicsArticles.includes(a))].slice(0, 6);
  
  const mainFeatured = heroArticles[0];
  const sideArticles = heroArticles.slice(1, 6);

  // Get trending articles (next 4) - use fallback if needed
  const trendingArticles = fallbackArticles.slice(6, 10);

  // Categorize articles by political topics - use fallback articles
  const usaArticles = fallbackArticles.filter(article => 
    article.title.toLowerCase().includes('usa') || 
    article.title.toLowerCase().includes('america') ||
    article.title.toLowerCase().includes('biden') ||
    article.title.toLowerCase().includes('trump') ||
    article.title.toLowerCase().includes('congress') ||
    article.title.toLowerCase().includes('senate') ||
    article.title.toLowerCase().includes('government') ||
    article.title.toLowerCase().includes('political')
  ).slice(0, 4);

  const euArticles = fallbackArticles.filter(article => 
    article.title.toLowerCase().includes('eu') || 
    article.title.toLowerCase().includes('europe') ||
    article.title.toLowerCase().includes('parliament') ||
    article.title.toLowerCase().includes('brussels') ||
    article.title.toLowerCase().includes('germany') ||
    article.title.toLowerCase().includes('france') ||
    article.title.toLowerCase().includes('political')
  ).slice(0, 4);

  const ukArticles = fallbackArticles.filter(article => 
    article.title.toLowerCase().includes('uk') || 
    article.title.toLowerCase().includes('britain') ||
    article.title.toLowerCase().includes('london') ||
    article.title.toLowerCase().includes('parliament') ||
    article.title.toLowerCase().includes('prime minister') ||
    article.title.toLowerCase().includes('government')
  ).slice(0, 3);

  const internationalArticles = fallbackArticles.filter(article => 
    article.title.toLowerCase().includes('international') || 
    article.title.toLowerCase().includes('global') ||
    article.title.toLowerCase().includes('china') ||
    article.title.toLowerCase().includes('russia') ||
    article.title.toLowerCase().includes('ukraine') ||
    article.title.toLowerCase().includes('political')
  ).slice(0, 2);

  // Latest articles - use fallback
  const latestArticles = fallbackArticles.slice(0, 3);

  // Popular articles (mock data for now)
  const popularArticles = [
    { title: "Germany defends AfD extremist label after U.S. backlash over 'tyranny' claims", time: "3 MONTHS AGO", views: "290" },
    { title: "Judge allows DOGE team limited access to sensitive Treasury data", time: "3 MONTHS AGO", views: "290" },
    { title: "Political developments shape national agenda", time: "3 MONTHS AGO", views: "290" }
  ];

  const formatTimeAgo = (date: string | number) => {
    const now = new Date();
    const articleDate = new Date(date);
    const diffInMonths = Math.floor((now.getTime() - articleDate.getTime()) / (1000 * 60 * 60 * 24 * 30));
    
    if (diffInMonths >= 1) {
      return `${diffInMonths} MONTHS AGO`;
    }
    const diffInDays = Math.floor((now.getTime() - articleDate.getTime()) / (1000 * 60 * 60 * 24));
    return `${diffInDays} DAYS AGO`;
  };

  console.log('EU articles found:', euArticles.length);
  console.log('EU articles:', euArticles.map(a => a.title));

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section - More organic and stylish */}
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Enhanced Hero Grid with better mobile layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 mb-12">
          {/* Left Column - Mobile: full width, Desktop: 3 columns */}
          <div className="lg:col-span-3 space-y-4">
            {sideArticles.slice(0, 2).map((article, index) => (
              <Link key={article._id} href={`/article/${article.slug}`} className="block">
                <div className="relative h-48 lg:h-40 rounded-xl overflow-hidden group shadow-lg hover:shadow-xl transition-all duration-300">
                  <Image
                    src={index === 0 ? "/government-building.jpg" : "/politics-meeting.jpg"}
                    alt={article.title}
                    fill
                    className="object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent" />
                  <div className="absolute top-3 left-3">
                    <span className="bg-white/20 backdrop-blur-sm text-white text-xs font-medium px-2 py-1 rounded-full">
                      {formatTimeAgo(article.publicationDate)}
                    </span>
                  </div>
                  <div className="absolute bottom-3 left-3 right-3">
                    <h3 className="text-white font-bold text-sm lg:text-xs leading-tight line-clamp-3">
                      {article.title}
                    </h3>
                  </div>
                </div>
              </Link>
            ))}
            {/* Third article - hidden on mobile to save space */}
            {sideArticles[2] && (
              <Link href={`/article/${sideArticles[2].slug}`} className="hidden lg:block">
                <div className="relative h-40 rounded-xl overflow-hidden group shadow-lg hover:shadow-xl transition-all duration-300">
                  <Image
                    src="/microchips-geopolitics.jpg"
                    alt={sideArticles[2].title}
                    fill
                    className="object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent" />
                  <div className="absolute top-3 left-3">
                    <span className="bg-white/20 backdrop-blur-sm text-white text-xs font-medium px-2 py-1 rounded-full">
                      {formatTimeAgo(sideArticles[2].publicationDate)}
                    </span>
                  </div>
                  <div className="absolute bottom-3 left-3 right-3">
                    <h3 className="text-white font-bold text-xs leading-tight line-clamp-3">
                      {sideArticles[2].title}
                    </h3>
                  </div>
                </div>
              </Link>
            )}
          </div>

          {/* Center - Main featured article */}
          {mainFeatured && (
            <div className="lg:col-span-6">
              <Link href={`/article/${mainFeatured.slug}`} className="block group">
                <div className="relative h-64 lg:h-[500px] rounded-2xl overflow-hidden shadow-2xl hover:shadow-3xl transition-all duration-500">
                  <Image
                    src="/international-politics.jpg"
                    alt={mainFeatured.title}
                    fill
                    className="object-cover group-hover:scale-105 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent" />
                  <div className="absolute top-4 left-4">
                    <span className="bg-red-500/90 backdrop-blur-sm text-white text-sm font-medium px-3 py-1 rounded-full">
                      {formatTimeAgo(mainFeatured.publicationDate)}
                    </span>
                  </div>
                  <div className="absolute bottom-6 left-6 right-6">
                    <h2 className="text-white font-bold text-xl lg:text-4xl leading-tight mb-4">
                      {mainFeatured.title}
                    </h2>
                    <div className="flex items-center space-x-3 text-white/90">
                      <div className="w-10 h-10 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center">
                        <span className="text-sm">👤</span>
                      </div>
                      <div>
                        <span className="text-sm font-medium">Political Correspondent</span>
                        <span className="text-sm ml-2">• 0 comments</span>
                      </div>
                    </div>
                  </div>
                </div>
              </Link>
            </div>
          )}

          {/* Right Column - Mobile: full width, Desktop: 3 columns */}
          <div className="lg:col-span-3 space-y-4">
            {sideArticles.slice(3, 5).map((article, index) => (
              <Link key={article._id} href={`/article/${article.slug}`} className="block">
                <div className="relative h-48 lg:h-40 rounded-xl overflow-hidden group shadow-lg hover:shadow-xl transition-all duration-300">
                  <Image
                    src={index === 0 ? "/usa-politics.jpg" : "/uk-politics.jpg"}
                    alt={article.title}
                    fill
                    className="object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent" />
                  <div className="absolute top-3 left-3">
                    <span className="bg-white/20 backdrop-blur-sm text-white text-xs font-medium px-2 py-1 rounded-full">
                      {formatTimeAgo(article.publicationDate)}
                    </span>
                  </div>
                  <div className="absolute bottom-3 left-3 right-3">
                    <h3 className="text-white font-bold text-sm lg:text-xs leading-tight line-clamp-3">
                      {article.title}
                    </h3>
                  </div>
                </div>
              </Link>
            ))}
            {/* Third article - hidden on mobile */}
            {sideArticles[5] && (
              <Link href={`/article/${sideArticles[5].slug}`} className="hidden lg:block">
                <div className="relative h-40 rounded-xl overflow-hidden group shadow-lg hover:shadow-xl transition-all duration-300">
                  <Image
                    src="/european-flags.jpg"
                    alt={sideArticles[5].title}
                    fill
                    className="object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent" />
                  <div className="absolute top-3 left-3">
                    <span className="bg-white/20 backdrop-blur-sm text-white text-xs font-medium px-2 py-1 rounded-full">
                      {formatTimeAgo(sideArticles[5].publicationDate)}
                    </span>
                  </div>
                  <div className="absolute bottom-3 left-3 right-3">
                    <h3 className="text-white font-bold text-xs leading-tight line-clamp-3">
                      {sideArticles[5].title}
                    </h3>
                  </div>
                </div>
              </Link>
            )}
            {/* Fourth article - new addition to fill empty space */}
            <div className="hidden lg:block">
              <div className="relative h-40 rounded-xl overflow-hidden group shadow-lg hover:shadow-xl transition-all duration-300">
                <Image
                  src="/chancellor.jpg"
                  alt="Political leadership meeting"
                  fill
                  className="object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent" />
                <div className="absolute top-3 left-3">
                  <span className="bg-white/20 backdrop-blur-sm text-white text-xs font-medium px-2 py-1 rounded-full">
                    2 DAYS AGO
                  </span>
                </div>
                <div className="absolute bottom-3 left-3 right-3">
                  <h3 className="text-white font-bold text-xs leading-tight line-clamp-3">
                    Political developments shape national agenda
                  </h3>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Trending this week - Enhanced styling */}
        <div className="mb-12">
          <div className="flex items-center space-x-3 mb-6">
            <div className="w-1 h-8 bg-red-500 rounded-full"></div>
            <h2 className="text-2xl lg:text-3xl font-bold text-foreground">Trending this week</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {trendingArticles.map((article, index) => (
              <Link key={article._id} href={`/article/${article.slug}`} className="group">
                <div className="bg-card rounded-xl overflow-hidden shadow-md hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1">
                  <div className="relative h-48">
                    <Image
                      src={
                        index === 0 ? "/government-building.jpg" :
                        index === 1 ? "/politics-meeting.jpg" :
                        index === 2 ? "/usa-politics.jpg" :
                        "/eu-parliament.jpg"
                      }
                      alt={article.title}
                      fill
                      className="object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                  </div>
                  <div className="p-4">
                    <div className="flex items-center space-x-2 mb-3">
                      <span className="bg-gradient-to-r from-red-500 to-red-600 text-white text-xs px-3 py-1 rounded-full font-medium">
                        POLITICS-NEWS
                      </span>
                      <span className="text-muted-foreground text-xs">
                        {formatTimeAgo(article.publicationDate)}
                      </span>
                    </div>
                    <h3 className="font-bold text-foreground text-sm leading-tight line-clamp-3 group-hover:text-red-600 transition-colors">
                      {article.title}
                    </h3>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>

        {/* USA Politics Section - Enhanced */}
        {usaArticles.length > 0 && (
          <div className="mb-12">
            <div className="flex items-center space-x-3 mb-6">
              <div className="w-1 h-8 bg-blue-500 rounded-full"></div>
              <h2 className="text-2xl lg:text-3xl font-bold text-foreground">USA Politics</h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {usaArticles.map((article, index) => (
                <Link key={article._id} href={`/article/${article.slug}`} className="group">
                  <div className="bg-card rounded-xl overflow-hidden shadow-md hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1">
                    <div className="relative h-48">
                      <Image
                        src={
                          index === 0 ? "/usa-politics.jpg" :
                          index === 1 ? "/government-building.jpg" :
                          index === 2 ? "/politics-meeting.jpg" :
                          "/international-politics.jpg"
                        }
                        alt={article.title}
                        fill
                        className="object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                    </div>
                    <div className="p-4">
                      <div className="flex items-center space-x-2 mb-3">
                        <span className="bg-gradient-to-r from-blue-500 to-blue-600 text-white text-xs px-3 py-1 rounded-full font-medium">
                          USA
                        </span>
                        <span className="text-muted-foreground text-xs">
                          {formatTimeAgo(article.publicationDate)}
                        </span>
                      </div>
                      <h3 className="font-bold text-foreground text-sm leading-tight line-clamp-3 group-hover:text-blue-600 transition-colors">
                        {article.title}
                      </h3>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        )}

        {/* EU Politics Section - Enhanced */}
        {euArticles.length > 0 && (
          <div className="mb-12">
            <div className="flex items-center space-x-3 mb-6">
              <div className="w-1 h-8 bg-yellow-500 rounded-full"></div>
              <h2 className="text-2xl lg:text-3xl font-bold text-foreground">EU Politics</h2>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Left side - Article list */}
              <div className="lg:col-span-1 space-y-6">
                <div className="space-y-4">
                  <div className="flex items-start space-x-3 p-4 bg-card rounded-xl shadow-md hover:shadow-lg transition-all duration-300">
                    <div className="relative w-20 h-16 rounded-lg overflow-hidden flex-shrink-0">
                      <Image
                        src="/eu-building.jpg"
                        alt="EU Politics"
                        fill
                        className="object-cover"
                      />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-bold text-foreground text-base leading-tight hover:text-yellow-600 transition-colors line-clamp-2">
                        EU Parliament passes new digital rights legislation
                      </h3>
                      <div className="flex items-center space-x-2 mt-2">
                        <span className="bg-gradient-to-r from-yellow-500 to-yellow-600 text-white text-xs px-2 py-1 rounded-full font-medium">
                          MAIN
                        </span>
                        <span className="text-muted-foreground text-xs">
                          2 MONTHS AGO
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Other EU articles */}
                <div className="space-y-4">
                  <div className="flex items-start space-x-3 p-4 bg-card rounded-xl shadow-md hover:shadow-lg transition-all duration-300">
                    <div className="relative w-20 h-16 rounded-lg overflow-hidden flex-shrink-0">
                      <Image
                        src="/european-flags.jpg"
                        alt="European Unity"
                        fill
                        className="object-cover"
                      />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-bold text-foreground text-base leading-tight hover:text-yellow-600 transition-colors line-clamp-2">
                        European unity tested by economic challenges
                      </h3>
                      <div className="flex items-center space-x-2 mt-2">
                        <span className="bg-gradient-to-r from-blue-500 to-blue-600 text-white text-xs px-2 py-1 rounded-full font-medium">
                          EU-NEWS
                        </span>
                        <span className="text-muted-foreground text-xs">
                          1 MONTH AGO
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex items-start space-x-3 p-4 bg-card rounded-xl shadow-md hover:shadow-lg transition-all duration-300">
                    <div className="relative w-20 h-16 rounded-lg overflow-hidden flex-shrink-0">
                      <Image
                        src="/chancellor.jpg"
                        alt="EU Leadership"
                        fill
                        className="object-cover"
                      />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-bold text-foreground text-base leading-tight hover:text-yellow-600 transition-colors line-clamp-2">
                        Germany defends AfD extremist label after U.S. backlash
                      </h3>
                      <div className="flex items-center space-x-2 mt-2">
                        <span className="bg-gradient-to-r from-red-500 to-red-600 text-white text-xs px-2 py-1 rounded-full font-medium">
                          EU-NEWS
                        </span>
                        <span className="text-muted-foreground text-xs">
                          3 MONTHS AGO
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex items-start space-x-3 p-4 bg-card rounded-xl shadow-md hover:shadow-lg transition-all duration-300">
                    <div className="relative w-20 h-16 rounded-lg overflow-hidden flex-shrink-0">
                      <Image
                        src="/eu-parliament.jpg"
                        alt="EU Parliament"
                        fill
                        className="object-cover"
                      />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-bold text-foreground text-base leading-tight hover:text-yellow-600 transition-colors line-clamp-2">
                        New EU climate policies reshape energy sector
                      </h3>
                      <div className="flex items-center space-x-2 mt-2">
                        <span className="bg-gradient-to-r from-green-500 to-green-600 text-white text-xs px-2 py-1 rounded-full font-medium">
                          EU-NEWS
                        </span>
                        <span className="text-muted-foreground text-xs">
                          2 WEEKS AGO
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Right side - Large Featured EU article */}
              <div className="lg:col-span-2">
                <div className="block group">
                  <div className="relative h-64 lg:h-96 rounded-2xl overflow-hidden shadow-xl hover:shadow-2xl transition-all duration-500">
                    <Image
                      src="/microchips-geopolitics.jpg"
                      alt="Microchips and Global Power"
                      fill
                      className="object-cover group-hover:scale-105 transition-transform duration-700"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent" />
                    <div className="absolute top-4 left-4">
                      <span className="bg-yellow-500/90 backdrop-blur-sm text-white text-sm font-medium px-3 py-1 rounded-full">
                        2 MONTHS AGO
                      </span>
                    </div>
                    <div className="absolute bottom-6 left-6 right-6">
                      <h3 className="text-white font-bold text-xl lg:text-3xl leading-tight mb-4">
                        Microchips and Global Power: The New Geopolitical Battlefield
                      </h3>
                      <div className="flex items-center space-x-3 text-white/90">
                        <div className="w-10 h-10 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center">
                          <span className="text-sm">👤</span>
                        </div>
                        <div>
                          <span className="text-sm font-medium">Political Correspondent</span>
                          <span className="text-sm ml-2">• 0 comments</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* International Politics Section - New enhanced section */}
        <div className="mb-12">
          <div className="flex items-center space-x-3 mb-6">
            <div className="w-1 h-8 bg-purple-500 rounded-full"></div>
            <h2 className="text-2xl lg:text-3xl font-bold text-foreground">International Politics</h2>
          </div>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left side - International article list */}
            <div className="lg:col-span-1 space-y-6">
              <div className="space-y-4">
                <div className="flex items-start space-x-3 p-4 bg-card rounded-xl shadow-md hover:shadow-lg transition-all duration-300">
                  <div className="relative w-20 h-16 rounded-lg overflow-hidden flex-shrink-0">
                    <Image
                      src="/international-politics.jpg"
                      alt="International Relations"
                      fill
                      className="object-cover"
                    />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-foreground text-base leading-tight hover:text-purple-600 transition-colors line-clamp-2">
                      Global summit addresses climate and security challenges
                    </h3>
                    <div className="flex items-center space-x-2 mt-2">
                      <span className="bg-gradient-to-r from-purple-500 to-purple-600 text-white text-xs px-2 py-1 rounded-full font-medium">
                        MAIN
                      </span>
                      <span className="text-muted-foreground text-xs">
                        1 MONTH AGO
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex items-start space-x-3 p-4 bg-card rounded-xl shadow-md hover:shadow-lg transition-all duration-300">
                  <div className="relative w-20 h-16 rounded-lg overflow-hidden flex-shrink-0">
                    <Image
                      src="/drone-military.jpg"
                      alt="Military Technology"
                      fill
                      className="object-cover"
                    />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-foreground text-base leading-tight hover:text-purple-600 transition-colors line-clamp-2">
                      Military drone technology reshapes modern warfare
                    </h3>
                    <div className="flex items-center space-x-2 mt-2">
                      <span className="bg-gradient-to-r from-red-500 to-red-600 text-white text-xs px-2 py-1 rounded-full font-medium">
                        DEFENSE-NEWS
                      </span>
                      <span className="text-muted-foreground text-xs">
                        3 WEEKS AGO
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex items-start space-x-3 p-4 bg-card rounded-xl shadow-md hover:shadow-lg transition-all duration-300">
                  <div className="relative w-20 h-16 rounded-lg overflow-hidden flex-shrink-0">
                    <Image
                      src="/uk-politics.jpg"
                      alt="UK Politics"
                      fill
                      className="object-cover"
                    />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-foreground text-base leading-tight hover:text-purple-600 transition-colors line-clamp-2">
                      UK foreign policy shifts amid global uncertainties
                    </h3>
                    <div className="flex items-center space-x-2 mt-2">
                      <span className="bg-gradient-to-r from-blue-500 to-blue-600 text-white text-xs px-2 py-1 rounded-full font-medium">
                        INTERNATIONAL-NEWS
                      </span>
                      <span className="text-muted-foreground text-xs">
                        2 WEEKS AGO
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex items-start space-x-3 p-4 bg-card rounded-xl shadow-md hover:shadow-lg transition-all duration-300">
                  <div className="relative w-20 h-16 rounded-lg overflow-hidden flex-shrink-0">
                    <Image
                      src="/government-building.jpg"
                      alt="Government Policy"
                      fill
                      className="object-cover"
                    />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-foreground text-base leading-tight hover:text-purple-600 transition-colors line-clamp-2">
                      Democratic institutions face new digital age challenges
                    </h3>
                    <div className="flex items-center space-x-2 mt-2">
                      <span className="bg-gradient-to-r from-green-500 to-green-600 text-white text-xs px-2 py-1 rounded-full font-medium">
                        INTERNATIONAL-NEWS
                      </span>
                      <span className="text-muted-foreground text-xs">
                        1 WEEK AGO
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Right side - Large Featured International article */}
            <div className="lg:col-span-2">
              <div className="block group">
                <div className="relative h-64 lg:h-96 rounded-2xl overflow-hidden shadow-xl hover:shadow-2xl transition-all duration-500">
                  <Image
                    src="/international-politics.jpg"
                    alt="Judge allows DOGE team limited access to sensitive Treasury data"
                    fill
                    className="object-cover group-hover:scale-105 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent" />
                  <div className="absolute top-4 left-4">
                    <span className="bg-purple-500/90 backdrop-blur-sm text-white text-sm font-medium px-3 py-1 rounded-full">
                      2 MONTHS AGO
                    </span>
                  </div>
                  <div className="absolute bottom-6 left-6 right-6">
                    <h3 className="text-white font-bold text-xl lg:text-3xl leading-tight mb-4">
                      Judge allows DOGE team limited access to sensitive Treasury data
                    </h3>
                    <div className="flex items-center space-x-3 text-white/90">
                      <div className="w-10 h-10 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center">
                        <span className="text-sm">👤</span>
                      </div>
                      <div>
                        <span className="text-sm font-medium">Political Correspondent</span>
                        <span className="text-sm ml-2">• 0 comments</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* UK Politics Section - Enhanced */}
        {ukArticles.length > 0 && (
          <div className="mb-12">
            <div className="flex items-center space-x-3 mb-6">
              <div className="w-1 h-8 bg-indigo-500 rounded-full"></div>
              <h2 className="text-2xl lg:text-3xl font-bold text-foreground">UK Politics</h2>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Left side - Article list */}
              <div className="lg:col-span-1 space-y-4">
                {ukArticles.slice(0, 3).map((article, index) => (
                  <div key={article._id} className="flex items-start space-x-3 p-4 bg-card rounded-xl shadow-md hover:shadow-lg transition-all duration-300">
                    <div className="relative w-16 h-16 rounded-lg overflow-hidden flex-shrink-0">
                      <Image
                        src={
                          index === 0 ? "/uk-politics.jpg" :
                          index === 1 ? "/government-building.jpg" :
                          "/politics-meeting.jpg"
                        }
                        alt={article.title}
                        fill
                        className="object-cover"
                      />
                    </div>
                    <div className="flex-1">
                      <Link href={`/article/${article.slug}`}>
                        <h3 className="font-bold text-foreground text-sm leading-tight hover:text-indigo-600 transition-colors line-clamp-2">
                          {article.title}
                        </h3>
                      </Link>
                      <div className="flex items-center space-x-2 mt-1">
                        <span className="bg-gradient-to-r from-indigo-500 to-indigo-600 text-white text-xs px-2 py-1 rounded-full font-medium">
                          UK-POLITICS
                        </span>
                        <span className="text-muted-foreground text-xs">
                          {formatTimeAgo(article.publicationDate)}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Right side - Featured UK Politics article */}
              <div className="lg:col-span-2">
                <div className="block group">
                  <div className="relative h-64 lg:h-96 rounded-2xl overflow-hidden shadow-xl hover:shadow-2xl transition-all duration-500">
                    <Image
                      src="/uk-politics.jpg"
                      alt="UK Political Developments"
                      fill
                      className="object-cover group-hover:scale-105 transition-transform duration-700"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent" />
                    <div className="absolute top-4 left-4">
                      <span className="bg-indigo-500/90 backdrop-blur-sm text-white text-sm font-medium px-3 py-1 rounded-full">
                        1 MONTH AGO
                      </span>
                    </div>
                    <div className="absolute bottom-6 left-6 right-6">
                      <h3 className="text-white font-bold text-xl lg:text-3xl leading-tight mb-4">
                        UK Parliament debates new immigration policies amid public pressure
                      </h3>
                      <div className="flex items-center space-x-3 text-white/90">
                        <div className="w-10 h-10 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center">
                          <span className="text-sm">👤</span>
                        </div>
                        <div>
                          <span className="text-sm font-medium">Political Correspondent</span>
                          <span className="text-sm ml-2">• 0 comments</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Latest & Popular Articles Section - Two column layout */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Latest Articles */}
          <div>
            <div className="flex items-center space-x-3 mb-6">
              <div className="w-1 h-8 bg-green-500 rounded-full"></div>
              <h2 className="text-2xl font-bold text-foreground">Latest</h2>
            </div>
            <div className="space-y-4">
              {latestArticles.map((article, index) => (
                <Link key={article._id} href={`/article/${article.slug}`} className="block group">
                  <div className="flex items-start space-x-4 p-4 bg-card rounded-xl shadow-md hover:shadow-lg transition-all duration-300">
                    <div className="relative w-20 h-16 rounded-lg overflow-hidden flex-shrink-0">
                      <Image
                        src={
                          index === 0 ? "/government-building.jpg" :
                          index === 1 ? "/politics-meeting.jpg" :
                          "/usa-politics.jpg"
                        }
                        alt={article.title}
                        fill
                        className="object-cover"
                      />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-bold text-foreground text-base leading-tight group-hover:text-green-600 transition-colors line-clamp-2">
                        {article.title}
                      </h3>
                      <div className="flex items-center space-x-2 mt-2">
                        <span className="bg-gradient-to-r from-green-500 to-green-600 text-white text-xs px-2 py-1 rounded-full font-medium">
                          POLITICS
                        </span>
                        <span className="text-muted-foreground text-xs">
                          {formatTimeAgo(article.publicationDate)}
                        </span>
                      </div>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>

          {/* Popular Articles */}
          <div>
            <div className="flex items-center space-x-3 mb-6">
              <div className="w-1 h-8 bg-orange-500 rounded-full"></div>
              <h2 className="text-2xl font-bold text-foreground">Popular</h2>
            </div>
            <div className="space-y-4">
              {popularArticles.map((article, index) => (
                <div key={index} className="flex items-start space-x-4 p-4 bg-card rounded-xl shadow-md hover:shadow-lg transition-all duration-300 group cursor-pointer">
                  <div className="relative w-20 h-16 rounded-lg overflow-hidden flex-shrink-0">
                    <Image
                      src={
                        index === 0 ? "/chancellor.jpg" :
                        index === 1 ? "/international-politics.jpg" :
                        "/politics-meeting.jpg"
                      }
                      alt={article.title}
                      fill
                      className="object-cover"
                    />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-foreground text-base leading-tight group-hover:text-orange-600 transition-colors line-clamp-2">
                      {article.title}
                    </h3>
                    <div className="flex items-center space-x-2 mt-2">
                      <span className="bg-gradient-to-r from-orange-500 to-orange-600 text-white text-xs px-2 py-1 rounded-full font-medium">
                        POLITICS
                      </span>
                      <span className="text-muted-foreground text-xs">
                        {article.time}
                      </span>
                      <span className="text-muted-foreground text-xs">
                        • {article.views} views
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}




