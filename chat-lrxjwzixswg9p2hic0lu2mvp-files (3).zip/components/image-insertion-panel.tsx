
"use client";

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Upload, Search, Wand2, Link } from 'lucide-react';
import { getOptimizedImageUrl } from '@/components/convex-image';

interface ImageInsertionPanelProps {
  onImageSelect: (imageUrl: string, alt?: string) => void;
  onFileUpload?: (file: File) => Promise<string>;
}

export default function ImageInsertionPanel({ onImageSelect, onFileUpload }: ImageInsertionPanelProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<any[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [aiPrompt, setAiPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [directUrl, setDirectUrl] = useState('');
  const [altText, setAltText] = useState('');
  const [uploading, setUploading] = useState(false);

  const searchImages = async () => {
    if (!searchQuery.trim()) return;
    
    setIsSearching(true);
    try {
      const response = await fetch('/api/pexels-search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query: searchQuery, page: 1 })
      });
      
      if (response.ok) {
        const data = await response.json();
        setSearchResults(data.photos || []);
      } else {
        console.error('Search failed');
        // Fallback to placeholder
        setSearchResults([
          { id: 1, src: { medium: '/placeholder-article.jpg' }, photographer: 'Sample', alt: searchQuery },
          { id: 2, src: { medium: '/placeholder-article.jpg' }, photographer: 'Sample', alt: searchQuery },
        ]);
      }
    } catch (error) {
      console.error('Search failed:', error);
      // Fallback to placeholder
      setSearchResults([
        { id: 1, src: { medium: '/placeholder-article.jpg' }, photographer: 'Sample', alt: searchQuery },
        { id: 2, src: { medium: '/placeholder-article.jpg' }, photographer: 'Sample', alt: searchQuery },
      ]);
    } finally {
      setIsSearching(false);
    }
  };

  const generateAIImage = async () => {
    if (!aiPrompt.trim()) return;
    
    setIsGenerating(true);
    try {
      const response = await fetch('/api/ai-image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          prompt: aiPrompt,
          intent: 'generate',
          aspectRatio: '16:9'
        })
      });
      
      if (response.ok) {
        const data = await response.json();
        onImageSelect(data.imageUrl, aiPrompt);
      } else {
        console.error('AI generation failed');
        // Fallback to placeholder
        onImageSelect('/placeholder-article.jpg', aiPrompt);
      }
    } catch (error) {
      console.error('Generation failed:', error);
      // Fallback to placeholder
      onImageSelect('/placeholder-article.jpg', aiPrompt);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !onFileUpload) return;

    setUploading(true);
    try {
      const storageId = await onFileUpload(file);
      // Use optimized CDN URL instead of direct storage URL
      const optimizedUrl = getOptimizedImageUrl(storageId, 800, 85);
      onImageSelect(optimizedUrl, altText || file.name);
    } catch (error) {
      console.error('Upload failed:', error);
      alert('Failed to upload image. Please try again.');
    } finally {
      setUploading(false);
    }
  };

  const insertDirectUrl = () => {
    if (directUrl.trim()) {
      onImageSelect(directUrl, altText);
      setDirectUrl('');
      setAltText('');
    }
  };

  return (
    <div className="w-full max-w-4xl">
      <Tabs defaultValue="upload" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="upload" className="flex items-center gap-2">
            <Upload className="h-4 w-4" />
            Upload
          </TabsTrigger>
          <TabsTrigger value="search" className="flex items-center gap-2">
            <Search className="h-4 w-4" />
            Search
          </TabsTrigger>
          <TabsTrigger value="ai" className="flex items-center gap-2">
            <Wand2 className="h-4 w-4" />
            AI Generate
          </TabsTrigger>
          <TabsTrigger value="url" className="flex items-center gap-2">
            <Link className="h-4 w-4" />
            URL
          </TabsTrigger>
        </TabsList>

        <TabsContent value="upload" className="space-y-4">
          <Card>
            <CardContent className="p-6">
              <div className="border-2 border-dashed border-slate-300 rounded-lg p-8 text-center">
                <Upload className="h-12 w-12 text-slate-400 mx-auto mb-4" />
                <p className="text-slate-600 mb-4">Upload an image from your computer</p>
                <Input
                  type="file"
                  accept="image/*"
                  onChange={handleFileUpload}
                  disabled={uploading}
                  className="max-w-xs mx-auto"
                />
                {uploading && <p className="text-sm text-blue-600 mt-2">Uploading...</p>}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="search" className="space-y-4">
          <div className="flex gap-2">
            <Input
              placeholder="Search for images..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && searchImages()}
            />
            <Button onClick={searchImages} disabled={isSearching}>
              {isSearching ? 'Searching...' : 'Search'}
            </Button>
          </div>
          
          {searchResults.length > 0 && (
            <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
              {searchResults.map((image) => (
                <Card key={image.id} className="cursor-pointer hover:shadow-md transition-shadow">
                  <CardContent className="p-2">
                    <img
                      src={image.src.medium}
                      alt={image.alt}
                      className="w-full h-32 object-cover rounded mb-2"
                      onClick={() => onImageSelect(image.src.medium, image.alt)}
                    />
                    <p className="text-xs text-slate-500">by {image.photographer}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="ai" className="space-y-4">
          <div className="space-y-4">
            <div>
              <Label htmlFor="aiPrompt">Describe the image you want to generate</Label>
              <Textarea
                id="aiPrompt"
                placeholder="A professional news photo of..."
                value={aiPrompt}
                onChange={(e) => setAiPrompt(e.target.value)}
                rows={3}
              />
            </div>
            <Button onClick={generateAIImage} disabled={isGenerating || !aiPrompt.trim()}>
              {isGenerating ? 'Generating...' : 'Generate Image'}
            </Button>
          </div>
        </TabsContent>

        <TabsContent value="url" className="space-y-4">
          <div className="space-y-4">
            <div>
              <Label htmlFor="directUrl">Image URL</Label>
              <Input
                id="directUrl"
                placeholder="https://example.com/image.jpg"
                value={directUrl}
                onChange={(e) => setDirectUrl(e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="altText">Alt Text (optional)</Label>
              <Input
                id="altText"
                placeholder="Description of the image"
                value={altText}
                onChange={(e) => setAltText(e.target.value)}
              />
            </div>
            <Button onClick={insertDirectUrl} disabled={!directUrl.trim()}>
              Insert Image
            </Button>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}



