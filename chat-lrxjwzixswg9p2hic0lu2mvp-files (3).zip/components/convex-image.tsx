"use client";

import Image, { ImageLoaderProps } from "next/image";

const convexLoader = ({ src, width, quality }: ImageLoaderProps) => {
  // src should be the storageId, not a full URL
  return `/api/image?id=${encodeURIComponent(src)}&w=${width}&q=${quality || 75}`;
};

interface ConvexImageProps {
  storageId: string;
  alt: string;
  width: number;
  height: number;
  className?: string;
  priority?: boolean;
  fill?: boolean;
  sizes?: string;
}

export default function ConvexImage({
  storageId,
  alt,
  width,
  height,
  className,
  priority = false,
  fill = false,
  sizes,
}: ConvexImageProps) {
  if (fill) {
    return (
      <Image
        loader={convexLoader}
        src={storageId}
        alt={alt}
        fill
        className={className}
        priority={priority}
        sizes={sizes}
        unoptimized={false}
      />
    );
  }

  return (
    <Image
      loader={convexLoader}
      src={storageId}
      alt={alt}
      width={width}
      height={height}
      className={className}
      priority={priority}
      sizes={sizes}
      unoptimized={false}
    />
  );
}

// Helper function to get optimized image URL for use in rich text editor
export function getOptimizedImageUrl(storageId: string, width = 800, quality = 75) {
  return `/api/image?id=${encodeURIComponent(storageId)}&w=${width}&q=${quality}`;
}