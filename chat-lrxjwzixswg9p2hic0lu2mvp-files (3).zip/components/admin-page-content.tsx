



















"use client";

import { useState, useEffect } from "react";
import { useQuery, useMutation } from "convex/react";
import { useAuthActions } from "@convex-dev/auth/react";
import { api } from "@/convex/_generated/api";
import type { Doc, Id } from "@/convex/_generated/dataModel";
import { Preloaded } from "convex/react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import RichTextEditor from "@/components/rich-text-editor";
import ImageInsertionPanel from "@/components/image-insertion-panel";
import Link from "next/link";
import { 
  Plus, Edit, Trash2, LogOut, Eye, Upload, Settings, 
  BarChart3, FileText, Image, Tag, Globe, TrendingUp,
  Users, Calendar, Activity, X, Save
} from "lucide-react";

interface AdminPageContentProps {
  // No props needed - using useQuery hooks directly
}

export default function AdminPageContent() {
  // Authentication state
  const [authStep, setAuthStep] = useState<"email" | "code">("email");
  const [email, setEmail] = useState("");
  const [isAuthLoading, setIsAuthLoading] = useState(false);
  
  // Article management state
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<Id<"articles"> | null>(null);
  const [formData, setFormData] = useState({
    title: "",
    slug: "",
    content: "",
    summary: "",
    categoryId: "" as Id<"categories">,
    authorId: "" as Id<"users"> | "", // Add author selection
    imageUrl: "",
    featuredImageStorageId: undefined as Id<"_storage"> | undefined,
    isFeatured: false,
    featuredPosition: 0,
    seo: {
      title: "",
      description: "",
      keywords: [] as string[],
      canonicalUrl: "",
    },
    tags: [] as string[],
  });
  const [isSlugManuallyEdited, setIsSlugManuallyEdited] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [newKeyword, setNewKeyword] = useState("");
  const [newTag, setNewTag] = useState("");
  const [showImagePanel, setShowImagePanel] = useState(false);

  // Homepage management state
  const [showHomepageForm, setShowHomepageForm] = useState(false);
  const [editingHomepageSection, setEditingHomepageSection] = useState<any>(null);
  const [homepageFormData, setHomepageFormData] = useState({
    sectionType: "featured",
    title: "",
    articleIds: [] as Id<"articles">[],
    order: 0,
    isActive: true,
    settings: {
      maxArticles: 6,
      layout: "grid",
      showImages: true,
    },
  });

  // Category management state
  const [showCategoryForm, setShowCategoryForm] = useState(false);
  const [editingCategoryId, setEditingCategoryId] = useState<Id<"categories"> | null>(null);
  const [categoryFormData, setCategoryFormData] = useState({
    name: "",
    slug: "",
    description: "",
    color: "#3b82f6",
    order: 0,
    isActive: true,
    featuredArticles: [] as Id<"articles">[],
  });
  const [selectedCategory, setSelectedCategory] = useState("");
  const [categoryFeaturedArticles, setCategoryFeaturedArticles] = useState<Id<"articles">[]>([]);

  // Queries
  const user = useQuery(api.users.currentLoggedInUser);
  const isAdmin = useQuery(api.authz.isAdmin);
  const articlesResult = useQuery(api.articles.getAllForAdmin, isAdmin ? {} : "skip");
  const categories = useQuery(api.categories.getAllCategories, {});
  const allUsers = useQuery(api.users.getAllUsers, isAdmin ? {} : "skip"); // Add users query
  const analytics = useQuery(api.analytics.getDashboardAnalytics, isAdmin ? {} : "skip");
  const media = useQuery(api.media.getAllMedia, isAdmin ? {} : "skip");
  const homepageSections = useQuery(api.siteSettings.getAllHomepageSections, isAdmin ? {} : "skip");
  
  // Debug logging
  console.log("Debug - Query results:", {
    user,
    isAdmin,
    categories,
    userType: typeof user,
    isAdminType: typeof isAdmin,
    convexUrl: process.env.NEXT_PUBLIC_CONVEX_URL
  });
  
  // Mutations
  const createArticle = useMutation(api.articles.create);
  const updateArticle = useMutation(api.articles.update);
  const deleteArticle = useMutation(api.articles.deleteArticle);
  const autoPromoteAdmin = useMutation(api.users.autoPromoteAdmin);
  const generateUploadUrl = useMutation(api.media.generateUploadUrl);
  const saveFileMetadata = useMutation(api.media.saveFileMetadata);
  const upsertHomepageSection = useMutation(api.siteSettings.upsertHomepageSection);
  const deleteHomepageSection = useMutation(api.siteSettings.deleteHomepageSection);
  const setCategoryFeatured = useMutation(api.siteSettings.setCategoryFeatured);
  const createCategory = useMutation(api.categories.createCategory);
  const updateCategory = useMutation(api.categories.updateCategory);
  const deleteCategory = useMutation(api.categories.deleteCategory);
  const { signIn, signOut } = useAuthActions();

  // Auto-promote admin user when they first log in
  useEffect(() => {
    console.log("Debug - user:", user);
    console.log("Debug - isAdmin:", isAdmin);
    if (user && user.email === "vovchok967@gmail.com" && user.role !== "admin") {
      autoPromoteAdmin();
    }
  }, [user, autoPromoteAdmin, isAdmin]);

  // Handle loading timeout
  useEffect(() => {
    if (user === undefined) {
      const timeoutId = setTimeout(() => {
        console.log("Debug - User query timeout, checking if still loading");
        if (typeof window !== 'undefined' && user === undefined) {
          console.log("Debug - Reloading page due to timeout");
          window.location.reload();
        }
      }, 10000); // Increased to 10 seconds

      return () => clearTimeout(timeoutId);
    }
  }, [user]);

  // Auto-generate slug from title
  const generateSlug = (title: string) => {
    return title
      .toLowerCase()
      .replace(/[^a-z0-9 -]/g, '')
      .replace(/\s+/g, '-')
      .replace(/-+/g, '-')
      .trim();
  };

  const handleTitleChange = (title: string) => {
    setFormData({ 
      ...formData, 
      title,
      slug: isSlugManuallyEdited ? formData.slug : generateSlug(title)
    });
  };

  const handleSlugChange = (slug: string) => {
    setFormData({ ...formData, slug });
    setIsSlugManuallyEdited(true);
  };

  // File upload handler
  const handleFileUpload = async (file: File) => {
    try {
      setUploading(true);
      
      // Step 1: Get upload URL from Convex
      const uploadUrl = await generateUploadUrl();
      
      // Step 2: Upload file directly to Convex storage using POST
      const uploadResponse = await fetch(uploadUrl, {
        method: "POST",
        headers: {
          "Content-Type": file.type,
        },
        body: file,
      });
      
      if (!uploadResponse.ok) {
        throw new Error(`Upload failed: ${uploadResponse.statusText}`);
      }
      
      // Step 3: Get the storage ID from response
      const { storageId } = await uploadResponse.json();
      
      if (!storageId) {
        throw new Error("No storage ID returned from upload");
      }
      
      // Step 4: Save metadata to database
      await saveFileMetadata({
        storageId,
        filename: file.name,
        contentType: file.type,
        size: file.size,
      });
      
      // Return storageId instead of URL for CDN optimization
      return storageId;
      
    } catch (error) {
      console.error("Upload error:", error);
      alert("Failed to upload image. Please try again.");
      throw error;
    } finally {
      setUploading(false);
    }
  };

  // Authentication handlers
  const handleEmailSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsAuthLoading(true);
    try {
      const formData = new FormData(e.currentTarget);
      const emailValue = formData.get("email") as string;
      setEmail(emailValue);
      await signIn("resend-otp", formData);
      setAuthStep("code");
    } catch (error) {
      console.error("Error sending code:", error);
    } finally {
      setIsAuthLoading(false);
    }
  };

  const handleCodeSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsAuthLoading(true);
    try {
      const formData = new FormData(e.currentTarget);
      await signIn("resend-otp", formData);
    } catch (error) {
      console.error("Error verifying code:", error);
    } finally {
      setIsAuthLoading(false);
    }
  };

  // Article management handlers
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const submitData = {
        ...formData,
        categoryId: formData.categoryId as Id<"categories">,
        authorId: formData.authorId || undefined, // Convert empty string to undefined
      };
      
      if (editingId) {
        const result = await updateArticle({ 
          id: editingId, 
          ...submitData,
        });
        if (result.ok) {
          resetForm();
        } else {
          alert(`Error: ${result.message}`);
        }
      } else {
        const result = await createArticle(submitData);
        if (result.ok) {
          resetForm();
        } else {
          alert(`Error: ${result.message}`);
        }
      }
    } catch (error) {
      console.error("Error saving article:", error);
    }
  };

  const resetForm = () => {
    setFormData({ 
      title: "", 
      slug: "", 
      content: "", 
      summary: "", 
      categoryId: "" as Id<"categories">,
      authorId: "", // Add authorId to reset
      imageUrl: "",
      featuredImageStorageId: undefined,
      isFeatured: false,
      featuredPosition: 0,
      seo: {
        title: "",
        description: "",
        keywords: [],
        canonicalUrl: "",
      },
      tags: [],
    });
    setShowForm(false);
    setEditingId(null);
    setIsSlugManuallyEdited(false);
  };

  const handleEdit = (article: Doc<"articles"> & { author?: { name: string } }) => {
    setFormData({
      title: article.title,
      slug: article.slug,
      content: article.content,
      summary: article.summary || "",
      categoryId: article.category,
      authorId: article.authorId || "", // Add authorId to edit
      imageUrl: article.imageUrl || "",
      featuredImageStorageId: article.featuredImageStorageId,
      isFeatured: article.isFeatured || false,
      featuredPosition: article.featuredPosition || 0,
      seo: {
        title: article.seo?.title || "",
        description: article.seo?.description || "",
        keywords: article.seo?.keywords || [],
        canonicalUrl: article.seo?.canonicalUrl || "",
      },
      tags: article.tags || [],
    });
    setEditingId(article._id);
    setShowForm(true);
    setIsSlugManuallyEdited(true);
  };

  const handleDelete = async (id: Id<"articles">) => {
    if (confirm("Are you sure you want to delete this article?")) {
      const result = await deleteArticle({ id: id });
      if (!result.ok) {
        alert(`Error: ${result.message}`);
      }
    }
  };

  const addKeyword = () => {
    if (newKeyword.trim() && !formData.seo.keywords.includes(newKeyword.trim())) {
      setFormData({
        ...formData,
        seo: {
          ...formData.seo,
          keywords: [...formData.seo.keywords, newKeyword.trim()]
        }
      });
      setNewKeyword("");
    }
  };

  const removeKeyword = (keyword: string) => {
    setFormData({
      ...formData,
      seo: {
        ...formData.seo,
        keywords: formData.seo.keywords.filter(k => k !== keyword)
      }
    });
  };

  const addTag = () => {
    if (newTag.trim() && !formData.tags.includes(newTag.trim())) {
      setFormData({
        ...formData,
        tags: [...formData.tags, newTag.trim()]
      });
      setNewTag("");
    }
  };

  const removeTag = (tag: string) => {
    setFormData({
      ...formData,
      tags: formData.tags.filter(t => t !== tag)
    });
  };

  // Homepage management handlers
  const resetHomepageForm = () => {
    setHomepageFormData({
      sectionType: "featured",
      title: "",
      articleIds: [],
      order: 0,
      isActive: true,
      settings: {
        maxArticles: 6,
        layout: "grid",
        showImages: true,
      },
    });
    setShowHomepageForm(false);
    setEditingHomepageSection(null);
  };

  const handleHomepageSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await upsertHomepageSection({
        sectionId: editingHomepageSection?._id,
        ...homepageFormData,
      });
      resetHomepageForm();
    } catch (error) {
      console.error("Error saving homepage section:", error);
      alert("Failed to save homepage section");
    }
  };

  const handleEditHomepageSection = (section: any) => {
    setHomepageFormData({
      sectionType: section.sectionType,
      title: section.title || "",
      articleIds: section.articleIds || [],
      order: section.order,
      isActive: section.isActive,
      settings: section.settings || {
        maxArticles: 6,
        layout: "grid",
        showImages: true,
      },
    });
    setEditingHomepageSection(section);
    setShowHomepageForm(true);
  };

  const handleDeleteHomepageSection = async (sectionId: Id<"homepageSections">) => {
    if (confirm("Are you sure you want to delete this homepage section?")) {
      try {
        await deleteHomepageSection({ sectionId });
      } catch (error) {
        console.error("Error deleting homepage section:", error);
        alert("Failed to delete homepage section");
      }
    }
  };

  const handleSaveCategoryFeatured = async () => {
    if (!selectedCategory) return;
    
    try {
      await setCategoryFeatured({
        categorySlug: selectedCategory,
        articleIds: categoryFeaturedArticles,
      });
      alert("Category featured articles updated successfully!");
    } catch (error) {
      console.error("Error saving category featured articles:", error);
      alert("Failed to save category featured articles");
    }
  };

  const toggleArticleInHomepage = (articleId: Id<"articles">) => {
    const currentIds = homepageFormData.articleIds;
    if (currentIds.includes(articleId)) {
      setHomepageFormData({
        ...homepageFormData,
        articleIds: currentIds.filter(id => id !== articleId)
      });
    } else {
      setHomepageFormData({
        ...homepageFormData,
        articleIds: [...currentIds, articleId]
      });
    }
  };

  const toggleArticleInCategory = (articleId: Id<"articles">) => {
    if (categoryFeaturedArticles.includes(articleId)) {
      setCategoryFeaturedArticles(categoryFeaturedArticles.filter(id => id !== articleId));
    } else {
      setCategoryFeaturedArticles([...categoryFeaturedArticles, articleId]);
    }
  };

  // Category management handlers
  const resetCategoryForm = () => {
    setCategoryFormData({
      name: "",
      slug: "",
      description: "",
      color: "#3b82f6",
      order: 0,
      isActive: true,
      featuredArticles: [],
    });
    setShowCategoryForm(false);
    setEditingCategoryId(null);
  };

  const handleCategorySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingCategoryId) {
        const result = await updateCategory({
          id: editingCategoryId,
          name: categoryFormData.name,
          slug: categoryFormData.slug,
          description: categoryFormData.description,
          color: categoryFormData.color,
          order: categoryFormData.order,
          isActive: categoryFormData.isActive,
        });
        if (result.ok) {
          resetCategoryForm();
        } else {
          alert(`Error: ${result.message}`);
        }
      } else {
        const result = await createCategory({
          name: categoryFormData.name,
          slug: categoryFormData.slug,
          description: categoryFormData.description,
          color: categoryFormData.color,
          order: categoryFormData.order,
          isActive: categoryFormData.isActive,
        });
        if (result.ok) {
          resetCategoryForm();
        } else {
          alert(`Error: ${result.message}`);
        }
      }
    } catch (error) {
      console.error("Error saving category:", error);
      alert("Failed to save category");
    }
  };

  const handleDeleteCategory = async (id: Id<"categories">) => {
    if (confirm("Are you sure you want to delete this category? This will also delete all articles in this category.")) {
      try {
        const result = await deleteCategory({ id });
        if (!result.ok) {
          alert(`Error: ${result.message}`);
        }
      } catch (error) {
        console.error("Error deleting category:", error);
        alert("Failed to delete category");
      }
    }
  };

  const generateCategorySlug = (name: string) => {
    return name
      .toLowerCase()
      .replace(/[^a-z0-9 -]/g, '')
      .replace(/\s+/g, '-')
      .replace(/-+/g, '-')
      .trim();
  };

  // Loading state - wait for user query to resolve, but don't wait for isAdmin if user is null
  if (user === undefined) {
    console.log("Debug - Loading user...");
    
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 to-slate-100">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-slate-600">Loading admin panel...</p>
          <p className="text-xs text-slate-400 mt-2">Debug: User query loading...</p>
        </div>
      </div>
    );
  }

  // Show login form if user is not authenticated
  if (user === null) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
        <Card className="w-full max-w-md shadow-xl border-0">
          <CardHeader className="text-center pb-8">
            <div className="mx-auto w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center mb-4">
              <Settings className="h-8 w-8 text-white" />
            </div>
            <CardTitle className="text-2xl font-bold text-slate-800">
              Admin Access
            </CardTitle>
            <p className="text-sm text-slate-600">
              {authStep === "email" ? "Enter your admin email to continue" : "Check your email for the verification code"}
            </p>
          </CardHeader>
          <CardContent>
            {authStep === "email" ? (
              <form onSubmit={handleEmailSubmit} className="space-y-4">
                <div>
                  <Label htmlFor="email" className="text-slate-700">Email Address</Label>
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    required
                    placeholder="admin@example.com"
                    disabled={isAuthLoading}
                    className="mt-1"
                  />
                </div>
                <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700" disabled={isAuthLoading}>
                  {isAuthLoading ? "Sending..." : "Send Verification Code"}
                </Button>
                <div className="text-center">
                  <Link href="/" className="text-sm text-slate-500 hover:text-slate-700 hover:underline">
                    ← Back to Blog
                  </Link>
                </div>
              </form>
            ) : (
              <form onSubmit={handleCodeSubmit} className="space-y-4">
                <input name="email" value={email} type="hidden" />
                <div>
                  <Label htmlFor="code" className="text-slate-700">Verification Code</Label>
                  <Input
                    id="code"
                    name="code"
                    type="text"
                    required
                    placeholder="Enter 6-digit code"
                    disabled={isAuthLoading}
                    className="mt-1 text-center text-lg tracking-widest"
                  />
                </div>
                <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700" disabled={isAuthLoading}>
                  {isAuthLoading ? "Verifying..." : "Verify & Sign In"}
                </Button>
                <Button
                  type="button"
                  variant="ghost"
                  className="w-full"
                  onClick={() => setAuthStep("email")}
                  disabled={isAuthLoading}
                >
                  Use different email
                </Button>
              </form>
            )}
          </CardContent>
        </Card>
      </div>
    );
  }

  // Access denied - shown when user is authenticated but not admin
  if (user && isAdmin === false) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-red-50 to-red-100">
        <Card className="shadow-xl border-0">
          <CardContent className="pt-6 text-center">
            <div className="mx-auto w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mb-4">
              <Settings className="h-8 w-8 text-red-600" />
            </div>
            <h2 className="text-xl font-semibold text-slate-800 mb-2">Access Denied</h2>
            <p className="text-slate-600 mb-6">You don't have permission to access the admin panel.</p>
            <p className="text-xs text-slate-400 mb-4">Debug: User role: {user?.role || 'none'}</p>
            <div className="flex gap-3 justify-center">
              <Button asChild>
                <Link href="/">Back to Blog</Link>
              </Button>
              <Button onClick={() => signOut()} variant="outline">
                Sign Out
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Loading articles
  if (articlesResult === undefined) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 to-slate-100">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-slate-600">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  // Error loading articles
  if (!articlesResult.ok) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="shadow-xl border-0">
          <CardContent className="pt-6 text-center">
            <p className="text-red-600 mb-4">Error: {articlesResult.message}</p>
            <Button onClick={() => window.location.reload()}>Retry</Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Main admin dashboard
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 shadow-sm">
        <div className="container mx-auto px-6 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-4">
              <div className="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
                <Settings className="h-6 w-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-slate-800">Admin Dashboard</h1>
                <p className="text-slate-600">Welcome back, {user.name || user.email}</p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <Button asChild>
                <Link href="/">
                  <Eye className="h-4 w-4 mr-2" />
                  View Site
                </Link>
              </Button>
              <Button onClick={() => signOut()} variant="ghost">
                <LogOut className="h-4 w-4 mr-2" />
                Sign Out
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-6 py-8">
        <Tabs defaultValue="dashboard" className="space-y-6">
          <TabsList className="grid w-full grid-cols-6 lg:w-auto lg:grid-cols-6">
            <TabsTrigger value="dashboard" className="flex items-center space-x-2">
              <BarChart3 className="h-4 w-4" />
              <span>Dashboard</span>
            </TabsTrigger>
            <TabsTrigger value="articles" className="flex items-center space-x-2">
              <FileText className="h-4 w-4" />
              <span>Articles</span>
            </TabsTrigger>
            <TabsTrigger value="categories" className="flex items-center space-x-2">
              <Tag className="h-4 w-4" />
              <span>Categories</span>
            </TabsTrigger>
            <TabsTrigger value="homepage" className="flex items-center space-x-2">
              <Globe className="h-4 w-4" />
              <span>Homepage</span>
            </TabsTrigger>
            <TabsTrigger value="media" className="flex items-center space-x-2">
              <Image className="h-4 w-4" />
              <span>Media</span>
            </TabsTrigger>
            <TabsTrigger value="settings" className="flex items-center space-x-2">
              <Settings className="h-4 w-4" />
              <span>Settings</span>
            </TabsTrigger>
          </TabsList>

          {/* Dashboard Tab */}
          <TabsContent value="dashboard" className="space-y-6">
            {analytics && (
              <>
                {/* Stats Cards */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  <Card className="bg-gradient-to-r from-blue-500 to-blue-600 text-white border-0">
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-blue-100 text-sm font-medium">Total Articles</p>
                          <p className="text-3xl font-bold">{analytics.totalArticles}</p>
                        </div>
                        <FileText className="h-8 w-8 text-blue-200" />
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="bg-gradient-to-r from-green-500 to-green-600 text-white border-0">
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-green-100 text-sm font-medium">Total Views</p>
                          <p className="text-3xl font-bold">{analytics.totalViews}</p>
                        </div>
                        <Eye className="h-8 w-8 text-green-200" />
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="bg-gradient-to-r from-purple-500 to-purple-600 text-white border-0">
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-purple-100 text-sm font-medium">Views Today</p>
                          <p className="text-3xl font-bold">{analytics.viewsToday}</p>
                        </div>
                        <TrendingUp className="h-8 w-8 text-purple-200" />
                      </div>
                    </CardContent>
                  </Card>

                  <Card className="bg-gradient-to-r from-orange-500 to-orange-600 text-white border-0">
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-orange-100 text-sm font-medium">Views This Week</p>
                          <p className="text-3xl font-bold">{analytics.viewsThisWeek}</p>
                        </div>
                        <Activity className="h-8 w-8 text-orange-200" />
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Charts and Lists */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {/* Top Articles */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center space-x-2">
                        <TrendingUp className="h-5 w-5" />
                        <span>Top Articles This Week</span>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        {analytics?.topArticles?.slice(0, 5).map((article, index) => {
                          // Type guard to ensure we have an article with the right properties
                          if (!article || !('title' in article) || !('slug' in article)) {
                            return null;
                          }
                          
                          return (
                            <div key={article._id} className="flex items-center justify-between">
                              <div className="flex-1">
                                <p className="font-medium text-sm truncate">{article.title}</p>
                                <p className="text-xs text-slate-500">/{article.slug}</p>
                              </div>
                              <Badge variant="secondary">{article.weeklyViews} views</Badge>
                            </div>
                          );
                        })}
                      </div>
                    </CardContent>
                  </Card>

                  {/* Top Categories */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center space-x-2">
                        <Tag className="h-5 w-5" />
                        <span>Popular Categories</span>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        {analytics.topCategories.map((category, index) => (
                          <div key={category.name} className="flex items-center justify-between">
                            <span className="font-medium">{category.name}</span>
                            <Badge variant="outline">{category.views} views</Badge>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </>
            )}
          </TabsContent>

          {/* Articles Tab */}
          <TabsContent value="articles" className="space-y-6">
            <div className="flex justify-between items-center">
              <div>
                <h2 className="text-2xl font-bold text-slate-800">Articles</h2>
                <p className="text-slate-600">{articlesResult.articles.length} total articles</p>
              </div>
              <Button onClick={() => {
                setShowForm(true);
                setIsSlugManuallyEdited(false);
              }} className="bg-blue-600 hover:bg-blue-700">
                <Plus className="h-4 w-4 mr-2" />
                New Article
              </Button>
            </div>

            {/* Articles List */}
            <div className="grid gap-4">
              {articlesResult.articles.map((article) => (
                <Card key={article._id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-2">
                          <h3 className="font-semibold text-lg">{article.title}</h3>
                          {article.isFeatured && (
                            <Badge className="bg-yellow-100 text-yellow-800">Featured</Badge>
                          )}
                        </div>
                        <p className="text-sm text-slate-500 mb-1">/{article.slug}</p>
                        <div className="flex items-center space-x-4 text-sm text-slate-500 mb-2">
                          <span>By {article.author.name}</span>
                          <span>•</span>
                          <span>{new Date(article.publicationDate || Date.now()).toLocaleDateString()}</span>
                          <span>•</span>
                          <span>{article.views || 0} views</span>
                        </div>
                        {article.summary && (
                          <p className="text-sm text-slate-600 line-clamp-2 mb-2">
                            {article.summary}
                          </p>
                        )}
                        {article.tags && article.tags.length > 0 && (
                          <div className="flex flex-wrap gap-1">
                            {article.tags.map((tag) => (
                              <Badge key={tag} variant="secondary" className="text-xs">
                                {tag}
                              </Badge>
                            ))}
                          </div>
                        )}
                      </div>
                      <div className="flex space-x-2 ml-4">
                        <Button size="sm" variant="ghost" asChild>
                          <Link href={`/article/${article.slug}`}>
                            <Eye className="h-4 w-4" />
                          </Link>
                        </Button>
                        <Button size="sm" variant="outline" onClick={() => handleEdit(article)}>
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleDelete(article._id)}
                          className="text-red-600 hover:text-red-700"
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Categories Tab */}
          <TabsContent value="categories" className="space-y-6">
            <div className="flex justify-between items-center">
              <div>
                <h2 className="text-2xl font-bold text-slate-800">Categories</h2>
                <p className="text-slate-600">Manage blog categories and featured articles</p>
              </div>
              <Button onClick={() => setShowCategoryForm(true)} className="bg-blue-600 hover:bg-blue-700">
                <Plus className="h-4 w-4 mr-2" />
                New Category
              </Button>
            </div>

            {/* Categories List */}
            <div className="grid gap-4">
              {categories?.map((category) => (
                <Card key={category._id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-2">
                          <h3 className="font-semibold text-lg">{category.name}</h3>
                          <div 
                            className="w-4 h-4 rounded-full border-2 border-white shadow-sm"
                            style={{ backgroundColor: category.color || '#3b82f6' }}
                          />
                          <Badge variant={category.isActive ? "default" : "secondary"}>
                            {category.isActive ? "Active" : "Inactive"}
                          </Badge>
                        </div>
                        <p className="text-sm text-slate-500 mb-1">/{category.slug}</p>
                        {category.description && (
                          <p className="text-sm text-slate-600 mb-2">
                            {category.description}
                          </p>
                        )}
                        <div className="flex items-center space-x-4 text-sm text-slate-500">
                          <span>Order: {category.order || 0}</span>
                        </div>
                      </div>
                      <div className="flex space-x-2 ml-4">
                        <Button size="sm" variant="ghost" asChild>
                          <Link href={`/category/${category.slug}`}>
                            <Eye className="h-4 w-4" />
                          </Link>
                        </Button>
                        <Button size="sm" variant="outline" onClick={() => {
                          setCategoryFormData({
                            name: category.name,
                            slug: category.slug,
                            description: category.description || "",
                            color: category.color || "#3b82f6",
                            order: category.order || 0,
                            isActive: category.isActive ?? true,
                            featuredArticles: [],
                          });
                          setEditingCategoryId(category._id);
                          setShowCategoryForm(true);
                        }}>
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button size="sm" variant="outline" onClick={() => {
                          setSelectedCategory(category.slug);
                          setCategoryFeaturedArticles([]);
                        }}>
                          <Settings className="h-4 w-4" />
                        </Button>
                        <Button size="sm" variant="outline" onClick={() => {
                          handleDeleteCategory(category._id);
                        }} className="text-red-600 hover:text-red-700">
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Category Featured Articles Management */}
            {selectedCategory && (
              <Card>
                <CardHeader>
                  <CardTitle>Manage Featured Articles for {selectedCategory}</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="grid gap-2 max-h-60 overflow-y-auto">
                      {articlesResult.articles.map((article) => (
                        <div key={article._id} className="flex items-center space-x-2 p-2 border rounded">
                          <input
                            type="checkbox"
                            checked={categoryFeaturedArticles.includes(article._id)}
                            onChange={() => toggleArticleInCategory(article._id)}
                            className="rounded"
                          />
                          <span className="flex-1 text-sm">{article.title}</span>
                          <Badge variant="outline" className="text-xs">
                            {categories?.find(c => c._id === article.category)?.name}
                          </Badge>
                        </div>
                      ))}
                    </div>
                    <div className="flex space-x-2">
                      <Button onClick={handleSaveCategoryFeatured} className="bg-green-600 hover:bg-green-700">
                        <Save className="h-4 w-4 mr-2" />
                        Save Featured Articles
                      </Button>
                      <Button onClick={() => setSelectedCategory("")} variant="outline">
                        Cancel
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* Homepage Tab */}
          <TabsContent value="homepage" className="space-y-6">
            <div className="flex justify-between items-center">
              <div>
                <h2 className="text-2xl font-bold text-slate-800">Homepage Management</h2>
                <p className="text-slate-600">Configure homepage sections and layout</p>
              </div>
              <Button onClick={() => setShowHomepageForm(true)} className="bg-blue-600 hover:bg-blue-700">
                <Plus className="h-4 w-4 mr-2" />
                Add Section
              </Button>
            </div>

            {/* Homepage Sections List */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-slate-800">Current Homepage Sections</h3>
              {homepageSections && homepageSections.length > 0 ? (
                <div className="grid gap-4">
                  {homepageSections.map((section) => (
                    <Card key={section._id} className="hover:shadow-md transition-shadow">
                      <CardContent className="p-6">
                        <div className="flex justify-between items-start">
                          <div className="flex-1">
                            <div className="flex items-center space-x-2 mb-2">
                              <h4 className="font-semibold text-lg">{section.title || `${section.sectionType} Section`}</h4>
                              <Badge variant={section.isActive ? "default" : "secondary"}>
                                {section.isActive ? "Active" : "Inactive"}
                              </Badge>
                              <Badge variant="outline">{section.sectionType}</Badge>
                            </div>
                            <div className="flex items-center space-x-4 text-sm text-slate-500 mb-2">
                              <span>Order: {section.order}</span>
                              <span>•</span>
                              <span>{section.articleIds.length} articles</span>
                              <span>•</span>
                              <span>Layout: {section.settings?.layout || 'grid'}</span>
                            </div>
                          </div>
                          <div className="flex space-x-2 ml-4">
                            <Button size="sm" variant="outline" onClick={() => handleEditHomepageSection(section)}>
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleDeleteHomepageSection(section._id)}
                              className="text-red-600 hover:text-red-700"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              ) : (
                <Card>
                  <CardContent className="p-6 text-center">
                    <p className="text-slate-500">No homepage sections configured yet.</p>
                    <Button onClick={() => setShowHomepageForm(true)} className="mt-4">
                      Create First Section
                    </Button>
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>

          {/* Media Tab */}
          <TabsContent value="media" className="space-y-6">
            <div>
              <h2 className="text-2xl font-bold text-slate-800">Media Library</h2>
              <p className="text-slate-600">Manage your uploaded images and files</p>
            </div>

            <Card>
              <CardContent className="p-6">
                <div className="border-2 border-dashed border-slate-300 rounded-lg p-8 text-center">
                  <Upload className="h-12 w-12 text-slate-400 mx-auto mb-4" />
                  <p className="text-slate-600 mb-4">Upload new media files</p>
                  <Input
                    type="file"
                    accept="image/*"
                    multiple
                    onChange={(e) => {
                      const files = Array.from(e.target.files || []);
                      files.forEach(file => handleFileUpload(file));
                    }}
                    className="max-w-xs mx-auto"
                  />
                </div>
              </CardContent>
            </Card>

            {media && media.length > 0 && (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {media.map((item) => (
                  <Card key={item._id} className="overflow-hidden">
                    <div className="aspect-square bg-slate-100">
                      {item.contentType.startsWith('image/') ? (
                        <img
                          src={item.url || ''}
                          alt={item.filename}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center">
                          <FileText className="h-12 w-12 text-slate-400" />
                        </div>
                      )}
                    </div>
                    <CardContent className="p-3">
                      <p className="text-sm font-medium truncate">{item.filename}</p>
                      <p className="text-xs text-slate-500">
                        {(item.size / 1024).toFixed(1)} KB
                      </p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          {/* Settings Tab */}
          <TabsContent value="settings" className="space-y-6">
            <div>
              <h2 className="text-2xl font-bold text-slate-800">Site Settings</h2>
              <p className="text-slate-600">Configure general blog settings and preferences</p>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>General Settings</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="siteName" className="text-slate-700 font-medium">Site Name</Label>
                    <Input
                      id="siteName"
                      placeholder="Your Blog Name"
                      className="mt-1"
                    />
                  </div>
                  <div>
                    <Label htmlFor="siteDescription" className="text-slate-700 font-medium">Site Description</Label>
                    <Textarea
                      id="siteDescription"
                      placeholder="A brief description of your blog"
                      rows={3}
                      className="mt-1"
                    />
                  </div>
                  <div>
                    <Label htmlFor="siteUrl" className="text-slate-700 font-medium">Site URL</Label>
                    <Input
                      id="siteUrl"
                      placeholder="https://yourblog.com"
                      className="mt-1"
                    />
                  </div>
                  <Button className="bg-blue-600 hover:bg-blue-700">
                    Save Settings
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>

      {/* Article Form Modal */}
      {showForm && (
        <Dialog open={showForm} onOpenChange={setShowForm}>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>
                {editingId ? "Edit Article" : "Create New Article"}
              </DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="title">Title</Label>
                  <Input
                    id="title"
                    value={formData.title}
                    onChange={(e) => handleTitleChange(e.target.value)}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="slug">Slug</Label>
                  <Input
                    id="slug"
                    value={formData.slug}
                    onChange={(e) => handleSlugChange(e.target.value)}
                    required
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="summary">Summary</Label>
                <Textarea
                  id="summary"
                  value={formData.summary}
                  onChange={(e) => setFormData({ ...formData, summary: e.target.value })}
                  rows={3}
                />
              </div>

              <div>
                <Label htmlFor="content">Content</Label>
                <RichTextEditor
                  value={formData.content}
                  onChange={(content) => setFormData({ ...formData, content })}
                  placeholder="Write your article content here..."
                  onFileUpload={handleFileUpload}
                  onImageInsert={(imageUrl) => {
                    // Handle image insertion into content
                    console.log('Image inserted:', imageUrl);
                  }}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="category">Category</Label>
                  <Select
                    value={formData.categoryId}
                    onValueChange={(value) => setFormData({ ...formData, categoryId: value as Id<"categories"> })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      {categories?.map((category) => (
                        <SelectItem key={category._id} value={category._id}>
                          {category.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="author">Author</Label>
                  <Select
                    value={formData.authorId}
                    onValueChange={(value) => setFormData({ ...formData, authorId: value as Id<"users"> })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select author" />
                    </SelectTrigger>
                    <SelectContent>
                      {allUsers?.map((author) => (
                        <SelectItem key={author._id} value={author._id}>
                          {author.name} ({author.email})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-2">
                  <Switch
                    id="featured"
                    checked={formData.isFeatured}
                    onCheckedChange={(checked) => setFormData({ ...formData, isFeatured: checked })}
                  />
                  <Label htmlFor="featured">Featured Article</Label>
                </div>
                {formData.isFeatured && (
                  <div>
                    <Label htmlFor="featuredPosition">Featured Position</Label>
                    <Input
                      id="featuredPosition"
                      type="number"
                      value={formData.featuredPosition}
                      onChange={(e) => setFormData({ ...formData, featuredPosition: parseInt(e.target.value) || 0 })}
                      className="w-20"
                    />
                  </div>
                )}
              </div>

              {/* SEO Section */}
              <div className="space-y-4">
                <h3 className="text-lg font-semibold">SEO Settings</h3>
                <div>
                  <Label htmlFor="seoTitle">SEO Title</Label>
                  <Input
                    id="seoTitle"
                    value={formData.seo.title}
                    onChange={(e) => setFormData({
                      ...formData,
                      seo: { ...formData.seo, title: e.target.value }
                    })}
                  />
                </div>
                <div>
                  <Label htmlFor="seoDescription">SEO Description</Label>
                  <Textarea
                    id="seoDescription"
                    value={formData.seo.description}
                    onChange={(e) => setFormData({
                      ...formData,
                      seo: { ...formData.seo, description: e.target.value }
                    })}
                    rows={3}
                  />
                </div>
                <div>
                  <Label htmlFor="keywords">Keywords</Label>
                  <div className="flex space-x-2 mb-2">
                    <Input
                      value={newKeyword}
                      onChange={(e) => setNewKeyword(e.target.value)}
                      placeholder="Add keyword"
                      onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addKeyword())}
                    />
                    <Button type="button" onClick={addKeyword} size="sm">
                      Add
                    </Button>
                  </div>
                  <div className="flex flex-wrap gap-1">
                    {formData.seo.keywords.map((keyword) => (
                      <Badge key={keyword} variant="secondary" className="cursor-pointer" onClick={() => removeKeyword(keyword)}>
                        {keyword} <X className="h-3 w-3 ml-1" />
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>

              {/* Tags Section */}
              <div>
                <Label htmlFor="tags">Tags</Label>
                <div className="flex space-x-2 mb-2">
                  <Input
                    value={newTag}
                    onChange={(e) => setNewTag(e.target.value)}
                    placeholder="Add tag"
                    onKeyPress={(e) => e.key === 'Enter' && (e.preventDefault(), addTag())}
                  />
                  <Button type="button" onClick={addTag} size="sm">
                    Add
                  </Button>
                </div>
                <div className="flex flex-wrap gap-1">
                  {formData.tags.map((tag) => (
                    <Badge key={tag} variant="secondary" className="cursor-pointer" onClick={() => removeTag(tag)}>
                      {tag} <X className="h-3 w-3 ml-1" />
                    </Badge>
                  ))}
                </div>
              </div>

              <div className="flex justify-end space-x-2">
                <Button type="button" variant="outline" onClick={resetForm}>
                  Cancel
                </Button>
                <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
                  {editingId ? "Update Article" : "Create Article"}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      )}

      {/* Image Insertion Panel Dialog */}
      {showImagePanel && (
        <Dialog open={showImagePanel} onOpenChange={setShowImagePanel}>
          <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Insert Image</DialogTitle>
            </DialogHeader>
            <ImageInsertionPanel
              onImageSelect={(imageUrl, alt) => {
                setFormData({ ...formData, imageUrl });
                setShowImagePanel(false);
              }}
              onFileUpload={handleFileUpload}
            />
          </DialogContent>
        </Dialog>
      )}

      {/* Homepage Form Modal */}
      {showHomepageForm && (
        <Dialog open={showHomepageForm} onOpenChange={setShowHomepageForm}>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>
                {editingHomepageSection ? "Edit Homepage Section" : "Create Homepage Section"}
              </DialogTitle>
            </DialogHeader>
            <form onSubmit={handleHomepageSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="sectionType">Section Type</Label>
                  <Select
                    value={homepageFormData.sectionType}
                    onValueChange={(value) => setHomepageFormData({ ...homepageFormData, sectionType: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="featured">Featured Articles</SelectItem>
                      <SelectItem value="latest">Latest Articles</SelectItem>
                      <SelectItem value="category">Category Spotlight</SelectItem>
                      <SelectItem value="trending">Trending Articles</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="sectionTitle">Section Title</Label>
                  <Input
                    id="sectionTitle"
                    value={homepageFormData.title}
                    onChange={(e) => setHomepageFormData({ ...homepageFormData, title: e.target.value })}
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="order">Display Order</Label>
                  <Input
                    id="order"
                    type="number"
                    value={homepageFormData.order}
                    onChange={(e) => setHomepageFormData({ ...homepageFormData, order: parseInt(e.target.value) || 0 })}
                  />
                </div>
                <div className="flex items-center space-x-2">
                  <Switch
                    id="isActive"
                    checked={homepageFormData.isActive}
                    onCheckedChange={(checked) => setHomepageFormData({ ...homepageFormData, isActive: checked })}
                  />
                  <Label htmlFor="isActive">Active</Label>
                </div>
              </div>

              <div>
                <Label>Select Articles</Label>
                <div className="grid gap-2 max-h-60 overflow-y-auto border rounded p-2">
                  {articlesResult.articles.map((article) => (
                    <div key={article._id} className="flex items-center space-x-2 p-2 hover:bg-slate-50 rounded">
                      <input
                        type="checkbox"
                        checked={homepageFormData.articleIds.includes(article._id)}
                        onChange={() => toggleArticleInHomepage(article._id)}
                        className="rounded"
                      />
                      <span className="flex-1 text-sm">{article.title}</span>
                      <Badge variant="outline" className="text-xs">
                        {categories?.find(c => c._id === article.category)?.name}
                      </Badge>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex justify-end space-x-2">
                <Button type="button" variant="outline" onClick={resetHomepageForm}>
                  Cancel
                </Button>
                <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
                  {editingHomepageSection ? "Update Section" : "Create Section"}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      )}

      {/* Category Form Modal */}
      {showCategoryForm && (
        <Dialog open={showCategoryForm} onOpenChange={setShowCategoryForm}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>
                {editingCategoryId ? "Edit Category" : "Create New Category"}
              </DialogTitle>
            </DialogHeader>
            <form onSubmit={(e) => {
              e.preventDefault();
              alert("Category management will be available soon!");
              setShowCategoryForm(false);
            }} className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="categoryName">Category Name</Label>
                  <Input
                    id="categoryName"
                    value={categoryFormData.name}
                    onChange={(e) => {
                      const name = e.target.value;
                      setCategoryFormData({ 
                        ...categoryFormData, 
                        name,
                        slug: generateCategorySlug(name)
                      });
                    }}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="categorySlug">Slug</Label>
                  <Input
                    id="categorySlug"
                    value={categoryFormData.slug}
                    onChange={(e) => setCategoryFormData({ ...categoryFormData, slug: e.target.value })}
                    required
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="categoryDescription">Description</Label>
                <Textarea
                  id="categoryDescription"
                  value={categoryFormData.description}
                  onChange={(e) => setCategoryFormData({ ...categoryFormData, description: e.target.value })}
                  rows={3}
                />
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="categoryColor">Color</Label>
                  <Input
                    id="categoryColor"
                    type="color"
                    value={categoryFormData.color}
                    onChange={(e) => setCategoryFormData({ ...categoryFormData, color: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="categoryOrder">Order</Label>
                  <Input
                    id="categoryOrder"
                    type="number"
                    value={categoryFormData.order}
                    onChange={(e) => setCategoryFormData({ ...categoryFormData, order: parseInt(e.target.value) || 0 })}
                  />
                </div>
                <div className="flex items-center space-x-2 pt-6">
                  <Switch
                    id="categoryActive"
                    checked={categoryFormData.isActive}
                    onCheckedChange={(checked) => setCategoryFormData({ ...categoryFormData, isActive: checked })}
                  />
                  <Label htmlFor="categoryActive">Active</Label>
                </div>
              </div>
              <div className="flex justify-end space-x-2">
                <Button type="button" variant="outline" onClick={() => setShowCategoryForm(false)}>
                  Cancel
                </Button>
                <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
                  {editingCategoryId ? "Update Category" : "Create Category"}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}




















