


"use client";

import Link from "next/link";
import { CategoryLink } from "./category-link";
import { useState } from "react";
import { Menu, X, Moon, Sun } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useTheme } from "next-themes";
import { usePathname } from "next/navigation";

const navigation = [
  { name: "Trending", href: "/", category: null },
  { name: "Home", href: "/", category: null },
  { name: "Political news", href: "/politics", category: "politics" },
  { name: "Finance news", href: "/finance", category: "finance" },
  { name: "Sport news", href: "/sports", category: "sports" },
  { name: "Tech news", href: "/tech", category: "tech" },
];

export default function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { theme, setTheme } = useTheme();
  const pathname = usePathname();

  // Function to check if a navigation item is active
  const isActive = (href: string) => {
    if (href === "/") {
      return pathname === "/";
    }
    return pathname.startsWith(href);
  };

  return (
    <header className="bg-background shadow-sm">
      {/* Top red navigation bar */}
      <div className="bg-red-600 text-white py-3">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex items-center justify-center">
            <nav className="hidden md:flex items-center space-x-8">
              {navigation.map((item) => (
                item.category ? (
                  <CategoryLink
                    key={item.name}
                    category={item.category}
                    href={item.href}
                    className={`text-sm font-medium transition-colors px-3 py-2 rounded-md ${
                      isActive(item.href)
                        ? "bg-red-700 text-white shadow-md"
                        : "hover:text-gray-200 hover:bg-red-700/50"
                    }`}
                  >
                    {item.name}
                  </CategoryLink>
                ) : (
                  <Link
                    key={item.name}
                    href={item.href}
                    className={`text-sm font-medium transition-colors px-3 py-2 rounded-md ${
                      isActive(item.href)
                        ? "bg-red-700 text-white shadow-md"
                        : "hover:text-gray-200 hover:bg-red-700/50"
                    }`}
                  >
                    {item.name}
                  </Link>
                )
              ))}
            </nav>
            
            {/* Mobile menu button */}
            <div className="md:hidden flex items-center">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className="text-white hover:text-gray-200 hover:bg-red-700"
              >
                {mobileMenuOpen ? (
                  <X className="h-6 w-6" />
                ) : (
                  <Menu className="h-6 w-6" />
                )}
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Main header with logo and controls */}
      <div className="bg-background border-b border-border">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            {/* Left side - Live */}
            <div className="flex items-center space-x-4">
              <span className="text-sm font-medium text-muted-foreground bg-muted px-3 py-1 rounded">Live</span>
            </div>

            {/* Center - Logo */}
            <div className="flex-1 flex justify-center">
              <Link href="/" className="flex items-center">
                <div className="text-center">
                  <div className="text-2xl md:text-3xl font-bold">
                    <span className="text-red-600">HORIZONS</span>
                  </div>
                  <div className="text-sm md:text-base text-muted-foreground font-medium">
                    Times
                  </div>
                </div>
              </Link>
            </div>

            {/* Right side - Theme toggle */}
            <div className="flex items-center">
              <Button asChild variant="ghost" size="sm" className="mr-2">
                <Link href="/admin">
                  Admin
                </Link>
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
                className="p-2 text-muted-foreground hover:text-foreground"
              >
                {theme === "dark" ? (
                  <Sun className="h-5 w-5" />
                ) : (
                  <Moon className="h-5 w-5" />
                )}
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-red-600 dark:bg-red-700 border-t border-red-700 dark:border-red-800">
          <div className="px-4 py-2 space-y-1">
            {navigation.map((item) => (
              item.category ? (
                <CategoryLink
                  key={item.name}
                  category={item.category}
                  href={item.href}
                  className={`block px-3 py-2 text-sm font-medium rounded transition-colors ${
                    isActive(item.href)
                      ? "bg-red-700 dark:bg-red-800 text-white shadow-md"
                      : "text-white hover:text-gray-200 hover:bg-red-700 dark:hover:bg-red-800"
                  }`}
                >
                  {item.name}
                </CategoryLink>
              ) : (
                <Link
                  key={item.name}
                  href={item.href}
                  className={`block px-3 py-2 text-sm font-medium rounded transition-colors ${
                    isActive(item.href)
                      ? "bg-red-700 dark:bg-red-800 text-white shadow-md"
                      : "text-white hover:text-gray-200 hover:bg-red-700 dark:hover:bg-red-800"
                  }`}
                  onClick={() => setMobileMenuOpen(false)}
                >
                  {item.name}
                </Link>
              )
            ))}
          </div>
        </div>
      )}
    </header>
  );
}






