"use client"

import { ConvexAuthProvider } from "@convex-dev/auth/react"
import { ConvexReactClient } from "convex/react"
import { ReactNode } from "react"

// Hardcode the URL temporarily to test if this is the issue
const convexUrl = process.env.NEXT_PUBLIC_CONVEX_URL || "https://neighborly-starling-819.convex.cloud"
console.log("ConvexClientProvider - convexUrl:", convexUrl)
const convex = new ConvexReactClient(convexUrl)
console.log("ConvexClientProvider - convex client created:", !!convex)

export function ConvexClientProvider({ children }: { children: ReactNode }) {
  console.log("ConvexClientProvider - Rendering with ConvexAuthProvider")
  return <ConvexAuthProvider client={convex}>{children}</ConvexAuthProvider>
}


