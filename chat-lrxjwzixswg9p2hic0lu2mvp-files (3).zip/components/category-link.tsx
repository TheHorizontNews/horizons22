"use client";
import { useState } from "react";
import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api";
import Link from "next/link";

function CategoryPrefetch({ category }: { category: string }) {
  // This will warm the client cache
  const data = useQuery(api.articles.getCategoryPageData, { categorySlug: category });
  // data === undefined -> loading; we return null because this is only for warming
  return null;
}

interface CategoryLinkProps {
  category: string;
  href: string;
  children: React.ReactNode;
  className?: string;
}

export function CategoryLink({ category, href, children, className }: CategoryLinkProps) {
  const [hovered, setHovered] = useState(false);
  
  return (
    <>
      <Link
        href={href}
        className={className}
        onMouseEnter={() => setHovered(true)}
        onFocus={() => setHovered(true)}
      >
        {children}
      </Link>
      {hovered && <CategoryPrefetch category={category} />}
    </>
  );
}
