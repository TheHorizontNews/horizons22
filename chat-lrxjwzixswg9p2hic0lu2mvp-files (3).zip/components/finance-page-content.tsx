




"use client";

import { usePreloadedQuery } from "convex/react";
import { api } from "@/convex/_generated/api";
import { Preloaded } from "convex/react";
import Image from "next/image";
import Link from "next/link";

interface FinancePageContentProps {
  preloadedData: Preloaded<typeof api.articles.getCategoryPageData>;
}

export default function FinancePageContent({ preloadedData }: FinancePageContentProps) {
  const { articles: categoryArticles, categories, category: financeCategory } = usePreloadedQuery(preloadedData);
  
  // Remove console logs for better performance
  // Use the articles directly from the optimized query
  const allArticles = categoryArticles;
  
  // Remove console logs for better performance
  // console.log('All articles:', allArticles.length);
  // console.log('Categories:', categories);
  
  // Find the finance category
  // console.log('Finance category:', financeCategory);
  
  // Filter finance articles by category ID - if no finance category found, use all articles as fallback
  const financeArticles = financeCategory 
    ? allArticles.filter(article => article.category === financeCategory._id)
    : allArticles.slice(0, 15); // Use first 15 articles as fallback
  
  // console.log('Finance articles:', financeArticles.length);
  
  // If we don't have enough finance articles, use fallback articles from other categories
  const allOtherArticles = financeCategory 
    ? allArticles.filter(article => article.category !== financeCategory._id)
    : [];
  
  // Ensure we have enough articles for all sections by using fallbacks
  const ensureMinimumArticles = (articles: typeof financeArticles, minimum: number) => {
    if (articles.length >= minimum) return articles;
    const needed = minimum - articles.length;
    const fallbacks = allOtherArticles.slice(0, needed);
    return [...articles, ...fallbacks];
  };
  
  // Get articles with fallbacks for each section
  const heroArticlesWithFallback = ensureMinimumArticles(financeArticles, 4);
  const trendingArticlesWithFallback = ensureMinimumArticles(financeArticles.slice(4), 3);
  
  // console.log('Finance articles with fallback for hero:', heroArticlesWithFallback.length);
  // console.log('Finance articles with fallback for trending:', trendingArticlesWithFallback.length);
  
  // Get featured articles for hero section (first 6)
  const heroArticles = heroArticlesWithFallback.slice(0, 6);
  const mainFeatured = heroArticles[0];
  const sideArticles = heroArticles.slice(1, 6);

  // Get trending articles (next 4)
  const trendingArticles = trendingArticlesWithFallback.slice(0, 4);

  // Categorize articles by financial topics
  const cryptoArticles = financeArticles.filter(article => 
    article.title.toLowerCase().includes('crypto') || 
    article.title.toLowerCase().includes('bitcoin') ||
    article.title.toLowerCase().includes('ethereum') ||
    article.title.toLowerCase().includes('blockchain') ||
    article.title.toLowerCase().includes('digital currency') ||
    article.title.toLowerCase().includes('cryptocurrency')
  ).slice(0, 4);

  const stockArticles = financeArticles.filter(article => 
    article.title.toLowerCase().includes('stock') || 
    article.title.toLowerCase().includes('market') ||
    article.title.toLowerCase().includes('trading') ||
    article.title.toLowerCase().includes('investment') ||
    article.title.toLowerCase().includes('nasdaq') ||
    article.title.toLowerCase().includes('dow jones')
  ).slice(0, 4);

  const bankingArticles = financeArticles.filter(article => 
    article.title.toLowerCase().includes('bank') || 
    article.title.toLowerCase().includes('financial') ||
    article.title.toLowerCase().includes('lending') ||
    article.title.toLowerCase().includes('mortgage') ||
    article.title.toLowerCase().includes('credit')
  ).slice(0, 3);

  const economyArticles = financeArticles.filter(article => 
    article.title.toLowerCase().includes('economy') || 
    article.title.toLowerCase().includes('economic') ||
    article.title.toLowerCase().includes('gdp') ||
    article.title.toLowerCase().includes('inflation') ||
    article.title.toLowerCase().includes('recession')
  ).slice(0, 2);

  // Latest articles
  const latestArticles = financeArticles.slice(0, 3);

  // Popular articles (mock data for now)
  const popularArticles = [
    { title: "Bitcoin reaches new all-time high amid institutional adoption", time: "2 MONTHS AGO", views: "450" },
    { title: "Federal Reserve signals potential interest rate changes", time: "1 MONTH AGO", views: "380" },
    { title: "Stock market volatility continues amid global uncertainties", time: "3 WEEKS AGO", views: "320" }
  ];

  const formatTimeAgo = (date: string | number) => {
    const now = new Date();
    const articleDate = new Date(date);
    const diffInMonths = Math.floor((now.getTime() - articleDate.getTime()) / (1000 * 60 * 60 * 24 * 30));
    
    if (diffInMonths >= 1) {
      return `${diffInMonths} MONTHS AGO`;
    }
    const diffInDays = Math.floor((now.getTime() - articleDate.getTime()) / (1000 * 60 * 60 * 24));
    return `${diffInDays} DAYS AGO`;
  };

  // console.log('Crypto articles found:', cryptoArticles.length);
  // console.log('Crypto articles:', cryptoArticles.map(a => a.title));

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section - More organic and stylish */}
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Enhanced Hero Grid with better mobile layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 mb-12">
          {/* Left Column - Mobile: full width, Desktop: 3 columns */}
          <div className="lg:col-span-3 space-y-4">
            {sideArticles.slice(0, 2).map((article, index) => (
              <Link key={article._id} href={`/article/${article.slug}`} className="block">
                <div className="relative h-48 lg:h-40 rounded-xl overflow-hidden group shadow-lg hover:shadow-xl transition-all duration-300">
                  <Image
                    src={index === 0 ? "/stock-charts.jpg" : "/financial-analysis.jpg"}
                    alt={article.title}
                    fill
                    className="object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent" />
                  <div className="absolute top-3 left-3">
                    <span className="bg-white/20 backdrop-blur-sm text-white text-xs font-medium px-2 py-1 rounded-full">
                      {formatTimeAgo(article.publicationDate)}
                    </span>
                  </div>
                  <div className="absolute bottom-3 left-3 right-3">
                    <h3 className="text-white font-bold text-sm lg:text-xs leading-tight line-clamp-3">
                      {article.title}
                    </h3>
                  </div>
                </div>
              </Link>
            ))}
            {/* Third article - hidden on mobile to save space */}
            {sideArticles[2] && (
              <Link href={`/article/${sideArticles[2].slug}`} className="hidden lg:block">
                <div className="relative h-40 rounded-xl overflow-hidden group shadow-lg hover:shadow-xl transition-all duration-300">
                  <Image
                    src="/crypto-bitcoin-gold.jpg"
                    alt={sideArticles[2].title}
                    fill
                    className="object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent" />
                  <div className="absolute top-3 left-3">
                    <span className="bg-white/20 backdrop-blur-sm text-white text-xs font-medium px-2 py-1 rounded-full">
                      {formatTimeAgo(sideArticles[2].publicationDate)}
                    </span>
                  </div>
                  <div className="absolute bottom-3 left-3 right-3">
                    <h3 className="text-white font-bold text-xs leading-tight line-clamp-3">
                      {sideArticles[2].title}
                    </h3>
                  </div>
                </div>
              </Link>
            )}
          </div>

          {/* Center - Main featured article */}
          {mainFeatured && (
            <div className="lg:col-span-6">
              <Link href={`/article/${mainFeatured.slug}`} className="block group">
                <div className="relative h-64 lg:h-[500px] rounded-2xl overflow-hidden shadow-2xl hover:shadow-3xl transition-all duration-500">
                  <Image
                    src="/finance-hero.jpg"
                    alt={mainFeatured.title}
                    fill
                    className="object-cover group-hover:scale-105 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent" />
                  <div className="absolute top-4 left-4">
                    <span className="bg-red-500/90 backdrop-blur-sm text-white text-sm font-medium px-3 py-1 rounded-full">
                      {formatTimeAgo(mainFeatured.publicationDate)}
                    </span>
                  </div>
                  <div className="absolute bottom-6 left-6 right-6">
                    <h2 className="text-white font-bold text-xl lg:text-4xl leading-tight mb-4">
                      {mainFeatured.title}
                    </h2>
                    <div className="flex items-center space-x-3 text-white/90">
                      <div className="w-10 h-10 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center">
                        <span className="text-sm">👤</span>
                      </div>
                      <div>
                        <span className="text-sm font-medium">Financial Analyst</span>
                        <span className="text-sm ml-2">• 0 comments</span>
                      </div>
                    </div>
                  </div>
                </div>
              </Link>
            </div>
          )}

          {/* Right Column - Mobile: full width, Desktop: 3 columns */}
          <div className="lg:col-span-3 space-y-4">
            {sideArticles.slice(3, 5).map((article, index) => (
              <Link key={article._id} href={`/article/${article.slug}`} className="block">
                <div className="relative h-48 lg:h-40 rounded-xl overflow-hidden group shadow-lg hover:shadow-xl transition-all duration-300">
                  <Image
                    src={index === 0 ? "/crypto-trading.jpg" : "/bitcoin-exchange.jpg"}
                    alt={article.title}
                    fill
                    className="object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent" />
                  <div className="absolute top-3 left-3">
                    <span className="bg-white/20 backdrop-blur-sm text-white text-xs font-medium px-2 py-1 rounded-full">
                      {formatTimeAgo(article.publicationDate)}
                    </span>
                  </div>
                  <div className="absolute bottom-3 left-3 right-3">
                    <h3 className="text-white font-bold text-sm lg:text-xs leading-tight line-clamp-3">
                      {article.title}
                    </h3>
                  </div>
                </div>
              </Link>
            ))}
            {/* Third article - hidden on mobile */}
            {sideArticles[5] && (
              <Link href={`/article/${sideArticles[5].slug}`} className="hidden lg:block">
                <div className="relative h-40 rounded-xl overflow-hidden group shadow-lg hover:shadow-xl transition-all duration-300">
                  <Image
                    src="/crypto-ethereum.jpg"
                    alt={sideArticles[5].title}
                    fill
                    className="object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent" />
                  <div className="absolute top-3 left-3">
                    <span className="bg-white/20 backdrop-blur-sm text-white text-xs font-medium px-2 py-1 rounded-full">
                      {formatTimeAgo(sideArticles[5].publicationDate)}
                    </span>
                  </div>
                  <div className="absolute bottom-3 left-3 right-3">
                    <h3 className="text-white font-bold text-xs leading-tight line-clamp-3">
                      {sideArticles[5].title}
                    </h3>
                  </div>
                </div>
              </Link>
            )}
            {/* Fourth article - new addition to fill empty space */}
            <div className="hidden lg:block">
              <div className="relative h-40 rounded-xl overflow-hidden group shadow-lg hover:shadow-xl transition-all duration-300">
                <Image
                  src="/crypto-phone-trading.jpg"
                  alt="Mobile crypto trading platform"
                  fill
                  className="object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent" />
                <div className="absolute top-3 left-3">
                  <span className="bg-white/20 backdrop-blur-sm text-white text-xs font-medium px-2 py-1 rounded-full">
                    2 DAYS AGO
                  </span>
                </div>
                <div className="absolute bottom-3 left-3 right-3">
                  <h3 className="text-white font-bold text-xs leading-tight line-clamp-3">
                    Mobile trading platforms revolutionize financial markets
                  </h3>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Trending this week - Enhanced styling */}
        <div className="mb-12">
          <div className="flex items-center space-x-3 mb-6">
            <div className="w-1 h-8 bg-red-500 rounded-full"></div>
            <h2 className="text-2xl lg:text-3xl font-bold text-foreground">Trending this week</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {trendingArticles.map((article, index) => (
              <Link key={article._id} href={`/article/${article.slug}`} className="group">
                <div className="bg-card rounded-xl overflow-hidden shadow-md hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1">
                  <div className="relative h-48">
                    <Image
                      src={
                        index === 0 ? "/stock-charts.jpg" :
                        index === 1 ? "/crypto-trading-screen.jpg" :
                        index === 2 ? "/financial-analysis.jpg" :
                        "/bitcoin-exchange.jpg"
                      }
                      alt={article.title}
                      fill
                      className="object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                  </div>
                  <div className="p-4">
                    <div className="flex items-center space-x-2 mb-3">
                      <span className="bg-gradient-to-r from-red-500 to-red-600 text-white text-xs px-3 py-1 rounded-full font-medium">
                        FINANCE-NEWS
                      </span>
                      <span className="text-muted-foreground text-xs">
                        {formatTimeAgo(article.publicationDate)}
                      </span>
                    </div>
                    <h3 className="font-bold text-foreground text-sm leading-tight line-clamp-3 group-hover:text-red-600 transition-colors">
                      {article.title}
                    </h3>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>

        {/* Cryptocurrency Section - Enhanced */}
        {cryptoArticles.length > 0 && (
          <div className="mb-12">
            <div className="flex items-center space-x-3 mb-6">
              <div className="w-1 h-8 bg-orange-500 rounded-full"></div>
              <h2 className="text-2xl lg:text-3xl font-bold text-foreground">Cryptocurrency</h2>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {cryptoArticles.map((article, index) => (
                <Link key={article._id} href={`/article/${article.slug}`} className="group">
                  <div className="bg-card rounded-xl overflow-hidden shadow-md hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1">
                    <div className="relative h-48">
                      <Image
                        src={
                          index === 0 ? "/crypto-bitcoin-gold.jpg" :
                          index === 1 ? "/crypto-ethereum.jpg" :
                          index === 2 ? "/crypto-hand-bitcoin.jpg" :
                          "/crypto-trading.jpg"
                        }
                        alt={article.title}
                        fill
                        className="object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                    </div>
                    <div className="p-4">
                      <div className="flex items-center space-x-2 mb-3">
                        <span className="bg-gradient-to-r from-orange-500 to-orange-600 text-white text-xs px-3 py-1 rounded-full font-medium">
                          CRYPTO
                        </span>
                        <span className="text-muted-foreground text-xs">
                          {formatTimeAgo(article.publicationDate)}
                        </span>
                      </div>
                      <h3 className="font-bold text-foreground text-sm leading-tight line-clamp-3 group-hover:text-orange-600 transition-colors">
                        {article.title}
                      </h3>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        )}

        {/* Stock Market Section - Enhanced */}
        {stockArticles.length > 0 && (
          <div className="mb-12">
            <div className="flex items-center space-x-3 mb-6">
              <div className="w-1 h-8 bg-green-500 rounded-full"></div>
              <h2 className="text-2xl lg:text-3xl font-bold text-foreground">Stock Market</h2>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Left side - Article list */}
              <div className="lg:col-span-1 space-y-6">
                <div className="space-y-4">
                  <div className="flex items-start space-x-3 p-4 bg-card rounded-xl shadow-md hover:shadow-lg transition-all duration-300">
                    <div className="relative w-20 h-16 rounded-lg overflow-hidden flex-shrink-0">
                      <Image
                        src="/stock-charts.jpg"
                        alt="Stock Market Analysis"
                        fill
                        className="object-cover"
                      />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-bold text-foreground text-base leading-tight hover:text-green-600 transition-colors line-clamp-2">
                        S&P 500 reaches record highs amid tech sector surge
                      </h3>
                      <div className="flex items-center space-x-2 mt-2">
                        <span className="bg-gradient-to-r from-green-500 to-green-600 text-white text-xs px-2 py-1 rounded-full font-medium">
                          MAIN
                        </span>
                        <span className="text-muted-foreground text-xs">
                          1 MONTH AGO
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Other Stock articles */}
                <div className="space-y-4">
                  <div className="flex items-start space-x-3 p-4 bg-card rounded-xl shadow-md hover:shadow-lg transition-all duration-300">
                    <div className="relative w-20 h-16 rounded-lg overflow-hidden flex-shrink-0">
                      <Image
                        src="/financial-analysis.jpg"
                        alt="Financial Analysis"
                        fill
                        className="object-cover"
                      />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-bold text-foreground text-base leading-tight hover:text-green-600 transition-colors line-clamp-2">
                        Quarterly earnings reports exceed market expectations
                      </h3>
                      <div className="flex items-center space-x-2 mt-2">
                        <span className="bg-gradient-to-r from-blue-500 to-blue-600 text-white text-xs px-2 py-1 rounded-full font-medium">
                          MARKET-NEWS
                        </span>
                        <span className="text-muted-foreground text-xs">
                          2 WEEKS AGO
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex items-start space-x-3 p-4 bg-card rounded-xl shadow-md hover:shadow-lg transition-all duration-300">
                    <div className="relative w-20 h-16 rounded-lg overflow-hidden flex-shrink-0">
                      <Image
                        src="/crypto-trading-screen.jpg"
                        alt="Trading Screen"
                        fill
                        className="object-cover"
                      />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-bold text-foreground text-base leading-tight hover:text-green-600 transition-colors line-clamp-2">
                        AI-driven trading algorithms reshape market dynamics
                      </h3>
                      <div className="flex items-center space-x-2 mt-2">
                        <span className="bg-gradient-to-r from-purple-500 to-purple-600 text-white text-xs px-2 py-1 rounded-full font-medium">
                          MARKET-NEWS
                        </span>
                        <span className="text-muted-foreground text-xs">
                          1 WEEK AGO
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  <div className="flex items-start space-x-3 p-4 bg-card rounded-xl shadow-md hover:shadow-lg transition-all duration-300">
                    <div className="relative w-20 h-16 rounded-lg overflow-hidden flex-shrink-0">
                      <Image
                        src="/bitcoin-exchange.jpg"
                        alt="Market Exchange"
                        fill
                        className="object-cover"
                      />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-bold text-foreground text-base leading-tight hover:text-green-600 transition-colors line-clamp-2">
                        Global markets respond to central bank policy changes
                      </h3>
                      <div className="flex items-center space-x-2 mt-2">
                        <span className="bg-gradient-to-r from-red-500 to-red-600 text-white text-xs px-2 py-1 rounded-full font-medium">
                          MARKET-NEWS
                        </span>
                        <span className="text-muted-foreground text-xs">
                          3 DAYS AGO
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Right side - Large Featured Stock Market article */}
              <div className="lg:col-span-2">
                <div className="block group">
                  <div className="relative h-64 lg:h-96 rounded-2xl overflow-hidden shadow-xl hover:shadow-2xl transition-all duration-500">
                    <Image
                      src="/finance-hero.jpg"
                      alt="Stock Market Analysis Dashboard"
                      fill
                      className="object-cover group-hover:scale-105 transition-transform duration-700"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent" />
                    <div className="absolute top-4 left-4">
                      <span className="bg-green-500/90 backdrop-blur-sm text-white text-sm font-medium px-3 py-1 rounded-full">
                        1 WEEK AGO
                      </span>
                    </div>
                    <div className="absolute bottom-6 left-6 right-6">
                      <h3 className="text-white font-bold text-xl lg:text-3xl leading-tight mb-4">
                        Market volatility creates new investment opportunities
                      </h3>
                      <div className="flex items-center space-x-3 text-white/90">
                        <div className="w-10 h-10 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center">
                          <span className="text-sm">👤</span>
                        </div>
                        <div>
                          <span className="text-sm font-medium">Financial Analyst</span>
                          <span className="text-sm ml-2">• 0 comments</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Banking Section - New enhanced section */}
        <div className="mb-12">
          <div className="flex items-center space-x-3 mb-6">
            <div className="w-1 h-8 bg-blue-500 rounded-full"></div>
            <h2 className="text-2xl lg:text-3xl font-bold text-foreground">Banking & Finance</h2>
          </div>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left side - Banking article list */}
            <div className="lg:col-span-1 space-y-6">
              <div className="space-y-4">
                <div className="flex items-start space-x-3 p-4 bg-card rounded-xl shadow-md hover:shadow-lg transition-all duration-300">
                  <div className="relative w-20 h-16 rounded-lg overflow-hidden flex-shrink-0">
                    <Image
                      src="/financial-analysis.jpg"
                      alt="Banking Services"
                      fill
                      className="object-cover"
                    />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-foreground text-base leading-tight hover:text-blue-600 transition-colors line-clamp-2">
                      Digital banking transformation accelerates globally
                    </h3>
                    <div className="flex items-center space-x-2 mt-2">
                      <span className="bg-gradient-to-r from-blue-500 to-blue-600 text-white text-xs px-2 py-1 rounded-full font-medium">
                        MAIN
                      </span>
                      <span className="text-muted-foreground text-xs">
                        3 WEEKS AGO
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex items-start space-x-3 p-4 bg-card rounded-xl shadow-md hover:shadow-lg transition-all duration-300">
                  <div className="relative w-20 h-16 rounded-lg overflow-hidden flex-shrink-0">
                    <Image
                      src="/crypto-phone-trading.jpg"
                      alt="Mobile Banking"
                      fill
                      className="object-cover"
                    />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-foreground text-base leading-tight hover:text-blue-600 transition-colors line-clamp-2">
                      Central banks explore digital currency implementations
                    </h3>
                    <div className="flex items-center space-x-2 mt-2">
                      <span className="bg-gradient-to-r from-purple-500 to-purple-600 text-white text-xs px-2 py-1 rounded-full font-medium">
                        BANKING-NEWS
                      </span>
                      <span className="text-muted-foreground text-xs">
                        2 WEEKS AGO
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex items-start space-x-3 p-4 bg-card rounded-xl shadow-md hover:shadow-lg transition-all duration-300">
                  <div className="relative w-20 h-16 rounded-lg overflow-hidden flex-shrink-0">
                    <Image
                      src="/stock-charts.jpg"
                      alt="Financial Regulations"
                      fill
                      className="object-cover"
                    />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-foreground text-base leading-tight hover:text-blue-600 transition-colors line-clamp-2">
                      New financial regulations impact lending practices
                    </h3>
                    <div className="flex items-center space-x-2 mt-2">
                      <span className="bg-gradient-to-r from-green-500 to-green-600 text-white text-xs px-2 py-1 rounded-full font-medium">
                        BANKING-NEWS
                      </span>
                      <span className="text-muted-foreground text-xs">
                        1 WEEK AGO
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex items-start space-x-3 p-4 bg-card rounded-xl shadow-md hover:shadow-lg transition-all duration-300">
                  <div className="relative w-20 h-16 rounded-lg overflow-hidden flex-shrink-0">
                    <Image
                      src="/bitcoin-exchange.jpg"
                      alt="Financial Technology"
                      fill
                      className="object-cover"
                    />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-foreground text-base leading-tight hover:text-blue-600 transition-colors line-clamp-2">
                      Fintech startups challenge traditional banking models
                    </h3>
                    <div className="flex items-center space-x-2 mt-2">
                      <span className="bg-gradient-to-r from-orange-500 to-orange-600 text-white text-xs px-2 py-1 rounded-full font-medium">
                        BANKING-NEWS
                      </span>
                      <span className="text-muted-foreground text-xs">
                        4 DAYS AGO
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Right side - Large Featured Banking article */}
            <div className="lg:col-span-2">
              <div className="block group">
                <div className="relative h-64 lg:h-96 rounded-2xl overflow-hidden shadow-xl hover:shadow-2xl transition-all duration-500">
                  <Image
                    src="/crypto-trading-screen.jpg"
                    alt="Digital Banking Revolution"
                    fill
                    className="object-cover group-hover:scale-105 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent" />
                  <div className="absolute top-4 left-4">
                    <span className="bg-blue-500/90 backdrop-blur-sm text-white text-sm font-medium px-3 py-1 rounded-full">
                      2 WEEKS AGO
                    </span>
                  </div>
                  <div className="absolute bottom-6 left-6 right-6">
                    <h3 className="text-white font-bold text-xl lg:text-3xl leading-tight mb-4">
                      Federal Reserve signals potential interest rate changes
                    </h3>
                    <div className="flex items-center space-x-3 text-white/90">
                      <div className="w-10 h-10 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center">
                        <span className="text-sm">👤</span>
                      </div>
                      <div>
                        <span className="text-sm font-medium">Financial Analyst</span>
                        <span className="text-sm ml-2">• 0 comments</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Economic Analysis Section - Enhanced */}
        {economyArticles.length > 0 && (
          <div className="mb-12">
            <div className="flex items-center space-x-3 mb-6">
              <div className="w-1 h-8 bg-purple-500 rounded-full"></div>
              <h2 className="text-2xl lg:text-3xl font-bold text-foreground">Economic Analysis</h2>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Left side - Article list */}
              <div className="lg:col-span-1 space-y-4">
                {economyArticles.slice(0, 3).map((article, index) => (
                  <div key={article._id} className="flex items-start space-x-3 p-4 bg-card rounded-xl shadow-md hover:shadow-lg transition-all duration-300">
                    <div className="relative w-16 h-16 rounded-lg overflow-hidden flex-shrink-0">
                      <Image
                        src={
                          index === 0 ? "/financial-analysis.jpg" :
                          index === 1 ? "/stock-charts.jpg" :
                          "/finance-hero.jpg"
                        }
                        alt={article.title}
                        fill
                        className="object-cover"
                      />
                    </div>
                    <div className="flex-1">
                      <Link href={`/article/${article.slug}`}>
                        <h3 className="font-bold text-foreground text-sm leading-tight hover:text-purple-600 transition-colors line-clamp-2">
                          {article.title}
                        </h3>
                      </Link>
                      <div className="flex items-center space-x-2 mt-1">
                        <span className="bg-gradient-to-r from-purple-500 to-purple-600 text-white text-xs px-2 py-1 rounded-full font-medium">
                          ECONOMY
                        </span>
                        <span className="text-muted-foreground text-xs">
                          {formatTimeAgo(article.publicationDate)}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Right side - Featured Economic article */}
              <div className="lg:col-span-2">
                <div className="block group">
                  <div className="relative h-64 lg:h-80 rounded-2xl overflow-hidden shadow-xl hover:shadow-2xl transition-all duration-500">
                    <Image
                      src="/financial-analysis.jpg"
                      alt="Economic Growth Analysis"
                      fill
                      className="object-cover group-hover:scale-105 transition-transform duration-700"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent" />
                    <div className="absolute top-4 left-4">
                      <span className="bg-purple-500/90 backdrop-blur-sm text-white text-sm font-medium px-3 py-1 rounded-full">
                        1 MONTH AGO
                      </span>
                    </div>
                    <div className="absolute bottom-6 left-6 right-6">
                      <h3 className="text-white font-bold text-xl lg:text-2xl leading-tight mb-4">
                        Global economic outlook shows mixed signals for 2025
                      </h3>
                      <div className="flex items-center space-x-3 text-white/90">
                        <div className="w-10 h-10 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center">
                          <span className="text-sm">👤</span>
                        </div>
                        <div>
                          <span className="text-sm font-medium">Financial Analyst</span>
                          <span className="text-sm ml-2">• 0 comments</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Latest & Popular Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Latest Articles */}
          <div>
            <div className="flex items-center space-x-3 mb-6">
              <div className="w-1 h-8 bg-green-500 rounded-full"></div>
              <h2 className="text-2xl font-bold text-foreground">Latest</h2>
            </div>
            <div className="space-y-4">
              {latestArticles.map((article, index) => (
                <Link key={article._id} href={`/article/${article.slug}`} className="block group">
                  <div className="flex items-start space-x-4 p-4 bg-card rounded-xl shadow-md hover:shadow-lg transition-all duration-300">
                    <div className="relative w-20 h-16 rounded-lg overflow-hidden flex-shrink-0">
                      <Image
                        src={
                          index === 0 ? "/crypto-trading.jpg" :
                          index === 1 ? "/stock-charts.jpg" :
                          "/financial-analysis.jpg"
                        }
                        alt={article.title}
                        fill
                        className="object-cover"
                      />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-bold text-foreground text-base leading-tight group-hover:text-green-600 transition-colors line-clamp-2">
                        {article.title}
                      </h3>
                      <div className="flex items-center space-x-2 mt-2">
                        <span className="bg-gradient-to-r from-green-500 to-green-600 text-white text-xs px-2 py-1 rounded-full font-medium">
                          FINANCE
                        </span>
                        <span className="text-muted-foreground text-xs">
                          {formatTimeAgo(article.publicationDate)}
                        </span>
                      </div>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>

          {/* Popular Articles */}
          <div>
            <div className="flex items-center space-x-3 mb-6">
              <div className="w-1 h-8 bg-orange-500 rounded-full"></div>
              <h2 className="text-2xl font-bold text-foreground">Popular</h2>
            </div>
            <div className="space-y-4">
              {popularArticles.map((article, index) => (
                <div key={index} className="flex items-start space-x-4 p-4 bg-card rounded-xl shadow-md hover:shadow-lg transition-all duration-300 group cursor-pointer">
                  <div className="relative w-20 h-16 rounded-lg overflow-hidden flex-shrink-0">
                    <Image
                      src={
                        index === 0 ? "/crypto-bitcoin-gold.jpg" :
                        index === 1 ? "/finance-hero.jpg" :
                        "/stock-charts.jpg"
                      }
                      alt={article.title}
                      fill
                      className="object-cover"
                    />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-bold text-foreground text-base leading-tight group-hover:text-orange-600 transition-colors line-clamp-2">
                      {article.title}
                    </h3>
                    <div className="flex items-center space-x-2 mt-2">
                      <span className="bg-gradient-to-r from-orange-500 to-orange-600 text-white text-xs px-2 py-1 rounded-full font-medium">
                        FINANCE
                      </span>
                      <span className="text-muted-foreground text-xs">
                        {article.time}
                      </span>
                      <span className="text-muted-foreground text-xs">
                        {article.views} views
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}




