















































"use client";

import { usePreloadedQuery } from "convex/react";
import { api } from "@/convex/_generated/api";
import { Preloaded } from "convex/react";
import Image from "next/image";
import Link from "next/link";

interface HomePageContentProps {
  preloadedData: Preloaded<typeof api.articles.getHomepageData>;
}

export default function HomePageContent({ preloadedData }: HomePageContentProps) {
  const { articles, categories } = usePreloadedQuery(preloadedData);

  // Helper function to get articles by category
  const getArticlesByCategory = (categoryName: string, limit: number = 4) => {
    const category = categories.find(cat => cat.name.toLowerCase().includes(categoryName.toLowerCase()));
    if (!category) return [];
    
    return articles
      .filter(article => article.category === category._id)
      .slice(0, limit);
  };

  // Helper function to format date
  const formatDate = (timestamp: number) => {
    const now = Date.now();
    const diff = now - timestamp;
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    const months = Math.floor(days / 30);
    
    if (months > 0) return `${months} month${months > 1 ? 's' : ''} ago`;
    if (days > 0) return `${days} day${days > 1 ? 's' : ''} ago`;
    return 'Today';
  };

  // Helper function to get image URL
  const getImageUrl = (article: any) => {
    if (article.featuredImageStorageId) {
      return `/api/storage/${article.featuredImageStorageId}`;
    }
    // Fallback images based on category or default
    return "https://images.pexels.com/photos/163064/play-stone-network-networked-interactive-163064.jpeg";
  };

  // Get different categories of articles - optimized
  const politicalArticles = getArticlesByCategory("political", 2); // Reduced from 4 to 2
  const sportArticles = getArticlesByCategory("sport", 2); // Reduced from 4 to 2
  const techArticles = getArticlesByCategory("tech", 2); // Reduced from 4 to 2
  const financeArticles = getArticlesByCategory("finance", 2); // Reduced from 4 to 2
  const gamingArticles = getArticlesByCategory("gaming", 2); // Reduced from 4 to 2
  const travelArticles = getArticlesByCategory("travel", 2); // Reduced from 4 to 2
  const hotNewsArticles = articles.slice(0, 3); // Reduced from 5 to 3
  
  // Get featured articles (first few articles for hero sections)
  const heroArticle = articles.find(a => a.isFeatured) || articles[0];
  const latestTopics = articles.slice(0, 8);

  return (
    <div className="min-h-screen bg-background">
      {/* Top Section: Political News + Hero + Sport News */}
      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          
          {/* Left Sidebar - Political News */}
          <div className="lg:col-span-1">
            <h2 className="text-lg font-bold text-foreground mb-4 pb-2 border-b-2 border-red-600 uppercase">
              POLITICAL NEWS
            </h2>
            <div>
              {politicalArticles.length > 0 ? politicalArticles.map((article) => (
                <Link key={article._id} href={`/article/${article.slug}`} className="block mb-8">
                  <article className="group cursor-pointer">
                    <div className="flex space-x-3">
                      <Image
                        src={getImageUrl(article)}
                        alt={article.title}
                        width={80}
                        height={60}
                        className="rounded object-cover flex-shrink-0"
                      />
                      <div className="flex-1">
                        <h3 className="text-sm font-semibold text-foreground line-clamp-2 group-hover:text-red-600 transition-colors">
                          {article.title}
                        </h3>
                        <p className="text-xs text-muted-foreground mt-1">{formatDate(article.publicationDate)}</p>
                      </div>
                    </div>
                  </article>
                </Link>
              )) : (
                <>
                  <article className="group mb-8">
                    <div className="flex space-x-3">
                      <Image
                        src="https://images.pexels.com/photos/6077326/pexels-photo-6077326.jpeg"
                        alt="Political news"
                        width={80}
                        height={60}
                        className="rounded object-cover flex-shrink-0"
                      />
                      <div className="flex-1">
                        <h3 className="text-sm font-semibold text-foreground line-clamp-2 group-hover:text-red-600 transition-colors">
                          Judge allows DOGE team limited access to sensitive...
                        </h3>
                        <p className="text-xs text-muted-foreground mt-1">3 months ago</p>
                      </div>
                    </div>
                  </article>
                  <article className="group mb-8">
                    <div className="flex space-x-3">
                      <Image
                        src="https://images.pexels.com/photos/6077326/pexels-photo-6077326.jpeg"
                        alt="Political news"
                        width={80}
                        height={60}
                        className="rounded object-cover flex-shrink-0"
                      />
                      <div className="flex-1">
                        <h3 className="text-sm font-semibold text-foreground line-clamp-2 group-hover:text-red-600 transition-colors">
                          Trump's IG picks spark backlash over scandals, partisanship
                        </h3>
                        <p className="text-xs text-muted-foreground mt-1">3 months ago</p>
                      </div>
                    </div>
                  </article>
                  <article className="group mb-8">
                    <div className="flex space-x-3">
                      <Image
                        src="https://images.pexels.com/photos/6077326/pexels-photo-6077326.jpeg"
                        alt="Political news"
                        width={80}
                        height={60}
                        className="rounded object-cover flex-shrink-0"
                      />
                      <div className="flex-1">
                        <h3 className="text-sm font-semibold text-foreground line-clamp-2 group-hover:text-red-600 transition-colors">
                          Iran warns it may end nuclear talks over UK envoy's uranium...
                        </h3>
                        <p className="text-xs text-muted-foreground mt-1">3 months ago</p>
                      </div>
                    </div>
                  </article>
                  <article className="group">
                    <div className="flex space-x-3">
                      <Image
                        src="https://images.pexels.com/photos/6077326/pexels-photo-6077326.jpeg"
                        alt="Political news"
                        width={80}
                        height={60}
                        className="rounded object-cover flex-shrink-0"
                      />
                      <div className="flex-1">
                        <h3 className="text-sm font-semibold text-foreground line-clamp-2 group-hover:text-red-600 transition-colors">
                          Police consulted on early release reforms, UK...
                        </h3>
                        <p className="text-xs text-muted-foreground mt-1">3 months ago</p>
                      </div>
                    </div>
                  </article>
                </>
              )}
            </div>
          </div>

          {/* Center - Hero Article */}
          <div className="lg:col-span-2">
            {heroArticle ? (
              <Link href={`/article/${heroArticle.slug}`}>
                <div className="relative h-[400px] rounded-lg overflow-hidden group cursor-pointer">
                  <Image
                    src="https://images.pexels.com/photos/163064/play-stone-network-networked-interactive-163064.jpeg"
                    alt={heroArticle.title}
                    fill
                    className="object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                  <div className="absolute bottom-0 left-0 right-0 p-6">
                    <div className="flex items-center mb-2">
                      <span className="text-white/80 text-sm">3 months ago</span>
                    </div>
                    <h1 className="text-white text-2xl md:text-3xl font-bold leading-tight mb-3">
                      AI vs Human Jobs: Automation Trends Across...
                    </h1>
                    <div className="flex items-center">
                      <Image
                        src="https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg"
                        alt="Author"
                        width={24}
                        height={24}
                        className="rounded-full mr-2 border border-white/20"
                      />
                      <span className="text-white text-sm">ksandr Vovchok</span>
                      <span className="text-white/60 text-sm ml-3">• 0</span>
                    </div>
                  </div>
                </div>
              </Link>
            ) : (
              <div className="relative h-[400px] rounded-lg overflow-hidden group cursor-pointer">
                <Image
                  src="https://images.pexels.com/photos/163064/play-stone-network-networked-interactive-163064.jpeg"
                  alt="Featured Article"
                  fill
                  className="object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                <div className="absolute bottom-0 left-0 right-0 p-6">
                  <div className="flex items-center mb-2">
                    <span className="text-white/80 text-sm">3 months ago</span>
                  </div>
                  <h1 className="text-white text-2xl md:text-3xl font-bold leading-tight mb-3">
                    AI vs Human Jobs: Automation Trends Across...
                  </h1>
                  <div className="flex items-center">
                    <Image
                      src="https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg"
                      alt="Author"
                      width={24}
                      height={24}
                      className="rounded-full mr-2 border border-white/20"
                    />
                    <span className="text-white text-sm">ksandr Vovchok</span>
                    <span className="text-white/60 text-sm ml-3">• 0</span>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Right Sidebar - Sport News */}
          <div className="lg:col-span-1">
            <h2 className="text-lg font-bold text-foreground mb-4 pb-2 border-b-2 border-red-600 uppercase">
              SPORT-NEWS
            </h2>
            <div>
              {sportArticles.length > 0 ? sportArticles.map((article) => (
                <Link key={article._id} href={`/article/${article.slug}`} className="block mb-8">
                  <article className="group cursor-pointer">
                    <div className="flex space-x-3">
                      <Image
                        src={getImageUrl(article)}
                        alt={article.title}
                        width={80}
                        height={60}
                        className="rounded object-cover flex-shrink-0"
                      />
                      <div className="flex-1">
                        <h3 className="text-sm font-semibold text-foreground line-clamp-2 group-hover:text-red-600 transition-colors">
                          {article.title}
                        </h3>
                        <p className="text-xs text-muted-foreground mt-1">{formatDate(article.publicationDate)}</p>
                      </div>
                    </div>
                  </article>
                </Link>
              )) : (
                <>
                  <article className="group mb-8">
                    <div className="flex space-x-3">
                      <Image
                        src="https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg"
                        alt="Sport news"
                        width={80}
                        height={60}
                        className="rounded object-cover flex-shrink-0"
                      />
                      <div className="flex-1">
                        <h3 className="text-sm font-semibold text-foreground line-clamp-2 group-hover:text-red-600 transition-colors">
                          June 2025 Football Transfer Window: Key Dates and Top...
                        </h3>
                        <p className="text-xs text-muted-foreground mt-1">2 months ago</p>
                      </div>
                    </div>
                  </article>
                  <article className="group mb-8">
                    <div className="flex space-x-3">
                      <Image
                        src="https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg"
                        alt="Sport news"
                        width={80}
                        height={60}
                        className="rounded object-cover flex-shrink-0"
                      />
                      <div className="flex-1">
                        <h3 className="text-sm font-semibold text-foreground line-clamp-2 group-hover:text-red-600 transition-colors">
                          Inter Milan's 2025/26 Away Kit Champions Inclusion and...
                        </h3>
                        <p className="text-xs text-muted-foreground mt-1">2 months ago</p>
                      </div>
                    </div>
                  </article>
                  <article className="group mb-8">
                    <div className="flex space-x-3">
                      <Image
                        src="https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg"
                        alt="Sport news"
                        width={80}
                        height={60}
                        className="rounded object-cover flex-shrink-0"
                      />
                      <div className="flex-1">
                        <h3 className="text-sm font-semibold text-foreground line-clamp-2 group-hover:text-red-600 transition-colors">
                          Thomas Frank's Tottenham Challenge: Winning Trust and...
                        </h3>
                        <p className="text-xs text-muted-foreground mt-1">2 months ago</p>
                      </div>
                    </div>
                  </article>
                  <article className="group">
                    <div className="flex space-x-3">
                      <Image
                        src="https://images.pexels.com/photos/274506/pexels-photo-274506.jpeg"
                        alt="Sport news"
                        width={80}
                        height={60}
                        className="rounded object-cover flex-shrink-0"
                      />
                      <div className="flex-1">
                        <h3 className="text-sm font-semibold text-foreground line-clamp-2 group-hover:text-red-600 transition-colors">
                          Paul Pogba in Advanced Monaco Talks After Doping Ban
                        </h3>
                        <p className="text-xs text-muted-foreground mt-1">2 months ago</p>
                      </div>
                    </div>
                  </article>
                </>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* HOT NEWS Section */}
      <div className="bg-muted py-8">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-2xl font-bold text-foreground mb-6 uppercase">HOT NEWS</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
            {hotNewsArticles.length > 0 ? hotNewsArticles.map((article, index) => (
              <Link key={article._id} href={`/article/${article.slug}`}>
                <article className="bg-card rounded-lg overflow-hidden shadow-sm group cursor-pointer">
                  <Image
                    src={index === 0 ? "https://images.pexels.com/photos/163064/play-stone-network-networked-interactive-163064.jpeg" :
                          index === 1 ? "https://images.pexels.com/photos/259027/pexels-photo-259027.jpeg" :
                          index === 2 ? "https://images.pexels.com/photos/6077326/pexels-photo-6077326.jpeg" :
                          index === 3 ? "https://images.pexels.com/photos/163064/play-stone-network-networked-interactive-163064.jpeg" :
                          "https://images.pexels.com/photos/1371360/pexels-photo-1371360.jpeg"}
                    alt={article.title}
                    width={300}
                    height={150}
                    className="w-full h-32 object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="p-3">
                    <h3 className="text-sm font-semibold text-card-foreground line-clamp-2 group-hover:text-red-600 transition-colors mb-2">
                      {index === 0 ? "Rise and Fall of Tech Unicorns (2010–2025) – Data-Driven..." :
                       index === 1 ? "Geo-Economic Consequences of the Russia-Ukraine War..." :
                       index === 2 ? "Trump Threatens Harvard's Tax-Exempt Status Over..." :
                       index === 3 ? "India launches Operation Sindoor, targets militant sites..." :
                       "Russian Missile Strike on Kryvyi Rih Kills14, Including..."}
                    </h3>
                    <div className="flex items-center text-xs text-muted-foreground">
                      <span>{index === 0 ? "3 months ago" : index === 1 ? "5 months ago" : index === 2 ? "3 months ago" : index === 3 ? "3 months ago" : "4 months ago"}</span>
                      <span className="ml-2">• 0</span>
                    </div>
                  </div>
                </article>
              </Link>
            )) : (
              <>
                <article className="bg-card rounded-lg overflow-hidden shadow-sm group">
                  <Image
                    src="https://images.pexels.com/photos/163064/play-stone-network-networked-interactive-163064.jpeg"
                    alt="Hot News"
                    width={300}
                    height={150}
                    className="w-full h-32 object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="p-3">
                    <h3 className="text-sm font-semibold text-card-foreground line-clamp-2 group-hover:text-red-600 transition-colors mb-2">
                      Rise and Fall of Tech Unicorns (2010–2025) – Data-Driven...
                    </h3>
                    <div className="flex items-center text-xs text-muted-foreground">
                      <span>3 months ago</span>
                      <span className="ml-2">• 0</span>
                    </div>
                  </div>
                </article>
                <article className="bg-card rounded-lg overflow-hidden shadow-sm group">
                  <Image
                    src="https://images.pexels.com/photos/259027/pexels-photo-259027.jpeg"
                    alt="Hot News"
                    width={300}
                    height={150}
                    className="w-full h-32 object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="p-3">
                    <h3 className="text-sm font-semibold text-card-foreground line-clamp-2 group-hover:text-red-600 transition-colors mb-2">
                      Geo-Economic Consequences of the Russia-Ukraine War...
                    </h3>
                    <div className="flex items-center text-xs text-muted-foreground">
                      <span>5 months ago</span>
                      <span className="ml-2">• 0</span>
                    </div>
                  </div>
                </article>
                <article className="bg-card rounded-lg overflow-hidden shadow-sm group">
                  <Image
                    src="https://images.pexels.com/photos/6077326/pexels-photo-6077326.jpeg"
                    alt="Hot News"
                    width={300}
                    height={150}
                    className="w-full h-32 object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="p-3">
                    <h3 className="text-sm font-semibold text-card-foreground line-clamp-2 group-hover:text-red-600 transition-colors mb-2">
                      Trump Threatens Harvard's Tax-Exempt Status Over...
                    </h3>
                    <div className="flex items-center text-xs text-muted-foreground">
                      <span>3 months ago</span>
                      <span className="ml-2">• 0</span>
                    </div>
                  </div>
                </article>
                <article className="bg-card rounded-lg overflow-hidden shadow-sm group">
                  <Image
                    src="https://images.pexels.com/photos/163064/play-stone-network-networked-interactive-163064.jpeg"
                    alt="Hot News"
                    width={300}
                    height={150}
                    className="w-full h-32 object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="p-3">
                    <h3 className="text-sm font-semibold text-card-foreground line-clamp-2 group-hover:text-red-600 transition-colors mb-2">
                      India launches Operation Sindoor, targets militant sites...
                    </h3>
                    <div className="flex items-center text-xs text-muted-foreground">
                      <span>3 months ago</span>
                      <span className="ml-2">• 0</span>
                    </div>
                  </div>
                </article>
                <article className="bg-card rounded-lg overflow-hidden shadow-sm group">
                  <Image
                    src="https://images.pexels.com/photos/1371360/pexels-photo-1371360.jpeg"
                    alt="Hot News"
                    width={300}
                    height={150}
                    className="w-full h-32 object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                  <div className="p-3">
                    <h3 className="text-sm font-semibold text-card-foreground line-clamp-2 group-hover:text-red-600 transition-colors mb-2">
                      Russian Missile Strike on Kryvyi Rih Kills14, Including...
                    </h3>
                    <div className="flex items-center text-xs text-muted-foreground">
                      <span>4 months ago</span>
                      <span className="ml-2">• 0</span>
                    </div>
                  </div>
                </article>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Category Sections Grid */}
      <div className="py-8">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
            
            {/* GAMING-NEWS */}
            <div>
              <h2 className="text-lg font-bold text-foreground mb-4 pb-2 border-b-2 border-red-600 uppercase">
                GAMING-NEWS
              </h2>
              <div>
                <Link href="/article/the-last-of-us-season-2" className="block mb-8">
                  <article className="group cursor-pointer">
                    <div className="flex space-x-3">
                      <Image
                        src="https://images.pexels.com/photos/163064/play-stone-network-networked-interactive-163064.jpeg"
                        alt="Gaming news"
                        width={80}
                        height={60}
                        className="rounded object-cover flex-shrink-0"
                      />
                      <div className="flex-1">
                        <h3 className="text-sm font-semibold text-foreground line-clamp-2 group-hover:text-red-600 transition-colors">
                          The Last of Us Season 2 Steelbook 4K Blu-ray Preorders Now Live
                        </h3>
                        <p className="text-xs text-muted-foreground mt-1">3 months ago</p>
                      </div>
                    </div>
                  </article>
                </Link>
                <Link href="/article/billie-eilish-tour" className="block mb-8">
                  <article className="group cursor-pointer">
                    <div className="flex space-x-3">
                      <Image
                        src="https://images.pexels.com/photos/163064/play-stone-network-networked-interactive-16d064.jpeg"
                        alt="Gaming news"
                        width={80}
                        height={60}
                        className="rounded object-cover flex-shrink-0"
                      />
                      <div className="flex-1">
                        <h3 className="text-sm font-semibold text-foreground line-clamp-2 group-hover:text-red-600 transition-colors">
                          Billie Eilish Adds 2025 U.S. and Japan Tour Dates to Hit Me Hard and Soft...
                        </h3>
                        <p className="text-xs text-muted-foreground mt-1">3 months ago</p>
                      </div>
                    </div>
                  </article>
                </Link>
                <Link href="/article/assassins-creed-shadows" className="block mb-8">
                  <article className="group cursor-pointer">
                    <div className="flex space-x-3">
                      <Image
                        src="https://images.pexels.com/photos/163064/play-stone-network-networked-interactive-163064.jpeg"
                        alt="Gaming news"
                        width={80}
                        height={60}
                        className="rounded object-cover flex-shrink-0"
                      />
                      <div className="flex-1">
                        <h3 className="text-sm font-semibold text-foreground line-clamp-2 group-hover:text-red-600 transition-colors">
                          How to Defeat The Ox in Assassin's Creed Shadows – Complete Boss...
                        </h3>
                        <p className="text-xs text-muted-foreground mt-1">3 months ago</p>
                      </div>
                    </div>
                  </article>
                </Link>
                <Link href="/article/clair-obscur-expedition" className="block">
                  <article className="group cursor-pointer">
                    <div className="flex space-x-3">
                      <Image
                        src="https://images.pexels.com/photos/163064/play-stone-network-networked-interactive-163064.jpeg"
                        alt="Gaming news"
                        width={80}
                        height={60}
                        className="rounded object-cover flex-shrink-0"
                      />
                      <div className="flex-1">
                        <h3 className="text-sm font-semibold text-foreground line-clamp-2 group-hover:text-red-600 transition-colors">
                          Clair Obscur: Expedition 33 – Should you Attack Troubadour?
                        </h3>
                        <p className="text-xs text-muted-foreground mt-1">3 months ago</p>
                      </div>
                    </div>
                  </article>
                </Link>
              </div>
            </div>

            {/* FINANCE-NEWS */}
            <div>
              <h2 className="text-lg font-bold text-foreground mb-4 pb-2 border-b-2 border-red-600 uppercase">
                FINANCE-NEWS
              </h2>
              <div>
                <Link href="/article/bank-of-america-profit" className="block mb-8">
                  <article className="group cursor-pointer">
                    <div className="flex space-x-3">
                      <Image
                        src="https://images.pexels.com/photos/259027/pexels-photo-259027.jpeg"
                        alt="Finance news"
                        width={80}
                        height={60}
                        className="rounded object-cover flex-shrink-0"
                      />
                      <div className="flex-1">
                        <h3 className="text-sm font-semibold text-foreground line-clamp-2 group-hover:text-red-600 transition-colors">
                          Bank of America Profit Jumps 10%, CEO Cautions on Economy
                        </h3>
                        <p className="text-xs text-muted-foreground mt-1">3 months ago</p>
                      </div>
                    </div>
                  </article>
                </Link>
                <Link href="/article/rivian-stock" className="block mb-8">
                  <article className="group cursor-pointer">
                    <div className="flex space-x-3">
                      <Image
                        src="https://images.pexels.com/photos/259027/pexels-photo-259027.jpeg"
                        alt="Finance news"
                        width={80}
                        height={60}
                        className="rounded object-cover flex-shrink-0"
                      />
                      <div className="flex-1">
                        <h3 className="text-sm font-semibold text-foreground line-clamp-2 group-hover:text-red-600 transition-colors">
                          Should You Buy Rivian Stock Under $20? Here's What to Know in 2025
                        </h3>
                        <p className="text-xs text-muted-foreground mt-1">3 months ago</p>
                      </div>
                    </div>
                  </article>
                </Link>
                <Link href="/article/jcpenney-stores" className="block">
                  <article className="group cursor-pointer">
                    <div className="flex space-x-3">
                      <Image
                        src="https://images.pexels.com/photos/259027/pexels-photo-259027.jpeg"
                        alt="Finance news"
                        width={80}
                        height={60}
                        className="rounded object-cover flex-shrink-0"
                      />
                      <div className="flex-1">
                        <h3 className="text-sm font-semibold text-foreground line-clamp-2 group-hover:text-red-600 transition-colors">
                          JCPenney to Close 7 U.S. Stores on May 25 Amid Ongoing Restructuring
                        </h3>
                        <p className="text-xs text-muted-foreground mt-1">3 months ago</p>
                      </div>
                    </div>
                  </article>
                </Link>
              </div>
            </div>

            {/* Ukraine's allies plan post-war security mission - Featured */}
            <div>
              <div className="relative h-[300px] rounded-lg overflow-hidden group cursor-pointer">
                <Image
                  src="https://images.pexels.com/photos/1371360/pexels-photo-1371360.jpeg"
                  alt="Ukraine security mission"
                  fill
                  className="object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                <div className="absolute bottom-0 left-0 right-0 p-6">
                  <div className="flex items-center mb-2">
                    <span className="text-white/80 text-sm">4 months ago</span>
                  </div>
                  <h1 className="text-white text-xl font-bold leading-tight mb-3">
                    Ukraine's allies plan post-war security mission...
                  </h1>
                  <div className="flex items-center">
                    <Image
                      src="https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg"
                      alt="Author"
                      width={24}
                      height={24}
                      className="rounded-full mr-2 border border-white/20"
                    />
                    <span className="text-white text-sm">ksandr Vovchok</span>
                    <span className="text-white/60 text-sm ml-3">• 0</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Second Row of Categories */}
      <div className="bg-muted py-8">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
            
            {/* TECH-NEWS */}
            <div>
              <div className="relative h-[200px] rounded-lg overflow-hidden group cursor-pointer mb-4">
                <Image
                  src="https://images.pexels.com/photos/163064/play-stone-network-networked-interactive-163064.jpeg"
                  alt="Tech news"
                  fill
                  className="object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                <div className="absolute bottom-0 left-0 right-0 p-4">
                  <div className="flex items-center mb-2">
                    <span className="text-white/80 text-sm">2 months ago</span>
                  </div>
                  <h3 className="text-white text-lg font-bold leading-tight mb-2">
                    Microwaves Reveal Real-World "Imaginary Time" via Frequency...
                  </h3>
                  <div className="flex items-center">
                    <Image
                      src="https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg"
                      alt="Author"
                      width={20}
                      height={20}
                      className="rounded-full mr-2 border border-white/20"
                    />
                    <span className="text-white text-sm">Pavlo Kulakov</span>
                    <span className="text-white/60 text-sm ml-3">• 0</span>
                  </div>
                </div>
              </div>
              
              <div>
                <Link href="/article/ultracold-atoms" className="block mb-8">
                  <article className="group cursor-pointer">
                    <div className="flex space-x-3">
                      <Image
                        src="https://images.pexels.com/photos/163064/play-stone-network-networked-interactive-163064.jpeg"
                        alt="Tech news"
                        width={80}
                        height={60}
                        className="rounded object-cover flex-shrink-0"
                      />
                      <div className="flex-1">
                        <h3 className="text-sm font-semibold text-foreground line-clamp-2 group-hover:text-red-600 transition-colors">
                          Ultracold atoms achieve hyperentanglement in quantum...
                        </h3>
                        <p className="text-xs text-muted-foreground mt-1">3 months ago</p>
                      </div>
                    </div>
                  </article>
                </Link>
                <Link href="/article/deepseek" className="block mb-8">
                  <article className="group cursor-pointer">
                    <div className="flex space-x-3">
                      <Image
                        src="https://images.pexels.com/photos/163064/play-stone-network-networked-interactive-163064.jpeg"
                        alt="Tech news"
                        width={80}
                        height={60}
                        className="rounded object-cover flex-shrink-0"
                      />
                      <div className="flex-1">
                        <h3 className="text-sm font-semibold text-foreground line-clamp-2 group-hover:text-red-600 transition-colors">
                          What is DeepSeek? The Chinese AI app challenging global tech giants
                        </h3>
                        <p className="text-xs text-muted-foreground mt-1">3 months ago</p>
                      </div>
                    </div>
                  </article>
                </Link>
                <Link href="/article/quantum-computers" className="block">
                  <article className="group cursor-pointer">
                    <div className="flex space-x-3">
                      <Image
                        src="https://images.pexels.com/photos/163064/play-stone-network-networked-interactive-163064.jpeg"
                        alt="Tech news"
                        width={80}
                        height={60}
                        className="rounded object-cover flex-shrink-0"
                      />
                      <div className="flex-1">
                        <h3 className="text-sm font-semibold text-foreground line-clamp-2 group-hover:text-red-600 transition-colors">
                          Quantum computers could break RSA encryption with fewer than a million...
                        </h3>
                        <p className="text-xs text-muted-foreground mt-1">3 months ago</p>
                      </div>
                    </div>
                  </article>
                </Link>
              </div>
            </div>

            {/* FINANCE-NEWS */}
            <div>
              <div className="relative h-[200px] rounded-lg overflow-hidden group cursor-pointer mb-4">
                <Image
                  src="https://images.pexels.com/photos/259027/pexels-photo-259027.jpeg"
                  alt="Finance news"
                  fill
                  className="object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                <div className="absolute bottom-0 left-0 right-0 p-4">
                  <div className="flex items-center mb-2">
                    <span className="text-white/80 text-sm">2 months ago</span>
                  </div>
                  <h3 className="text-white text-lg font-bold leading-tight mb-2">
                    $300 million in Trump meme coins unlock as token drops 90% from...
                  </h3>
                  <div className="flex items-center">
                    <Image
                      src="https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg"
                      alt="Author"
                      width={20}
                      height={20}
                      className="rounded-full mr-2 border border-white/20"
                    />
                    <span className="text-white text-sm">Sam Davenport</span>
                    <span className="text-white/60 text-sm ml-3">• 0</span>
                  </div>
                </div>
              </div>
              
              <div>
                <Link href="/article/bank-of-america-profit">
                  <article className="group cursor-pointer">
                    <div className="flex space-x-3">
                      <Image
                        src="https://images.pexels.com/photos/259027/pexels-photo-259027.jpeg"
                        alt="Finance news"
                        width={80}
                        height={60}
                        className="rounded object-cover flex-shrink-0"
                      />
                      <div className="flex-1">
                        <h3 className="text-sm font-semibold text-foreground line-clamp-2 group-hover:text-red-600 transition-colors">
                          Bank of America Profit Jumps 10%, CEO Cautions on Economy
                        </h3>
                        <p className="text-xs text-muted-foreground mt-1">3 months ago</p>
                      </div>
                    </div>
                  </article>
                </Link>
                <Link href="/article/rivian-stock">
                  <article className="group cursor-pointer">
                    <div className="flex space-x-3">
                      <Image
                        src="https://images.pexels.com/photos/259027/pexels-photo-259027.jpeg"
                        alt="Finance news"
                        width={80}
                        height={60}
                        className="rounded object-cover flex-shrink-0"
                      />
                      <div className="flex-1">
                        <h3 className="text-sm font-semibold text-foreground line-clamp-2 group-hover:text-red-600 transition-colors">
                          Should You Buy Rivian Stock Under $20? Here's What to Know in 2025
                        </h3>
                        <p className="text-xs text-muted-foreground mt-1">3 months ago</p>
                      </div>
                    </div>
                  </article>
                </Link>
                <Link href="/article/jcpenney-stores">
                  <article className="group cursor-pointer">
                    <div className="flex space-x-3">
                      <Image
                        src="https://images.pexels.com/photos/259027/pexels-photo-259027.jpeg"
                        alt="Finance news"
                        width={80}
                        height={60}
                        className="rounded object-cover flex-shrink-0"
                      />
                      <div className="flex-1">
                        <h3 className="text-sm font-semibold text-foreground line-clamp-2 group-hover:text-red-600 transition-colors">
                          JCPenney to Close 7 U.S. Stores on May 25 Amid Ongoing Restructuring
                        </h3>
                        <p className="text-xs text-muted-foreground mt-1">3 months ago</p>
                      </div>
                    </div>
                  </article>
                </Link>
              </div>
            </div>

            {/* TRAVEL-NEWS */}
            <div>
              <div className="relative h-[200px] rounded-lg overflow-hidden group cursor-pointer mb-4">
                <Image
                  src="https://images.pexels.com/photos/1371360/pexels-photo-1371360.jpeg"
                  alt="Travel news"
                  fill
                  className="object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                <div className="absolute bottom-0 left-0 right-0 p-4">
                  <div className="flex items-center mb-2">
                    <span className="text-white/80 text-sm">3 months ago</span>
                  </div>
                  <h3 className="text-white text-lg font-bold leading-tight mb-2">
                    Best Day Trips from Toronto in 2025 – Top 24 Weekend Escapes
                  </h3>
                  <div className="flex items-center">
                    <Image
                      src="https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg"
                      alt="Author"
                      width={20}
                      height={20}
                      className="rounded-full mr-2 border border-white/20"
                    />
                    <span className="text-white text-sm">Sam Walker</span>
                    <span className="text-white/60 text-sm ml-3">• 0</span>
                  </div>
                </div>
              </div>
              
              <div>
                <Link href="/article/latam-flights" className="block mb-8">
                  <article className="group cursor-pointer">
                    <div className="flex space-x-3">
                      <Image
                        src="https://images.pexels.com/photos/1371360/pexels-photo-1371360.jpeg"
                        alt="Travel news"
                        width={80}
                        height={60}
                        className="rounded object-cover flex-shrink-0"
                      />
                      <div className="flex-1">
                        <h3 className="text-sm font-semibold text-foreground line-clamp-2 group-hover:text-red-600 transition-colors">
                          LATAM Restores Daily Miami–Buenos Aires Flights With 787
                        </h3>
                        <p className="text-xs text-muted-foreground mt-1">3 months ago</p>
                      </div>
                    </div>
                  </article>
                </Link>
                <Link href="/article/puglia-road-trip" className="block mb-8">
                  <article className="group cursor-pointer">
                    <div className="flex space-x-3">
                      <Image
                        src="https://images.pexels.com/photos/1371360/pexels-photo-1371360.jpeg"
                        alt="Travel news"
                        width={80}
                        height={60}
                        className="rounded object-cover flex-shrink-0"
                      />
                      <div className="flex-1">
                        <h3 className="text-sm font-semibold text-foreground line-clamp-2 group-hover:text-red-600 transition-colors">
                          This Off-the-Radar Road Trip Through Puglia and Basilicata Is Italy's Best-...
                        </h3>
                        <p className="text-xs text-muted-foreground mt-1">4 months ago</p>
                      </div>
                    </div>
                  </article>
                </Link>
                <Link href="/article/kentucky-bourbon-trail" className="block">
                  <article className="group cursor-pointer">
                    <div className="flex space-x-3">
                      <Image
                        src="https://images.pexels.com/photos/1371360/pexels-photo-1371360.jpeg"
                        alt="Travel news"
                        width={80}
                        height={60}
                        className="rounded object-cover flex-shrink-0"
                      />
                      <div className="flex-1">
                        <h3 className="text-sm font-semibold text-foreground line-clamp-2 group-hover:text-red-600 transition-colors">
                          The Ultimate Guide to the Kentucky Bourbon Trail in 2025
                        </h3>
                        <p className="text-xs text-muted-foreground mt-1">4 months ago</p>
                      </div>
                    </div>
                  </article>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Latest Topics Section */}
      <div className="py-8">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-10">
            
            {/* Latest Topics */}
            <div className="lg:col-span-3">
              <h2 className="text-2xl font-bold text-foreground mb-8 uppercase">LATEST TOPICS</h2>
              
              <div>
                {latestTopics.length > 0 ? latestTopics.map((article, index) => (
                  <Link key={article._id} href={`/article/${article.slug}`} className="block mb-8">
                    <article className="bg-white dark:bg-gray-700 rounded-lg shadow-sm overflow-hidden group cursor-pointer border dark:border-gray-600">
                      <div className="flex flex-col md:flex-row">
                        <div className="md:w-1/3">
                          <Image
                            src={index === 0 ? "https://images.pexels.com/photos/163064/play-stone-network-networked-interactive-163064.jpeg" :
                                  index === 1 ? "https://images.pexels.com/photos/163064/play-stone-network-networked-interactive-163064.jpeg" :
                                  index === 2 ? "https://images.pexels.com/photos/6077326/pexels-photo-6077326.jpeg" :
                                  index === 3 ? "https://images.pexels.com/photos/163064/play-stone-network-networked-interactive-163064.jpeg" :
                                  index === 4 ? "https://images.pexels.com/photos/163064/play-stone-network-networked-interactive-163064.jpeg" :
                                  index === 5 ? "https://images.pexels.com/photos/163064/play-stone-network-networked-interactive-163064.jpeg" :
                                  index === 6 ? "https://images.pexels.com/photos/163064/play-stone-network-networked-interactive-163064.jpeg" :
                                  "https://images.pexels.com/photos/1371360/pexels-photo-1371360.jpeg"}
                            alt={article.title}
                            width={300}
                            height={200}
                            className="w-full h-48 md:h-full object-cover group-hover:scale-105 transition-transform duration-300"
                          />
                        </div>
                        <div className="md:w-2/3 p-6">
                          <h3 className="text-xl font-bold text-foreground mb-3 group-hover:text-red-600 transition-colors">
                            {index === 0 ? "Spain and Portugal blackouts spark cyberattack concerns across Europe" :
                             index === 1 ? "Microchips and Global Power: The New Geopolitical Battlefield" :
                             index === 2 ? "Trump Threatens Harvard's Tax-Exempt Status Over..." :
                             index === 3 ? "New Orleans Jail Worker Helped Inmate Escape After Threats, Officials Say" :
                             index === 4 ? "Why Art Exhibitions Still Matter in 2025: Creativity, Community, and Calm" :
                             index === 5 ? "India launches Operation Sindoor, targets militant sites in Pakistan" :
                             index === 6 ? "Germany defends AfD extremist label after U.S. backlash over 'tyranny' claims" :
                             "Israel strikes near Syria's presidential palace amid Druze unrest"}
                          </h3>
                          <p className="text-gray-600 dark:text-gray-300 mb-4">
                            {index === 0 ? "Recent power outages raise alarms over cyber threats to European infrastructure as officials probe possible digital sabotage" :
                             index === 1 ? "How semiconductor technology has become the new battleground for global supremacy and economic control" :
                             index === 2 ? "Federal investigation into university governance practices sparks debate over academic freedom and institutional autonomy" :
                             index === 3 ? "Internal corruption scandal rocks correctional facility as investigation reveals security breaches and staff misconduct" :
                             index === 4 ? "Exploring how traditional art spaces continue to provide unique value in our increasingly digital world" :
                             index === 5 ? "Cross-border military operation targets terrorist infrastructure in response to recent security threats" :
                             index === 6 ? "Political tensions escalate as international criticism mounts over domestic security classifications" :
                             "Middle East conflict intensifies with targeted strikes on government facilities amid regional unrest"}
                          </p>
                          <div className="flex items-center text-sm text-red-600 font-semibold">
                            <span>READ MORE</span>
                          </div>
                        </div>
                      </div>
                    </article>
                  </Link>
                )) : (
                  <>
                    <article className="bg-white dark:bg-gray-700 rounded-lg shadow-sm overflow-hidden group border dark:border-gray-600 mb-8">
                      <div className="flex flex-col md:flex-row">
                        <div className="md:w-1/3">
                          <Image
                            src="https://images.pexels.com/photos/163064/play-stone-network-networked-interactive-163064.jpeg"
                            alt="Latest Topic"
                            width={300}
                            height={200}
                            className="w-full h-48 md:h-full object-cover group-hover:scale-105 transition-transform duration-300"
                          />
                        </div>
                        <div className="md:w-2/3 p-6">
                          <h3 className="text-xl font-bold text-foreground mb-3 group-hover:text-red-600 transition-colors">
                            Spain and Portugal blackouts spark cyberattack concerns across Europe
                          </h3>
                          <p className="text-gray-600 dark:text-gray-300 mb-4">
                            Recent power outages raise alarms over cyber threats to European infrastructure as officials probe possible digital sabotage
                          </p>
                          <div className="flex items-center text-sm text-red-600 font-semibold">
                            <span>READ MORE</span>
                          </div>
                        </div>
                      </div>
                    </article>
                    <article className="bg-white dark:bg-gray-700 rounded-lg shadow-sm overflow-hidden group border dark:border-gray-600">
                      <div className="flex flex-col md:flex-row">
                        <div className="md:w-1/3">
                          <Image
                            src="https://images.pexels.com/photos/163064/play-stone-network-networked-interactive-163064.jpeg"
                            alt="Latest Topic"
                            width={300}
                            height={200}
                            className="w-full h-48 md:h-full object-cover group-hover:scale-105 transition-transform duration-300"
                          />
                        </div>
                        <div className="md:w-2/3 p-6">
                          <h3 className="text-xl font-bold text-foreground mb-3 group-hover:text-red-600 transition-colors">
                            Microchips and Global Power: The New Geopolitical Battlefield
                          </h3>
                          <p className="text-gray-600 dark:text-gray-300 mb-4">
                            How semiconductor technology has become the new battleground for global supremacy and economic control
                          </p>
                          <div className="flex items-center text-sm text-red-600 font-semibold">
                            <span>READ MORE</span>
                          </div>
                        </div>
                      </div>
                    </article>
                  </>
                )}
              </div>
            </div>

            {/* Popular Now Sidebar */}
            <div className="lg:col-span-1">
              <h2 className="text-xl font-bold text-foreground mb-6 uppercase">POPULAR NOW</h2>
              <div>
                <article className="group cursor-pointer mb-8">
                  <div className="flex items-start space-x-3">
                    <span className="text-2xl font-bold text-red-600 flex-shrink-0">1</span>
                    <div className="flex-1">
                      <h3 className="text-sm font-semibold text-foreground line-clamp-2 group-hover:text-red-600 transition-colors">
                        New 3D Titanic simulation confirms century-old eyewitness accounts
                      </h3>
                      <p className="text-xs text-muted-foreground mt-1">New Right Now 332</p>
                    </div>
                  </div>
                </article>
                <article className="group cursor-pointer mb-8">
                  <div className="flex items-start space-x-3">
                    <span className="text-2xl font-bold text-red-600 flex-shrink-0">2</span>
                    <div className="flex-1">
                      <h3 className="text-sm font-semibold text-foreground line-clamp-2 group-hover:text-red-600 transition-colors">
                        NVIDIA SOARS: Blackwell Demand Significantly Outstrips Supply, CEO Says
                      </h3>
                      <p className="text-xs text-muted-foreground mt-1">New Right Now 332</p>
                    </div>
                  </div>
                </article>
                <article className="group cursor-pointer">
                  <div className="flex items-start space-x-3">
                    <span className="text-2xl font-bold text-red-600 flex-shrink-0">3</span>
                    <div className="flex-1">
                      <h3 className="text-sm font-semibold text-foreground line-clamp-2 group-hover:text-red-600 transition-colors">
                        Over 140 Chinese Firms Blacklisted by US Over Uyghur Forced Labor
                      </h3>
                      <p className="text-xs text-muted-foreground mt-1">New Right Now 332</p>
                    </div>
                  </div>
                </article>
              </div>

              {/* Follow @NEWS Section */}
              <div className="mt-8 bg-gray-100 dark:bg-gray-800 p-4 rounded-lg">
                <h3 className="text-lg font-bold text-foreground mb-4 uppercase">FOLLOW @NEWS</h3>
                <div className="mb-4">
                  <input
                    type="email"
                    placeholder="Your email"
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md text-sm focus:outline-none focus:ring-2 focus:ring-red-500 bg-white dark:bg-gray-700 text-black dark:text-white"
                  />
                </div>
                <button className="w-full bg-red-600 text-white py-2 px-4 rounded-md font-semibold hover:bg-red-700 transition-colors">
                  Sign up
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}























