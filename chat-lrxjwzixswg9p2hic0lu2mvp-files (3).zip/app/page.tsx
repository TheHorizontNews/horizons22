import { preloadQuery } from "convex/nextjs";
import { api } from "@/convex/_generated/api";
import HomePageContent from "@/components/home-page-content";
import type { Metadata } from "next";
import siteMetadata from "@/app/metadata.json";

export const metadata: Metadata = siteMetadata["/"];

export default async function HomePage() {
  // Use the new combined query instead of separate queries for better performance
  const preloadedData = await preloadQuery(api.articles.getHomepageData, { limit: 15 });

  return (
    <HomePageContent 
      preloadedData={preloadedData}
    />
  );
}

