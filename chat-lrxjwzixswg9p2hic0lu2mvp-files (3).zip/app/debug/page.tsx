import type { Metadata } from 'next';
import { DebugArticle } from '@/components/debug-article';

export const metadata: Metadata = {
  title: 'Debug Article - The Horizons Times',
  description: 'Debug article data',
};

export default function DebugPage() {
  return <DebugArticle slug="first-step" />;
}