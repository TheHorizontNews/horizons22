import type { Metadata } from 'next';
import siteMetadata from '@/app/metadata.json';
import { preloadQuery } from "convex/nextjs";
import { api } from "@/convex/_generated/api";
import PoliticsPageContent from '@/components/politics-page-content';

export const metadata: Metadata = siteMetadata['/politics'];

// Enable ISR with 60 second revalidation for better performance
export const revalidate = 60;

export default async function PoliticsPage() {
  // Use the new combined query for better performance
  const preloadedData = await preloadQuery(api.articles.getCategoryPageData, { 
    categorySlug: 'politics', 
    limit: 20 
  });

  return (
    <PoliticsPageContent 
      preloadedData={preloadedData}
    />
  );
}




