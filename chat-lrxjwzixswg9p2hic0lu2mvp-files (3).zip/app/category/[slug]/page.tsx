import type { Metadata } from 'next';
import { preloadQuery } from "convex/nextjs";
import { api } from "@/convex/_generated/api";
import CategoryPageContent from '@/components/category-page-content';

interface CategoryPageProps {
  params: Promise<{ slug: string }>;
}

export async function generateMetadata({ params }: CategoryPageProps): Promise<Metadata> {
  const { slug } = await params;
  
  const categoryName = slug.charAt(0).toUpperCase() + slug.slice(1);
  
  return {
    title: `${categoryName} News | Horizons Times`,
    description: `Latest ${categoryName.toLowerCase()} news and articles from Horizons Times. Stay updated with breaking news and in-depth analysis.`,
    openGraph: {
      title: `${categoryName} News | Horizons Times`,
      description: `Latest ${categoryName.toLowerCase()} news and articles from Horizons Times.`,
      type: 'website',
    },
  };
}

export default async function CategoryPage({ params }: CategoryPageProps) {
  const { slug } = await params;
  
  // Get all categories to find the matching one
  const preloadedCategories = await preloadQuery(api.categories.getAllCategories, {});
  const preloadedArticles = await preloadQuery(api.articles.getArticlesByCategorySlug, { categorySlug: slug });

  return (
    <CategoryPageContent 
      categorySlug={slug}
      preloadedCategories={preloadedCategories}
      preloadedArticles={preloadedArticles}
    />
  );
}
