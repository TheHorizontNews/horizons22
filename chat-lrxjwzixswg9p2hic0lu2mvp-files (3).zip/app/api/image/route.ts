import { NextRequest, NextResponse } from 'next/server';

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const id = searchParams.get('id');
  
  if (!id) {
    return new NextResponse('Missing id parameter', { status: 400 });
  }

  // Optional width and quality params for future optimization
  const width = searchParams.get('w');
  const quality = searchParams.get('q');

  try {
    // Call Convex HTTP route to get signed URL
    const convexBase = process.env.NEXT_PUBLIC_CONVEX_URL?.replace('/api', '');
    if (!convexBase) {
      console.error('NEXT_PUBLIC_CONVEX_URL not configured');
      return new NextResponse('Configuration error', { status: 500 });
    }

    const signedUrlResp = await fetch(`${convexBase}/signed-url?id=${encodeURIComponent(id)}`, {
      headers: { 
        'x-image-proxy-secret': process.env.IMAGE_PROXY_SECRET || '' 
      },
    });

    if (!signedUrlResp.ok) {
      console.error('Failed to get signed URL:', signedUrlResp.status, signedUrlResp.statusText);
      return new NextResponse('File not found', { status: 404 });
    }

    const { url: signedUrl } = await signedUrlResp.json();

    // Fetch the image from Convex storage via the signed URL
    const upstream = await fetch(signedUrl);
    if (!upstream.ok) {
      console.error('Failed to fetch from upstream:', upstream.status, upstream.statusText);
      return new NextResponse('Upstream error', { status: 502 });
    }

    // Get the image data
    const imageBuffer = await upstream.arrayBuffer();
    const contentType = upstream.headers.get('content-type') || 'application/octet-stream';

    // Return with aggressive caching headers for CDN optimization
    return new NextResponse(imageBuffer, {
      status: 200,
      headers: {
        'Content-Type': contentType,
        'Cache-Control': 'public, max-age=31536000, immutable',
        'ETag': `"${id}"`,
        'Content-Length': imageBuffer.byteLength.toString(),
      },
    });

  } catch (error) {
    console.error('Image proxy error:', error);
    return new NextResponse('Internal server error', { status: 500 });
  }
}