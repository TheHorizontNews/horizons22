import type { Metadata } from 'next';
import siteMetadata from '@/app/metadata.json';
import { preloadQuery } from "convex/nextjs";
import { api } from "@/convex/_generated/api";
import TechPageContent from '@/components/tech-page-content';

export const metadata: Metadata = siteMetadata['/tech'];

// Enable ISR with 60 second revalidation for better performance
export const revalidate = 60;

export default async function TechPage() {
  // Use the new combined query for better performance
  const preloadedData = await preloadQuery(api.articles.getCategoryPageData, { 
    categorySlug: 'tech', 
    limit: 20 
  });

  return (
    <TechPageContent 
      preloadedData={preloadedData}
    />
  );
}


