import type { Metadata } from 'next';
import siteMetadata from '@/app/metadata.json';
import { preloadQuery } from "convex/nextjs";
import { api } from "@/convex/_generated/api";
import SportsPageContent from '@/components/sports-page-content';

export const metadata: Metadata = siteMetadata['/sports'];

export default async function SportsPage() {
  const preloadedArticles = await preloadQuery(api.articles.getRecentArticles, { limit: 50 });
  const preloadedCategories = await preloadQuery(api.categories.getAllCategories, {});

  return (
    <SportsPageContent 
      preloadedArticles={preloadedArticles}
      preloadedCategories={preloadedCategories}
    />
  );
}
