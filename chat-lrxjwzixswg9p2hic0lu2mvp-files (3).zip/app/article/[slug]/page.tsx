
import type { Metadata } from 'next';
import { preloadQuery } from "convex/nextjs";
import { api } from "@/convex/_generated/api";
import ArticlePageContent from '@/components/article-page-content';

interface ArticlePageProps {
  params: Promise<{ slug: string }>;
}

export async function generateMetadata({ params }: ArticlePageProps): Promise<Metadata> {
  const { slug } = await params;
  
  try {
    const preloadedData = await preloadQuery(api.articles.getArticleWithExtras, { slug });
    
    // For metadata generation, we need to execute the query directly
    const data = JSON.parse(preloadedData._valueJSON || 'null');
    const article = data?.article;
    
    if (!article) {
      return {
        title: 'Article Not Found | Horizons Times',
        description: 'The requested article could not be found.',
      };
    }

    return {
      title: `${article.title} | Horizons Times`,
      description: article.summary || article.content?.substring(0, 160) + '...',
      openGraph: {
        title: article.title,
        description: article.summary || article.content?.substring(0, 160) + '...',
        images: article.featuredImageStorageId ? [`/api/storage/${article.featuredImageStorageId}`] : [],
        type: 'article',
        publishedTime: new Date(article.publicationDate).toISOString(),
        authors: [article.authorId || 'Horizons Times'],
      },
      twitter: {
        card: 'summary_large_image',
        title: article.title,
        description: article.summary || article.content?.substring(0, 160) + '...',
        images: article.featuredImageStorageId ? [`/api/storage/${article.featuredImageStorageId}`] : [],
      },
    };
  } catch (error) {
    return {
      title: 'Article Not Found | Horizons Times',
      description: 'The requested article could not be found.',
    };
  }
}

export default async function ArticlePage({ params }: ArticlePageProps) {
  const { slug } = await params;
  
  const preloadedData = await preloadQuery(api.articles.getArticleWithExtras, { slug });

  return (
    <ArticlePageContent 
      preloadedData={preloadedData}
    />
  );
}

// Add ISR for better performance
export const revalidate = 60;



