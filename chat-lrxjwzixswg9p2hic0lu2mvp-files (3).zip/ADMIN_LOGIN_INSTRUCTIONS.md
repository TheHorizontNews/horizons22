# Admin Panel Login Instructions

## 🔐 How to Access the Admin Panel

### Step 1: Navigate to Admin Panel
Go to: `/admin`

### Step 2: Authentication Process
The admin panel uses **OTP (One-Time Password)** authentication via email, not a traditional password.

1. **Enter your email**: `vovchok967@gmail.com`
2. **Check your email** for a 6-digit verification code
3. **Enter the code** to access the admin panel

### Step 3: If Loading Issues Occur
If the admin panel shows "Loading..." for more than 5 seconds:
1. **Refresh the page** (F5 or Ctrl+R)
2. **Clear browser cache** if needed
3. **Try in incognito/private mode**

### Step 4: Admin Features Available
Once logged in, you can:
- ✅ **Create & Edit Articles** with rich text editor
- ✅ **Upload Images** with automatic CDN optimization
- ✅ **Select Authors** from dropdown
- ✅ **Manage Categories** (Politics, Finance, Sports, Tech)
- ✅ **SEO Settings** for each article
- ✅ **Featured Article Management**

### Troubleshooting
- **Stuck on loading?** → Refresh the page
- **No email received?** → Check spam folder
- **Code expired?** → Request a new code
- **Access denied?** → Ensure you're using `vovchok967@gmail.com`

### 🚀 Quick Start
1. Go to `/admin`
2. Enter: `vovchok967@gmail.com`
3. Check email for code
4. Start creating articles!

The admin panel is fully functional with professional image handling and rich text editing capabilities.