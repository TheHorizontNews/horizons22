import { mutation, query } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";

// Generate upload URL - this is the first step
export const generateUploadUrl = mutation({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Must be authenticated to upload files");
    }
    return await ctx.storage.generateUploadUrl();
  },
});

// Store file metadata after upload
export const saveFileMetadata = mutation({
  args: {
    storageId: v.id("_storage"),
    filename: v.string(),
    contentType: v.string(),
    size: v.number(),
    alt: v.optional(v.string()),
    caption: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Must be authenticated to save file metadata");
    }

    return await ctx.db.insert("media", {
      storageId: args.storageId,
      filename: args.filename,
      contentType: args.contentType,
      size: args.size,
      uploadedAt: Date.now(),
      uploadedBy: userId,
      alt: args.alt,
      caption: args.caption,
    });
  },
});

// Get file URL from storage ID
export const getFileUrl = query({
  args: { storageId: v.id("_storage") },
  handler: async (ctx, args) => {
    return await ctx.storage.getUrl(args.storageId);
  },
});

// Get all media files for admin
export const getAllMedia = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];
    
    const user = await ctx.db.get(userId);
    if (!user || user.role !== "admin") return [];

    const media = await ctx.db.query("media")
      .order("desc")
      .collect();

    // Get URLs for all media files
    const mediaWithUrls = await Promise.all(
      media.map(async (item) => ({
        ...item,
        url: await ctx.storage.getUrl(item.storageId),
      }))
    );

    return mediaWithUrls;
  },
});

// Delete media file
export const deleteMedia = mutation({
  args: { mediaId: v.id("media") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Must be authenticated");
    }
    
    const user = await ctx.db.get(userId);
    if (!user || user.role !== "admin") {
      throw new Error("Must be admin to delete media");
    }

    const media = await ctx.db.get(args.mediaId);
    if (!media) {
      throw new Error("Media not found");
    }

    // Delete from storage
    await ctx.storage.delete(media.storageId);
    
    // Delete from database
    await ctx.db.delete(args.mediaId);
  },
});