import { internalMutation } from "./_generated/server";
import { v } from "convex/values";

export const keepWarm = internalMutation({
  args: {}, // validator required
  handler: async (ctx) => {
    const categories = ["politics", "finance", "tech", "sports"];
    for (const categorySlug of categories) {
      // Very small, fast reads to warm both Convex worker and DB cache
      await ctx.db
        .query("articles")
        .withIndex("by_category")
        .filter((q) => q.eq(q.field("category"), categorySlug))
        .take(1);
    }
    return null;
  },
});
