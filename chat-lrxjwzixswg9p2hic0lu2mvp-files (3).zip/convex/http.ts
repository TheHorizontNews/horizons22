import { httpRouter } from "convex/server"
import { httpAction } from "./_generated/server"
import { auth } from "./auth"

const http = httpRouter()

// Image proxy route for CDN optimization
http.route({
  path: "/signed-url",
  method: "GET",
  handler: httpAction(async (ctx, req) => {
    const secretHeader = req.headers.get("x-image-proxy-secret");
    // Secret is stored in Macaly Settings → Secrets as IMAGE_PROXY_SECRET
    if (secretHeader !== process.env.IMAGE_PROXY_SECRET) {
      return new Response("Unauthorized", { status: 401 });
    }
    
    const url = new URL(req.url);
    const id = url.searchParams.get("id");
    if (!id) return new Response("Missing id", { status: 400 });

    try {
      const signed = await ctx.storage.getUrl(id);
      if (!signed) return new Response("Not found", { status: 404 });

      return new Response(JSON.stringify({ url: signed }), {
        status: 200,
        headers: { "Content-Type": "application/json" },
      });
    } catch (error) {
      console.error("Error getting signed URL:", error);
      return new Response("Internal error", { status: 500 });
    }
  }),
});

auth.addHttpRoutes(http)

export default http

