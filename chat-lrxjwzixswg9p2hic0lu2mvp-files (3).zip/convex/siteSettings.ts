import { mutation, query } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";
import { api } from "./_generated/api";

// Get homepage sections configuration
export const getHomepageSections = query({
  args: {},
  handler: async (ctx) => {
    return await ctx.db.query("homepageSections")
      .filter((q) => q.eq(q.field("isActive"), true))
      .order("asc")
      .collect();
  },
});

// Get all homepage sections for admin
export const getAllHomepageSections = query({
  args: {},
  handler: async (ctx) => {
    const isUserAdmin = await ctx.runQuery(api.authz.isAdmin, {});
    if (!isUserAdmin) return [];

    return await ctx.db.query("homepageSections")
      .order("asc")
      .collect();
  },
});

// Create or update homepage section
export const upsertHomepageSection = mutation({
  args: {
    sectionId: v.optional(v.id("homepageSections")),
    sectionType: v.string(),
    title: v.optional(v.string()),
    articleIds: v.array(v.id("articles")),
    order: v.number(),
    isActive: v.boolean(),
    settings: v.optional(v.object({
      maxArticles: v.optional(v.number()),
      layout: v.optional(v.string()),
      showImages: v.optional(v.boolean()),
    })),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Must be authenticated");
    }
    
    const user = await ctx.db.get(userId);
    if (!user || user.role !== "admin") {
      throw new Error("Must be admin to manage homepage sections");
    }

    if (args.sectionId) {
      // Update existing section
      await ctx.db.patch(args.sectionId, {
        sectionType: args.sectionType,
        title: args.title,
        articleIds: args.articleIds,
        order: args.order,
        isActive: args.isActive,
        settings: args.settings,
      });
      return args.sectionId;
    } else {
      // Create new section
      return await ctx.db.insert("homepageSections", {
        sectionType: args.sectionType,
        title: args.title,
        articleIds: args.articleIds,
        order: args.order,
        isActive: args.isActive,
        settings: args.settings,
      });
    }
  },
});

// Delete homepage section
export const deleteHomepageSection = mutation({
  args: { sectionId: v.id("homepageSections") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Must be authenticated");
    }
    
    const user = await ctx.db.get(userId);
    if (!user || user.role !== "admin") {
      throw new Error("Must be admin to delete homepage sections");
    }

    await ctx.db.delete(args.sectionId);
  },
});

// Get site setting by key
export const getSiteSetting = query({
  args: { key: v.string() },
  handler: async (ctx, args) => {
    const setting = await ctx.db.query("siteSettings")
      .filter((q) => q.eq(q.field("key"), args.key))
      .first();
    
    return setting?.value;
  },
});

// Set site setting
export const setSiteSetting = mutation({
  args: {
    key: v.string(),
    value: v.any(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Must be authenticated");
    }
    
    const user = await ctx.db.get(userId);
    if (!user || user.role !== "admin") {
      throw new Error("Must be admin to change site settings");
    }

    const existing = await ctx.db.query("siteSettings")
      .filter((q) => q.eq(q.field("key"), args.key))
      .first();

    if (existing) {
      await ctx.db.patch(existing._id, {
        value: args.value,
        updatedAt: Date.now(),
        updatedBy: userId,
      });
      return existing._id;
    } else {
      return await ctx.db.insert("siteSettings", {
        key: args.key,
        value: args.value,
        updatedAt: Date.now(),
        updatedBy: userId,
      });
    }
  },
});

// Get featured articles for a specific category
export const getCategoryFeatured = query({
  args: { categorySlug: v.string() },
  handler: async (ctx, args) => {
    const setting = await ctx.db.query("siteSettings")
      .filter((q) => q.eq(q.field("key"), `category_${args.categorySlug}_featured`))
      .first();
    
    if (!setting || !Array.isArray(setting.value)) {
      return [];
    }

    // Get articles by IDs
    const articles = await Promise.all(
      setting.value.map(async (articleId: string) => {
        return await ctx.db.get(articleId as any);
      })
    );

    return articles.filter(Boolean);
  },
});

// Set featured articles for a category
export const setCategoryFeatured = mutation({
  args: {
    categorySlug: v.string(),
    articleIds: v.array(v.id("articles")),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("Must be authenticated");
    }
    
    const user = await ctx.db.get(userId);
    if (!user || user.role !== "admin") {
      throw new Error("Must be admin to set featured articles");
    }

    const key = `category_${args.categorySlug}_featured`;
    
    const existing = await ctx.db.query("siteSettings")
      .filter((q) => q.eq(q.field("key"), key))
      .first();

    if (existing) {
      await ctx.db.patch(existing._id, {
        value: args.articleIds,
        updatedAt: Date.now(),
        updatedBy: userId,
      });
      return existing._id;
    } else {
      return await ctx.db.insert("siteSettings", {
        key,
        value: args.articleIds,
        updatedAt: Date.now(),
        updatedBy: userId,
      });
    }
  },
});