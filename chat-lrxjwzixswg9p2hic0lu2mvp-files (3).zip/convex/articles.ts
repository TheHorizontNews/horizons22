






import { query, mutation } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";
import { v } from "convex/values";
import { Doc, Id } from "./_generated/dataModel";
import { paginationOptsValidator } from "convex/server";
import { api } from "./_generated/api";

/**
 * Paginated list for a category (fast: uses by_category_and_publicationDate index).
 */
export const listArticlesByCategory = query({
  args: {
    categoryId: v.id("categories"),
    paginationOpts: paginationOptsValidator,
  },
  handler: async (ctx, args) => {
    const articles = await ctx.db
      .query("articles")
      .withIndex("by_category_and_publicationDate", (q) =>
        q.eq("category", args.categoryId)
      )
      .order("desc")
      .paginate(args.paginationOpts);
    return articles;
  },
});

/**
 * Get article by slug (unique index by_slug).
 */
export const getArticleBySlug = query({
  args: { slug: v.string() },
  handler: async (ctx, args) => {
    const article = await ctx.db
      .query("articles")
      .withIndex("by_slug", (q) => q.eq("slug", args.slug))
      .unique();
    return article;
  },
});

/**
 * Get article by slug (alias for getArticleBySlug).
 */
export const getBySlug = query({
  args: { slug: v.string() },
  handler: async (ctx, args) => {
    const article = await ctx.db
      .query("articles")
      .withIndex("by_slug", (q) => q.eq("slug", args.slug))
      .unique();
    return article;
  },
});

/**
 * Top featured articles (global). You can add category filtering if needed.
 */
export const getFeaturedArticles = query({
  args: { limit: v.optional(v.number()), categoryId: v.optional(v.id("categories")) },
  handler: async (ctx, args) => {
    let q = ctx.db
      .query("articles")
      .withIndex("by_isFeatured_and_publicationDate", (q) => q.eq("isFeatured", true))
      .order("desc");

    if (args.categoryId) {
      // secondary filter on the small featured set
      q = q.filter((q) => q.eq(q.field("category"), args.categoryId));
    }

    const limit = args.limit ?? 6;
    const results = await q.take(limit);

    // Sort by featuredPosition if provided (lower => higher priority)
    return results.sort((a, b) => {
      const pa = a.featuredPosition ?? Number.MAX_SAFE_INTEGER;
      const pb = b.featuredPosition ?? Number.MAX_SAFE_INTEGER;
      return pa - pb;
    });
  },
});

/**
 * Trending articles: high trendingScore first. Use cron/action to refresh trendingScore periodically.
 */
export const getTrendingArticles = query({
  args: { limit: v.optional(v.number()) },
  handler: async (ctx, args) => {
    const limit = args.limit ?? 10;
    const res = await ctx.db
      .query("articles")
      .withIndex("by_trendingScore", (q) => q.gt("trendingScore", 0))
      .order("desc")
      .take(limit);
    return res;
  },
});

/**
 * Get all articles with pagination
 */
export const getAllArticles = query({
  args: { paginationOpts: paginationOptsValidator },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("articles")
      .order("desc")
      .paginate(args.paginationOpts);
  },
});

/**
 * Get recent articles for homepage - optimized version
 */
export const getRecentArticles = query({
  args: { limit: v.optional(v.number()) },
  handler: async (ctx, args) => {
    const limit = args.limit ?? 10; // Reduced from 20 to 10
    return await ctx.db
      .query("articles")
      .order("desc")
      .take(limit);
  },
});

/**
 * Full text search (server-side). Optional category filter.
 */
export const searchArticles = query({
  args: { queryText: v.string(), categoryId: v.optional(v.id("categories")), limit: v.optional(v.number()) },
  handler: async (ctx, args) => {
    let q = ctx.db
      .query("articles")
      .withSearchIndex("search_articles", (q) => q.search("content", args.queryText));

    if (args.categoryId) {
      q = q.filter((q) => q.eq(q.field("category"), args.categoryId));
    }

    const limit = args.limit ?? 20;
    return await q.take(limit);
  },
});

/**
 * Get recent articles with category information
 */
export const getRecentArticlesWithCategories = query({
  args: { limit: v.optional(v.number()) },
  handler: async (ctx, args) => {
    const limit = args.limit ?? 20;
    const articles = await ctx.db
      .query("articles")
      .order("desc")
      .take(limit);
    
    // Join with categories
    const articlesWithCategories = await Promise.all(
      articles.map(async (article) => {
        const category = await ctx.db.get(article.category);
        return {
          ...article,
          categoryInfo: category
        };
      })
    );
    
    return articlesWithCategories;
  },
});

/**
 * Get articles by category slug
 */
export const getArticlesByCategorySlug = query({
  args: { 
    categorySlug: v.string(),
    limit: v.optional(v.number()) 
  },
  handler: async (ctx, args) => {
    const limit = args.limit ?? 20;
    
    // First find the category by slug
    const category = await ctx.db
      .query("categories")
      .withIndex("by_slug", (q) => q.eq("slug", args.categorySlug))
      .unique();
    
    if (!category) {
      return [];
    }
    
    // Then get articles for this category
    const articles = await ctx.db
      .query("articles")
      .withIndex("by_category_and_publicationDate", (q) =>
        q.eq("category", category._id)
      )
      .order("desc")
      .take(limit);
    
    // Join with category info
    const articlesWithCategories = articles.map(article => ({
      ...article,
      categoryInfo: category
    }));
    
    return articlesWithCategories;
  },
});

// Admin query to get all articles (published and unpublished)
type GetAllForAdminResult =
  | { ok: true; articles: (Doc<"articles"> & { author: { name: string } })[] }
  | { ok: false; code: "FORBIDDEN"; message: string };

export const getAllForAdmin = query({
  args: {},
  handler: async (ctx): Promise<GetAllForAdminResult> => {
    const isUserAdmin: boolean = await ctx.runQuery(api.authz.isAdmin, {});
    
    if (!isUserAdmin) {
      return { ok: false, code: "FORBIDDEN", message: "You must be an admin to view these articles." };
    }

    const articles = await ctx.db.query("articles").order("desc").collect();
    
    // Get author info for each article
    const articlesWithAuthors = await Promise.all(
      articles.map(async (article) => {
        const author = await ctx.db.get(article.authorId);
        return {
          ...article,
          author: author ? { name: author.name || "Anonymous" } : { name: "Anonymous" }
        };
      })
    );
    
    return { ok: true, articles: articlesWithAuthors };
  },
});

// Admin mutation to create a new article
type CreateArticleResult =
  | { ok: true; articleId: string }
  | { ok: false; code: "FORBIDDEN" | "VALIDATION_ERROR"; message: string };

export const create = mutation({
  args: {
    title: v.string(),
    slug: v.string(),
    content: v.string(),
    summary: v.optional(v.string()),
    categoryId: v.id("categories"),
    authorId: v.optional(v.id("users")), // Allow selecting different author
    imageUrl: v.optional(v.string()),
    featuredImageStorageId: v.optional(v.id("_storage")),
    isFeatured: v.optional(v.boolean()),
    featuredPosition: v.optional(v.number()),
    seo: v.optional(v.object({
      title: v.optional(v.string()),
      description: v.optional(v.string()),
      keywords: v.optional(v.array(v.string())),
      canonicalUrl: v.optional(v.string()),
    })),
    tags: v.optional(v.array(v.string()))
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return { ok: false, code: "FORBIDDEN", message: "You must be logged in." };
    }

    // Check if slug already exists
    const existingArticle = await ctx.db
      .query("articles")
      .withIndex("by_slug", (q) => q.eq("slug", args.slug))
      .first();
    
    if (existingArticle) {
      return { ok: false, code: "VALIDATION_ERROR", message: "An article with this slug already exists." };
    }

    const now = Date.now();
    const articleId = await ctx.db.insert("articles", {
      title: args.title,
      slug: args.slug,
      content: args.content,
      summary: args.summary,
      category: args.categoryId,
      authorId: args.authorId || userId, // Use selected author or current user
      publicationDate: now,
      imageUrl: args.imageUrl || "/placeholder-article.jpg",
      featuredImageStorageId: args.featuredImageStorageId,
      isFeatured: args.isFeatured || false,
      featuredPosition: args.featuredPosition,
      seo: args.seo,
      tags: args.tags,
      views: 0,
      trendingScore: 0
    });

    return { ok: true, articleId };
  }
});

// Admin mutation to update an article
type UpdateArticleResult =
  | { ok: true }
  | { ok: false; code: "FORBIDDEN" | "NOT_FOUND" | "VALIDATION_ERROR"; message: string };

export const update = mutation({
  args: {
    id: v.id("articles"),
    title: v.string(),
    slug: v.string(),
    content: v.string(),
    summary: v.optional(v.string()),
    categoryId: v.id("categories"),
    authorId: v.optional(v.id("users")), // Allow changing author
    imageUrl: v.optional(v.string()),
    featuredImageStorageId: v.optional(v.id("_storage")),
    isFeatured: v.optional(v.boolean()),
    featuredPosition: v.optional(v.number()),
    seo: v.optional(v.object({
      title: v.optional(v.string()),
      description: v.optional(v.string()),
      keywords: v.optional(v.array(v.string())),
      canonicalUrl: v.optional(v.string()),
    })),
    tags: v.optional(v.array(v.string()))
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return { ok: false, code: "FORBIDDEN", message: "You must be logged in." };
    }

    const existingArticle = await ctx.db.get(args.id);
    if (!existingArticle) {
      return { ok: false, code: "NOT_FOUND", message: "Article not found." };
    }

    // Check if slug already exists (excluding current article)
    const duplicateSlug = await ctx.db
      .query("articles")
      .withIndex("by_slug", (q) => q.eq("slug", args.slug))
      .first();
    
    if (duplicateSlug && duplicateSlug._id !== args.id) {
      return { ok: false, code: "VALIDATION_ERROR", message: "An article with this slug already exists." };
    }

    await ctx.db.patch(args.id, {
      title: args.title,
      slug: args.slug,
      content: args.content,
      summary: args.summary,
      category: args.categoryId,
      authorId: args.authorId || existingArticle.authorId, // Keep existing author if not specified
      imageUrl: args.imageUrl,
      featuredImageStorageId: args.featuredImageStorageId,
      isFeatured: args.isFeatured,
      featuredPosition: args.featuredPosition,
      seo: args.seo,
      tags: args.tags,
    });

    return { ok: true };
  }
});

// Admin mutation to delete an article
type DeleteArticleResult =
  | { ok: true }
  | { ok: false; code: "FORBIDDEN" | "NOT_FOUND"; message: string };

export const deleteArticle = mutation({
  args: { id: v.id("articles") },
  handler: async (ctx, { id }): Promise<DeleteArticleResult> => {
    const isUserAdmin: boolean = await ctx.runQuery(api.authz.isAdmin, {});
    
    if (!isUserAdmin) {
      return { ok: false, code: "FORBIDDEN", message: "You must be an admin to delete articles." };
    }

    const article = await ctx.db.get(id);
    if (!article) {
      return { ok: false, code: "NOT_FOUND", message: "Article not found." };
    }

    await ctx.db.delete(id);
    return { ok: true };
  },
});

/**
 * Combined query for homepage - gets articles and categories in one call
 */
export const getHomepageData = query({
  args: { limit: v.optional(v.number()) },
  handler: async (ctx, args) => {
    const limit = args.limit ?? 15; // Reduced from 20
    
    // Get articles and categories in parallel
    const [articles, categories] = await Promise.all([
      ctx.db
        .query("articles")
        .order("desc")
        .take(limit),
      ctx.db
        .query("categories")
        .order("asc")
        .collect()
    ]);
    
    return { articles, categories };
  },
});

/**
 * Combined query for category pages - gets articles for specific category and all categories
 */
export const getCategoryPageData = query({
  args: { 
    categorySlug: v.string(),
    limit: v.optional(v.number()) 
  },
  handler: async (ctx, args) => {
    const limit = args.limit ?? 15; // Reduced from 20
    
    // First find the category by slug
    const category = await ctx.db
      .query("categories")
      .withIndex("by_slug", (q) => q.eq("slug", args.categorySlug))
      .unique();
    
    if (!category) {
      // Return empty articles but still return all categories
      const categories = await ctx.db.query("categories").order("asc").collect();
      return { articles: [], categories, category: null };
    }
    
    // Get articles for this category and all categories in parallel
    const [articles, categories] = await Promise.all([
      ctx.db
        .query("articles")
        .withIndex("by_category_and_publicationDate", (q) =>
          q.eq("category", category._id)
        )
        .order("desc")
        .take(limit),
      ctx.db
        .query("categories")
        .order("asc")
        .collect()
    ]);
    
    return { articles, categories, category };
  },
});

/**
 * Optimized query for article pages - gets article, related articles, and navigation in one call
 */
export const getArticleWithExtras = query({
  args: {
    slug: v.string(),
    relatedLimit: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const article = await ctx.db
      .query("articles")
      .withIndex("by_slug", (q) => q.eq("slug", args.slug))
      .unique();

    if (!article) return { article: null, related: [], prev: null, next: null, author: null };

    // Get author information
    const author = article.authorId ? await ctx.db.get(article.authorId) : null;

    const limit = args.relatedLimit ?? 4;

    // Get related articles from same category (more efficient than loading all articles)
    const relatedCandidates = await ctx.db
      .query("articles")
      .withIndex("by_category_and_publicationDate", (q) => 
        q.eq("category", article.category)
      )
      .order("desc")
      .take(limit + 5); // Get a few extra to ensure we have enough after filtering

    const related = relatedCandidates
      .filter((a) => a._id !== article._id)
      .slice(0, limit);

    // For prev/next navigation, get articles around the current one by publication date
    // Get articles published before this one (for prev)
    const prevCandidates = await ctx.db
      .query("articles")
      .withIndex("by_category_and_publicationDate", (q) => 
        q.eq("category", article.category).lt("publicationDate", article.publicationDate)
      )
      .order("desc")
      .take(1);
    
    // Get articles published after this one (for next)
    const nextCandidates = await ctx.db
      .query("articles")
      .withIndex("by_category_and_publicationDate", (q) => 
        q.eq("category", article.category).gt("publicationDate", article.publicationDate)
      )
      .order("asc")
      .take(1);

    const prev = prevCandidates[0] || null;
    const next = nextCandidates[0] || null;

    return { 
      article, 
      related, 
      prev, 
      next, 
      author: author ? {
        name: author.name || author.email || "Anonymous",
        email: author.email
      } : null
    };
  },
});

/**
 * Debug helper: fetch an article by slug, include a resolved storage URL (if any)
 * and the _storage metadata (if any).
 */
export const getArticleForDebug = query({
  args: { slug: v.string() },
  handler: async (ctx, args) => {
    const article = await ctx.db
      .query("articles")
      .withIndex("by_slug", (q) => q.eq("slug", args.slug))
      .unique();

    if (!article) return null;

    // Get featured image storage id
    const featuredStorageId = article.featuredImageStorageId;

    let featuredImageUrl: string | null = null;
    let storageMeta: unknown | null = null;

    if (featuredStorageId) {
      featuredImageUrl = await ctx.storage.getUrl(featuredStorageId);
      storageMeta = await ctx.db.system.get(featuredStorageId);
    }

    return { article, featuredImageUrl, storageMeta };
  },
});

export const findArticlesContaining = query({
  args: { needle: v.string() },
  handler: async (ctx, args) => {
    const all = await ctx.db.query("articles").collect();
    const results = all.filter((a) => {
      const contentHit = typeof a.content === "string" && a.content.includes(args.needle);
      const tagsHit = Array.isArray(a.tags) && a.tags.includes(args.needle);
      return contentHit || tagsHit;
    });
    return results.map((r) => ({ _id: r._id, slug: r.slug, title: r.title }));
  },
});

/**
 * Patch an article: update tags, content, optionally set a new featured image storage id.
 */
export const fixArticle = mutation({
  args: {
    articleId: v.id("articles"),
    newTags: v.array(v.string()),
    newContent: v.string(),
    newStorageId: v.optional(v.id("_storage")),
  },
  handler: async (ctx, args) => {
    const patch: Record<string, unknown> = {
      tags: args.newTags,
      content: args.newContent,
    };
    if (args.newStorageId) {
      patch.featuredImageStorageId = args.newStorageId;
    }
    await ctx.db.patch(args.articleId, patch);
    return null;
  },
});

export const updateArticleData = mutation({
  args: {
    articleId: v.id("articles"),
    categoryId: v.optional(v.id("categories")),
    featuredImageStorageId: v.optional(v.id("_storage")),
    tags: v.optional(v.array(v.string())),
    content: v.optional(v.string()),
    title: v.optional(v.string()),
    summary: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const { articleId, ...updates } = args;
    
    // Remove undefined values
    const cleanUpdates = Object.fromEntries(
      Object.entries(updates).filter(([_, value]) => value !== undefined)
    );
    
    await ctx.db.patch(articleId, cleanUpdates);
    return { success: true };
  },
});












