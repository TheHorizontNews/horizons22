import { cronJobs } from "convex/server";
import { internal } from "./_generated/api";

const crons = cronJobs();

// Run every 5 minutes to keep Convex workers and DB cache warm
crons.interval("keep-warm", { minutes: 5 }, internal.warm.keepWarm, {});

export default crons;