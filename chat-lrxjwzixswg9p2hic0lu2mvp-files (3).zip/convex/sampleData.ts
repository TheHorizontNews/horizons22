

import { mutation } from "./_generated/server";
import { v } from "convex/values";

export const seedDatabase = mutation({
  args: {},
  handler: async (ctx) => {
    // Check if data already exists
    const existingCategories = await ctx.db.query("categories").take(1);
    if (existingCategories.length > 0) {
      return "Database already seeded";
    }

    // Create categories with correct slugs matching the page routes
    const politicsId = await ctx.db.insert("categories", {
      name: "Politics",
      slug: "politics",
      description: "Political news and analysis",
      order: 1,
    });

    const financeId = await ctx.db.insert("categories", {
      name: "Finance",
      slug: "finance",
      description: "Financial news and market updates",
      order: 2,
    });

    const sportsId = await ctx.db.insert("categories", {
      name: "Sports",
      slug: "sports",
      description: "Sports news and updates",
      order: 3,
    });

    const techId = await ctx.db.insert("categories", {
      name: "Tech",
      slug: "tech",
      description: "Technology news and innovations",
      order: 4,
    });

    const gamingId = await ctx.db.insert("categories", {
      name: "Gaming",
      slug: "gaming",
      description: "Gaming news and reviews",
      order: 5,
    });

    const fashionId = await ctx.db.insert("categories", {
      name: "Fashion",
      slug: "fashion",
      description: "Fashion trends and style news",
      order: 6,
    });

    const travelId = await ctx.db.insert("categories", {
      name: "Travel",
      slug: "travel",
      description: "Travel guides and news",
      order: 7,
    });

    const foodId = await ctx.db.insert("categories", {
      name: "Food",
      slug: "food",
      description: "Food news and culinary trends",
      order: 8,
    });

    // Create a sample user (author)
    const authorId = await ctx.db.insert("users", {
      name: "Aleksandr Vovchok",
      email: "vovchok967@gmail.com",
      role: "author",
      bio: "Senior journalist and news editor",
    });

    // Create sample articles
    const now = Date.now();
    const oneDay = 24 * 60 * 60 * 1000;

    // Featured article
    await ctx.db.insert("articles", {
      title: "Microchips and Global Power: The New Geopolitical Battlefield",
      slug: "microchips-global-power-geopolitical-battlefield",
      summary: "How semiconductor technology is reshaping international relations and economic power structures in the 21st century.",
      content: `<p>The global semiconductor industry has become the new battleground for international supremacy, with nations recognizing that control over chip production equals control over the future economy.</p>
      
      <p>From smartphones to military equipment, from cars to artificial intelligence systems, microchips are the invisible foundation of modern civilization. This dependency has transformed semiconductor manufacturing from a purely commercial enterprise into a matter of national security.</p>
      
      <p>The United States and China are locked in an escalating competition for technological dominance, with Europe, Japan, and South Korea playing crucial supporting roles. Trade restrictions, export controls, and massive government investments are reshaping the industry landscape.</p>
      
      <p>As supply chains become increasingly politicized, the question isn't just who makes the best chips, but who controls the technology that powers our digital world.</p>`,
      category: politicsId,
      authorId: authorId,
      publicationDate: now - oneDay * 2,
      isFeatured: true,
      featuredPosition: 1,
      views: 1250,
      trendingScore: 95,
      imageUrl: "/microchips-geopolitics.jpg",
      tags: ["geopolitics", "technology", "semiconductors", "trade-war"],
      seo: {
        title: "Microchips and Global Power: The New Geopolitical Battlefield | The Horizons Times",
        description: "How semiconductor technology is reshaping international relations and economic power structures in the 21st century.",
        keywords: ["microchips", "geopolitics", "semiconductors", "global power", "technology war"],
      },
    });

    // Political articles
    await ctx.db.insert("articles", {
      title: "Germany defends AfD extremist label after U.S. backlash over 'tyranny' claims",
      slug: "germany-defends-afd-extremist-label-us-backlash",
      summary: "German officials stand firm on AfD classification amid international criticism.",
      content: `<p>German authorities have defended their decision to classify the Alternative for Germany (AfD) party as an extremist organization, despite criticism from some U.S. political figures who claim this represents governmental overreach.</p>
      
      <p>The Federal Office for the Protection of the Constitution maintains that the AfD poses a threat to democratic institutions through its rhetoric and policy positions.</p>`,
      category: politicsId,
      authorId: authorId,
      publicationDate: now - oneDay * 1,
      views: 890,
      trendingScore: 78,
      imageUrl: "/government-building.jpg",
      tags: ["germany", "politics", "extremism", "international-relations"],
    });

    await ctx.db.insert("articles", {
      title: "Judge allows DOGE team limited access to sensitive Treasury data",
      slug: "judge-allows-doge-team-treasury-data-access",
      summary: "Federal court ruling grants Department of Government Efficiency restricted access to financial records.",
      content: `<p>A federal judge has ruled that the Department of Government Efficiency (DOGE) team can access certain Treasury Department data, but with significant restrictions to protect sensitive financial information.</p>
      
      <p>The decision comes amid ongoing debates about government transparency and the balance between efficiency initiatives and data security.</p>`,
      category: politicsId,
      authorId: authorId,
      publicationDate: now - oneDay * 3,
      views: 654,
      trendingScore: 65,
      imageUrl: "/politics-meeting.jpg",
      tags: ["doge", "treasury", "government", "transparency"],
    });

    // Sports articles
    await ctx.db.insert("articles", {
      title: "June 2025 Football Transfer Window: Key Dates and Top Moves",
      slug: "june-2025-football-transfer-window-key-dates",
      summary: "Everything you need to know about the upcoming summer transfer window.",
      content: `<p>The June 2025 transfer window promises to be one of the most exciting in recent memory, with several high-profile players expected to move clubs.</p>
      
      <p>Key dates include the window opening on June 1st and closing on August 31st for most European leagues.</p>`,
      category: sportsId,
      authorId: authorId,
      publicationDate: now - oneDay * 2,
      views: 1100,
      trendingScore: 82,
      tags: ["football", "transfers", "summer-window", "2025"],
    });

    await ctx.db.insert("articles", {
      title: "Paul Pogba in Advanced Monaco Talks After Doping Ban",
      slug: "paul-pogba-monaco-talks-doping-ban",
      summary: "French midfielder explores return to football following suspension.",
      content: `<p>Paul Pogba is reportedly in advanced negotiations with AS Monaco regarding a potential move following the conclusion of his doping suspension.</p>
      
      <p>The former Manchester United and Juventus midfielder is eager to return to competitive football.</p>`,
      category: sportsId,
      authorId: authorId,
      publicationDate: now - oneDay * 2,
      views: 756,
      trendingScore: 71,
      tags: ["pogba", "monaco", "doping", "comeback"],
    });

    await ctx.db.insert("articles", {
      title: "Inter Milan's 2025/26 Away Kit Champions Inclusion and Diversity",
      slug: "inter-milan-2025-26-away-kit-champions-inclusion",
      summary: "Inter Milan unveil a white away jersey overlaid with blue X-patterns symbolising unity, debuts at the FIFA Club World Cup in Miami.",
      content: `<p>Inter Milan have unveiled their striking new away kit for the 2025/26 season, featuring a predominantly white design with distinctive blue X-patterns that represent unity and inclusion.</p>
      
      <p>The kit will make its debut at the FIFA Club World Cup in Miami, marking a significant moment for the club's global presence.</p>`,
      category: sportsId,
      authorId: authorId,
      publicationDate: now - oneDay * 2,
      views: 892,
      trendingScore: 75,
      tags: ["inter-milan", "kit", "champions", "diversity"],
    });

    await ctx.db.insert("articles", {
      title: "Thomas Frank's Tottenham Challenge: Winning Trust and Shaping Squad",
      slug: "thomas-frank-tottenham-challenge-winning-trust",
      summary: "Brentford manager Thomas Frank faces the challenge of transforming Tottenham's culture and building a competitive squad.",
      content: `<p>Thomas Frank's potential move to Tottenham represents one of the most intriguing managerial challenges in modern football, as he would need to transform the club's culture while building a competitive squad.</p>
      
      <p>The Danish manager has proven his tactical acumen at Brentford, but Tottenham presents a different scale of challenge entirely.</p>`,
      category: sportsId,
      authorId: authorId,
      publicationDate: now - oneDay * 2,
      views: 1034,
      trendingScore: 78,
      tags: ["thomas-frank", "tottenham", "manager", "challenge"],
    });

    await ctx.db.insert("articles", {
      title: "Assessing the Impact of FIFA's Expanded Club World Cup",
      slug: "fifa-expanded-club-world-cup-impact",
      summary: "Analysis of how FIFA's new 32-team Club World Cup format will reshape international club football.",
      content: `<p>FIFA's expanded Club World Cup represents a seismic shift in international club football, with 32 teams competing in a month-long tournament that promises to rival the World Cup in prestige.</p>
      
      <p>The tournament's impact on domestic leagues, player welfare, and the global football calendar continues to generate debate among stakeholders.</p>`,
      category: sportsId,
      authorId: authorId,
      publicationDate: now - oneDay * 2,
      views: 687,
      trendingScore: 69,
      tags: ["fifa", "club-world-cup", "expansion", "impact"],
    });

    await ctx.db.insert("articles", {
      title: "Verstappen Tops Canadian GP Practice After Leclerc Crash",
      slug: "verstappen-canadian-gp-practice-leclerc-crash",
      summary: "Max Verstappen leads Friday practice sessions as Charles Leclerc suffers setback with practice crash.",
      content: `<p>Max Verstappen dominated Friday practice at the Canadian Grand Prix, setting the fastest lap times while championship rival Charles Leclerc encountered difficulties with a practice session crash.</p>
      
      <p>The incident has raised questions about Ferrari's setup choices for the challenging Montreal circuit.</p>`,
      category: sportsId,
      authorId: authorId,
      publicationDate: now - oneDay * 2,
      views: 923,
      trendingScore: 81,
      tags: ["verstappen", "f1", "canadian-gp", "leclerc"],
    });

    await ctx.db.insert("articles", {
      title: "Hamilton, Russell slam FIA over reversed swearing ban: 'A mess'",
      slug: "hamilton-russell-fia-swearing-ban-mess",
      summary: "Mercedes drivers criticize FIA's handling of swearing regulations in Formula 1.",
      content: `<p>Lewis Hamilton and George Russell have strongly criticized the FIA's approach to regulating driver language, calling the recent policy reversals regarding swearing bans 'a complete mess'.</p>
      
      <p>The controversy highlights ongoing tensions between drivers and Formula 1's governing body over freedom of expression.</p>`,
      category: sportsId,
      authorId: authorId,
      publicationDate: now - oneDay * 3,
      views: 1156,
      trendingScore: 84,
      tags: ["hamilton", "russell", "fia", "swearing-ban"],
    });

    await ctx.db.insert("articles", {
      title: "F1 2025 Season: Full Calendar, Driver Line-Ups, Testing, Rules",
      slug: "f1-2025-season-calendar-drivers-testing-rules",
      summary: "Complete guide to the 2025 Formula 1 season including race calendar, driver changes, and new regulations.",
      content: `<p>The 2025 Formula 1 season promises to be one of the most competitive in recent memory, with significant driver movements, new technical regulations, and an expanded race calendar.</p>
      
      <p>Key changes include new aerodynamic rules designed to improve racing and several high-profile driver transfers that will reshape the competitive landscape.</p>`,
      category: sportsId,
      authorId: authorId,
      publicationDate: now - oneDay * 7,
      views: 1445,
      trendingScore: 89,
      tags: ["f1", "2025-season", "calendar", "drivers"],
    });

    await ctx.db.insert("articles", {
      title: "2025 NBA Playoffs: Key takeaways from Western Conference first round",
      slug: "2025-nba-playoffs-western-conference-first-round",
      summary: "Analysis of the most compelling storylines and performances from the Western Conference playoff opening round.",
      content: `<p>The Western Conference first round delivered spectacular basketball, with several upsets and standout individual performances that have reshaped championship expectations.</p>
      
      <p>From rookie sensations to veteran leadership, the opening round showcased the depth and talent across the conference.</p>`,
      category: sportsId,
      authorId: authorId,
      publicationDate: now - oneDay * 3,
      views: 834,
      trendingScore: 76,
      tags: ["nba", "playoffs", "western-conference", "basketball"],
    });

    await ctx.db.insert("articles", {
      title: "2025 NBA Playoffs: Second-round preview and key questions for each matchup",
      slug: "2025-nba-playoffs-second-round-preview",
      summary: "Breaking down the second round matchups and critical factors that will determine advancement to the conference finals.",
      content: `<p>The NBA playoffs second round features compelling matchups across both conferences, with each series presenting unique tactical challenges and star player battles.</p>
      
      <p>Key questions include injury management, role player contributions, and coaching adjustments that could swing entire series.</p>`,
      category: sportsId,
      authorId: authorId,
      publicationDate: now - oneDay * 3,
      views: 712,
      trendingScore: 73,
      tags: ["nba", "playoffs", "second-round", "preview"],
    });

    await ctx.db.insert("articles", {
      title: "Gregg Popovich steps down as Spurs coach: What's next for San Antonio?",
      slug: "gregg-popovich-steps-down-spurs-coach",
      summary: "The legendary coach's departure marks the end of an era for the San Antonio Spurs franchise.",
      content: `<p>Gregg Popovich's decision to step down as San Antonio Spurs head coach closes one of the most successful chapters in NBA history, leaving the franchise to navigate a new era.</p>
      
      <p>The search for Pop's successor will be crucial in determining the Spurs' direction as they continue rebuilding around young talent.</p>`,
      category: sportsId,
      authorId: authorId,
      publicationDate: now - oneDay * 3,
      views: 1267,
      trendingScore: 87,
      tags: ["popovich", "spurs", "coaching", "nba"],
    });

    await ctx.db.insert("articles", {
      title: "Emma Raducanu picks Mark Petchey as Wimbledon coach, ending Murray hopes",
      slug: "emma-raducanu-mark-petchey-wimbledon-coach",
      summary: "British tennis star Emma Raducanu announces Mark Petchey as her new coach ahead of Wimbledon, ruling out Andy Murray collaboration.",
      content: `<p>Emma Raducanu has appointed Mark Petchey as her new coach ahead of Wimbledon, ending speculation about a potential partnership with recently retired Andy Murray.</p>
      
      <p>The decision represents Raducanu's continued search for stability in her coaching setup as she aims to return to Grand Slam contention.</p>`,
      category: sportsId,
      authorId: authorId,
      publicationDate: now - oneDay * 3,
      views: 945,
      trendingScore: 79,
      tags: ["raducanu", "petchey", "wimbledon", "tennis"],
    });

    await ctx.db.insert("articles", {
      title: "Jack Draper battles back to defeat Moutet in Rome after chaotic start",
      slug: "jack-draper-defeats-moutet-rome-chaotic-start",
      summary: "British tennis player Jack Draper overcomes early difficulties to secure victory at the Italian Open.",
      content: `<p>Jack Draper demonstrated remarkable resilience to overcome a chaotic start against Corentin Moutet at the Italian Open in Rome, eventually securing a hard-fought victory.</p>
      
      <p>The match showcased Draper's mental fortitude and ability to adapt his game under pressure on the clay courts.</p>`,
      category: sportsId,
      authorId: authorId,
      publicationDate: now - oneDay * 4,
      views: 623,
      trendingScore: 68,
      tags: ["draper", "moutet", "rome", "tennis"],
    });

    await ctx.db.insert("articles", {
      title: "2025 SEC Baseball Tournament: Bracket, Schedule, and Championship Predictions",
      slug: "2025-sec-baseball-tournament-bracket-schedule",
      summary: "Complete guide to the SEC Baseball Tournament including bracket breakdown and championship contenders.",
      content: `<p>The 2025 SEC Baseball Tournament promises intense competition as conference rivals battle for the automatic bid to the NCAA Tournament.</p>
      
      <p>With several teams capable of making deep runs, the tournament bracket setup will be crucial in determining the eventual champion.</p>`,
      category: sportsId,
      authorId: authorId,
      publicationDate: now - oneDay * 3,
      views: 567,
      trendingScore: 65,
      tags: ["sec", "baseball", "tournament", "bracket"],
    });

    // Tech articles
    await ctx.db.insert("articles", {
      title: "Microwaves Reveal Real-World 'Imaginary Time' via Frequency Modulation",
      slug: "microwaves-reveal-imaginary-time-frequency-modulation",
      summary: "Scientists discover new quantum phenomena using microwave technology.",
      content: `<p>Researchers have made a breakthrough discovery using microwave frequency modulation to observe quantum mechanical effects previously thought to be purely theoretical.</p>
      
      <p>The concept of 'imaginary time' in quantum mechanics has now been demonstrated in real-world laboratory conditions.</p>`,
      category: techId,
      authorId: authorId,
      publicationDate: now - oneDay * 2,
      views: 432,
      trendingScore: 58,
      tags: ["quantum-physics", "microwaves", "research", "breakthrough"],
    });

    // Finance articles
    await ctx.db.insert("articles", {
      title: "$300 million in Trump meme coins unlock as token drops 90% from peak",
      slug: "trump-meme-coins-unlock-token-drops-90-percent",
      summary: "Cryptocurrency market sees major volatility in political-themed tokens.",
      content: `<p>The cryptocurrency market experienced significant turbulence as $300 million worth of Trump-themed meme coins were unlocked, coinciding with a 90% drop from their peak value.</p>
      
      <p>This event highlights the volatile nature of politically-themed cryptocurrencies and their susceptibility to market manipulation.</p>`,
      category: financeId,
      authorId: authorId,
      publicationDate: now - oneDay * 2,
      views: 987,
      trendingScore: 85,
      tags: ["cryptocurrency", "meme-coins", "trump", "volatility"],
    });

    // Gaming articles
    await ctx.db.insert("articles", {
      title: "The Last of Us Season 2 Steelbook 4K Blu-ray Preorders Now Live",
      slug: "last-of-us-season-2-steelbook-4k-preorders-live",
      summary: "Collectors can now secure their copy of the highly anticipated series.",
      content: `<p>Fans of The Last of Us can now preorder the Season 2 Steelbook 4K Blu-ray edition, featuring exclusive artwork and behind-the-scenes content.</p>
      
      <p>The limited edition release includes director commentary and deleted scenes.</p>`,
      category: gamingId,
      authorId: authorId,
      publicationDate: now - oneDay * 3,
      views: 543,
      trendingScore: 62,
      tags: ["last-of-us", "steelbook", "4k", "preorder"],
    });

    // Travel articles
    await ctx.db.insert("articles", {
      title: "Best Day Trips from Toronto in 2025 – Top 24 Weekend Escapes",
      slug: "best-day-trips-toronto-2025-weekend-escapes",
      summary: "Discover amazing destinations within driving distance of Toronto.",
      content: `<p>Toronto offers incredible access to diverse landscapes and attractions, making it perfect for day trips and weekend getaways.</p>
      
      <p>From Niagara Falls to the Muskoka region, here are the top 24 destinations for your next adventure.</p>`,
      category: travelId,
      authorId: authorId,
      publicationDate: now - oneDay * 3,
      views: 678,
      trendingScore: 69,
      tags: ["toronto", "day-trips", "weekend", "travel-guide"],
    });

    // Fashion articles
    await ctx.db.insert("articles", {
      title: "Milan Fashion Week 2025: Sustainable Fashion Takes Center Stage",
      slug: "milan-fashion-week-2025-sustainable-fashion",
      summary: "Designers showcase eco-friendly collections at this year's fashion week.",
      content: `<p>Milan Fashion Week 2025 has put sustainability at the forefront, with major designers presenting collections made from recycled and eco-friendly materials.</p>
      
      <p>The fashion industry continues to evolve towards more environmentally conscious practices.</p>`,
      category: fashionId,
      authorId: authorId,
      publicationDate: now - oneDay * 1,
      views: 445,
      trendingScore: 67,
      tags: ["milan", "fashion-week", "sustainability", "eco-fashion"],
    });

    // Food articles
    await ctx.db.insert("articles", {
      title: "Plant-Based Meat Alternatives Reach New Heights in 2025",
      slug: "plant-based-meat-alternatives-2025",
      summary: "Innovation in food technology creates more realistic meat substitutes.",
      content: `<p>The plant-based meat industry has achieved remarkable breakthroughs in 2025, with new products that closely mimic the taste and texture of traditional meat.</p>
      
      <p>These innovations are changing how consumers think about sustainable protein sources.</p>`,
      category: foodId,
      authorId: authorId,
      publicationDate: now - oneDay * 2,
      views: 523,
      trendingScore: 64,
      tags: ["plant-based", "meat-alternatives", "food-tech", "sustainability"],
    });

    return "Database seeded successfully with sample data";
  },
});

export const addMoreFinanceArticles = mutation({
  args: {},
  handler: async (ctx) => {
    // Get the finance category
    const financeCategory = await ctx.db
      .query("categories")
      .withIndex("by_slug", (q) => q.eq("slug", "finance"))
      .unique();
    
    if (!financeCategory) {
      return "Finance category not found";
    }

    // Get an author
    const author = await ctx.db.query("users").first();
    if (!author) {
      return "No author found";
    }

    const now = Date.now();
    const oneDay = 24 * 60 * 60 * 1000;

    // Add more finance articles
    const financeArticles = [
      {
        title: "Bitcoin Surges Past $100K as Institutional Adoption Accelerates",
        slug: "bitcoin-surges-100k-institutional-adoption",
        summary: "Major corporations and pension funds drive cryptocurrency to new all-time highs.",
        content: `<p>Bitcoin has reached a historic milestone, surpassing $100,000 for the first time as institutional investors continue to embrace cryptocurrency as a legitimate asset class.</p>
        
        <p>The surge comes amid growing adoption by major corporations and pension funds seeking to diversify their portfolios with digital assets.</p>`,
        category: financeCategory._id,
        authorId: author._id,
        publicationDate: now - oneDay * 1,
        views: 2340,
        trendingScore: 95,
        imageUrl: "/placeholder-article.jpg",
        tags: ["bitcoin", "cryptocurrency", "institutional", "adoption", "100k"],
      },
      {
        title: "Federal Reserve Signals Interest Rate Cuts Amid Economic Slowdown",
        slug: "federal-reserve-interest-rate-cuts-economic-slowdown",
        summary: "Central bank prepares monetary policy shift as inflation shows signs of cooling.",
        content: `<p>The Federal Reserve has signaled potential interest rate cuts in the coming months as economic indicators suggest a slowdown in growth and inflation pressures begin to ease.</p>
        
        <p>The policy shift could have significant implications for borrowing costs and investment strategies across all sectors.</p>`,
        category: financeCategory._id,
        authorId: author._id,
        publicationDate: now - oneDay * 2,
        views: 1890,
        trendingScore: 88,
        imageUrl: "/placeholder-article.jpg",
        tags: ["federal-reserve", "interest-rates", "monetary-policy", "inflation", "economy"],
      },
      {
        title: "Tech Stocks Rally as AI Investment Reaches Record Highs",
        slug: "tech-stocks-rally-ai-investment-record-highs",
        summary: "Artificial intelligence sector attracts unprecedented venture capital funding.",
        content: `<p>Technology stocks are experiencing a significant rally as artificial intelligence companies attract record levels of venture capital investment, with funding reaching unprecedented heights.</p>
        
        <p>Major tech giants are leading the charge with massive AI infrastructure investments that promise to reshape entire industries.</p>`,
        category: financeCategory._id,
        authorId: author._id,
        publicationDate: now - oneDay * 3,
        views: 1650,
        trendingScore: 82,
        imageUrl: "/placeholder-article.jpg",
        tags: ["tech-stocks", "ai", "venture-capital", "investment", "rally"],
      },
      {
        title: "Global Markets React to China Economic Stimulus Package",
        slug: "global-markets-china-economic-stimulus-package",
        summary: "International investors respond to Beijing's latest economic support measures.",
        content: `<p>Global financial markets are reacting positively to China's announcement of a comprehensive economic stimulus package designed to boost domestic consumption and support key industries.</p>
        
        <p>The measures include tax cuts, infrastructure spending, and targeted support for small and medium enterprises.</p>`,
        category: financeCategory._id,
        authorId: author._id,
        publicationDate: now - oneDay * 4,
        views: 1420,
        trendingScore: 79,
        imageUrl: "/placeholder-article.jpg",
        tags: ["china", "stimulus", "global-markets", "economy", "investment"],
      },
      {
        title: "Oil Prices Surge on Middle East Supply Concerns",
        slug: "oil-prices-surge-middle-east-supply-concerns",
        summary: "Energy markets volatile amid geopolitical tensions affecting crude production.",
        content: `<p>Oil prices have surged significantly due to growing concerns about supply disruptions in the Middle East, with geopolitical tensions affecting major crude oil producing regions.</p>
        
        <p>Energy analysts warn that sustained high prices could impact global inflation and economic growth prospects.</p>`,
        category: financeCategory._id,
        authorId: author._id,
        publicationDate: now - oneDay * 5,
        views: 1280,
        trendingScore: 76,
        imageUrl: "/placeholder-article.jpg",
        tags: ["oil-prices", "energy", "middle-east", "supply", "geopolitics"],
      },
      {
        title: "European Central Bank Maintains Hawkish Stance on Inflation",
        slug: "european-central-bank-hawkish-stance-inflation",
        summary: "ECB officials emphasize commitment to price stability despite economic headwinds.",
        content: `<p>The European Central Bank has maintained its hawkish stance on inflation, with officials emphasizing their commitment to achieving price stability despite growing economic headwinds across the eurozone.</p>
        
        <p>The decision reflects ongoing concerns about persistent inflationary pressures in key European economies.</p>`,
        category: financeCategory._id,
        authorId: author._id,
        publicationDate: now - oneDay * 6,
        views: 1150,
        trendingScore: 73,
        imageUrl: "/placeholder-article.jpg",
        tags: ["ecb", "inflation", "monetary-policy", "europe", "interest-rates"],
      },
      {
        title: "Renewable Energy Stocks Soar on Climate Investment Surge",
        slug: "renewable-energy-stocks-soar-climate-investment",
        summary: "Clean energy sector benefits from massive government and private sector funding.",
        content: `<p>Renewable energy stocks are experiencing significant gains as both government initiatives and private sector investments in clean energy technologies reach new heights.</p>
        
        <p>The sector is benefiting from favorable policy environments and growing corporate commitments to carbon neutrality.</p>`,
        category: financeCategory._id,
        authorId: author._id,
        publicationDate: now - oneDay * 7,
        views: 1050,
        trendingScore: 70,
        imageUrl: "/placeholder-article.jpg",
        tags: ["renewable-energy", "climate", "investment", "clean-tech", "stocks"],
      },
      {
        title: "Cryptocurrency Market Cap Exceeds $3 Trillion Milestone",
        slug: "cryptocurrency-market-cap-exceeds-3-trillion",
        summary: "Digital asset market reaches new heights driven by institutional and retail adoption.",
        content: `<p>The total cryptocurrency market capitalization has exceeded $3 trillion for the first time, driven by widespread adoption across both institutional and retail investor segments.</p>
        
        <p>This milestone reflects growing acceptance of digital assets as a legitimate component of diversified investment portfolios.</p>`,
        category: financeCategory._id,
        authorId: author._id,
        publicationDate: now - oneDay * 8,
        views: 1890,
        trendingScore: 85,
        imageUrl: "/placeholder-article.jpg",
        tags: ["cryptocurrency", "market-cap", "3-trillion", "adoption", "milestone"],
      },
      {
        title: "Banking Sector Faces Regulatory Scrutiny Over Digital Assets",
        slug: "banking-sector-regulatory-scrutiny-digital-assets",
        summary: "Financial regulators increase oversight of traditional banks' cryptocurrency activities.",
        content: `<p>Traditional banking institutions are facing increased regulatory scrutiny as they expand their digital asset offerings and cryptocurrency-related services.</p>
        
        <p>Regulators are working to establish clear guidelines while ensuring consumer protection and financial system stability.</p>`,
        category: financeCategory._id,
        authorId: author._id,
        publicationDate: now - oneDay * 9,
        views: 1340,
        trendingScore: 77,
        imageUrl: "/placeholder-article.jpg",
        tags: ["banking", "regulation", "digital-assets", "cryptocurrency", "oversight"],
      },
      {
        title: "Inflation Data Shows Mixed Signals Across Global Economies",
        slug: "inflation-data-mixed-signals-global-economies",
        summary: "Economic indicators reveal varying inflationary pressures in different regions.",
        content: `<p>Recent inflation data from major economies shows mixed signals, with some regions experiencing cooling price pressures while others continue to grapple with persistent inflation.</p>
        
        <p>Central banks are carefully monitoring these trends as they adjust their monetary policy strategies for the coming year.</p>`,
        category: financeCategory._id,
        authorId: author._id,
        publicationDate: now - oneDay * 10,
        views: 1120,
        trendingScore: 74,
        imageUrl: "/placeholder-article.jpg",
        tags: ["inflation", "global-economy", "monetary-policy", "central-banks", "data"],
      }
    ];

    // Insert all articles
    for (const article of financeArticles) {
      await ctx.db.insert("articles", article);
    }

    return `Added ${financeArticles.length} finance articles successfully`;
  },
});

export const addMorePoliticsArticles = mutation({
  args: {},
  handler: async (ctx) => {
    // Find the politics category
    const politicsCategory = await ctx.db
      .query("categories")
      .filter((q) => q.eq(q.field("slug"), "politics"))
      .first();

    if (!politicsCategory) {
      throw new Error("Politics category not found");
    }

    // Get or create a default author
    let authorId = await ctx.db
      .query("users")
      .filter((q) => q.eq(q.field("email"), "author@example.com"))
      .first()
      .then((user) => user?._id);

    if (!authorId) {
      authorId = await ctx.db.insert("users", {
        name: "Political Correspondent",
        email: "author@example.com",
        role: "author",
      });
    }

    const now = Date.now();
    const oneDay = 24 * 60 * 60 * 1000;

    const politicsArticles = [
      {
        title: "Biden Administration Announces New Climate Policy Initiative",
        slug: "biden-climate-policy-initiative-2025",
        summary: "The White House unveils comprehensive climate action plan targeting carbon emissions reduction by 2030.",
        content: `<p>In a landmark announcement, the Biden administration has revealed its most ambitious climate policy initiative to date, setting aggressive targets for carbon emissions reduction and renewable energy adoption.</p>
        
        <p>The comprehensive plan includes federal investments in clean energy infrastructure, new regulations for industrial emissions, and partnerships with state governments to accelerate the transition to sustainable energy sources.</p>`,
        category: politicsCategory._id,
        authorId: authorId,
        publicationDate: now - oneDay * 7,
        views: 1234,
        trendingScore: 85,
        tags: ["climate", "biden", "policy", "environment"],
        isFeatured: true,
      },
      {
        title: "European Parliament Passes Digital Rights Legislation",
        slug: "eu-digital-rights-legislation-2025",
        summary: "New EU regulations aim to protect citizen privacy and regulate big tech companies operating in Europe.",
        content: `<p>The European Parliament has passed groundbreaking digital rights legislation that will reshape how technology companies operate within the European Union, establishing new standards for data protection and algorithmic transparency.</p>
        
        <p>The legislation includes provisions for user consent, data portability, and significant penalties for companies that violate privacy regulations.</p>`,
        category: politicsCategory._id,
        authorId: authorId,
        publicationDate: now - oneDay * 14,
        views: 987,
        trendingScore: 78,
        tags: ["eu", "digital rights", "privacy", "technology"],
      },
      {
        title: "UK Parliament Debates Immigration Reform Bill",
        slug: "uk-immigration-reform-bill-2025",
        summary: "British lawmakers engage in heated debate over proposed changes to immigration policies and border control measures.",
        content: `<p>The House of Commons witnessed intense debates as MPs discussed the controversial immigration reform bill, which proposes significant changes to the UK's approach to border control and asylum processing.</p>
        
        <p>The legislation has drawn criticism from human rights groups while receiving support from those advocating for stricter immigration controls.</p>`,
        category: politicsCategory._id,
        authorId: authorId,
        publicationDate: now - oneDay * 21,
        views: 756,
        trendingScore: 72,
        tags: ["uk", "immigration", "parliament", "reform"],
      },
      {
        title: "Global Summit Addresses Rising Geopolitical Tensions",
        slug: "global-summit-geopolitical-tensions-2025",
        summary: "World leaders gather to discuss diplomatic solutions to escalating international conflicts and trade disputes.",
        content: `<p>Representatives from major world powers convened for an emergency summit to address growing geopolitical tensions, focusing on diplomatic solutions to prevent further escalation of international conflicts.</p>
        
        <p>The summit agenda includes discussions on trade disputes, territorial conflicts, and collaborative approaches to global security challenges.</p>`,
        category: politicsCategory._id,
        authorId: authorId,
        publicationDate: now - oneDay * 28,
        views: 1456,
        trendingScore: 89,
        tags: ["international", "diplomacy", "summit", "geopolitics"],
      },
      {
        title: "Congressional Midterm Elections: Key Races to Watch",
        slug: "congressional-midterm-elections-key-races-2025",
        summary: "Analysis of crucial congressional races that could determine the balance of power in Washington.",
        content: `<p>As midterm elections approach, political analysts are closely watching several key congressional races that could significantly impact the balance of power in both the House and Senate.</p>
        
        <p>These races feature competitive candidates and could determine the legislative agenda for the remainder of the presidential term.</p>`,
        category: politicsCategory._id,
        authorId: authorId,
        publicationDate: now - oneDay * 35,
        views: 1123,
        trendingScore: 81,
        tags: ["elections", "congress", "midterms", "politics"],
      },
      {
        title: "NATO Alliance Strengthens Eastern European Defense",
        slug: "nato-eastern-european-defense-2025",
        summary: "Military alliance announces increased troop deployments and defense spending in response to regional security concerns.",
        content: `<p>NATO has announced a significant expansion of its military presence in Eastern Europe, including increased troop deployments and enhanced defense infrastructure to address regional security concerns.</p>
        
        <p>The decision reflects the alliance's commitment to collective defense and deterrence in the face of evolving security challenges.</p>`,
        category: politicsCategory._id,
        authorId: authorId,
        publicationDate: now - oneDay * 42,
        views: 892,
        trendingScore: 76,
        tags: ["nato", "defense", "military", "security"],
      },
      {
        title: "Supreme Court Ruling Impacts Federal Regulatory Powers",
        slug: "supreme-court-federal-regulatory-powers-2025",
        summary: "Landmark court decision reshapes the scope of federal agency authority in regulatory matters.",
        content: `<p>The Supreme Court has issued a pivotal ruling that significantly impacts how federal agencies can regulate various industries, potentially limiting the scope of administrative authority.</p>
        
        <p>The decision has far-reaching implications for environmental regulations, financial oversight, and other areas of federal governance.</p>`,
        category: politicsCategory._id,
        authorId: authorId,
        publicationDate: now - oneDay * 49,
        views: 1345,
        trendingScore: 83,
        tags: ["supreme court", "regulation", "federal", "law"],
      },
      {
        title: "China-US Trade Relations Show Signs of Improvement",
        slug: "china-us-trade-relations-improvement-2025",
        summary: "Diplomatic efforts yield positive results as both nations work toward resolving long-standing trade disputes.",
        content: `<p>Recent diplomatic meetings between Chinese and American officials have produced encouraging signs of progress in resolving trade disputes that have strained bilateral relations for several years.</p>
        
        <p>Both sides have expressed cautious optimism about reaching agreements on key trade issues while maintaining their respective economic interests.</p>`,
        category: politicsCategory._id,
        authorId: authorId,
        publicationDate: now - oneDay * 56,
        views: 1067,
        trendingScore: 79,
        tags: ["china", "usa", "trade", "diplomacy"],
      },
    ];

    // Insert all politics articles
    for (const article of politicsArticles) {
      await ctx.db.insert("articles", article);
    }

    return { message: `Added ${politicsArticles.length} politics articles` };
  },
});

export const addCryptocurrencyArticles = mutation({
  args: {},
  handler: async (ctx) => {
    // Get the finance category
    const financeCategory = await ctx.db
      .query("categories")
      .withIndex("by_slug", (q) => q.eq("slug", "finance"))
      .unique();
    
    if (!financeCategory) {
      return "Finance category not found";
    }

    // Get an author
    const author = await ctx.db.query("users").first();
    if (!author) {
      return "No author found";
    }

    const now = Date.now();
    const oneDay = 24 * 60 * 60 * 1000;

    const cryptoArticles = [
      {
        title: "Bitcoin Surges Past $45,000 as Institutional Adoption Accelerates",
        slug: "bitcoin-surges-45000-institutional-adoption",
        summary: "Bitcoin has broken through the $45,000 resistance level as major corporations and financial institutions continue to embrace cryptocurrency.",
        content: `<p>Bitcoin has broken through the $45,000 resistance level as major corporations and financial institutions continue to embrace cryptocurrency. The surge comes amid growing acceptance of digital assets in traditional finance.</p>
        
        <p>Major investment firms and corporations are allocating significant portions of their treasuries to Bitcoin, viewing it as a hedge against inflation and currency debasement.</p>`,
        category: financeCategory._id,
        authorId: author._id,
        publicationDate: now - 1000 * 60 * 60 * 6, // 6 hours ago
        views: 2340,
        trendingScore: 92,
        imageUrl: "/crypto-bitcoin-gold.jpg",
        tags: ["cryptocurrency", "bitcoin", "institutional"],
      },
      {
        title: "Ethereum 2.0 Staking Rewards Reach New Highs",
        slug: "ethereum-staking-rewards-new-highs",
        summary: "Ethereum's proof-of-stake network continues to attract validators as staking rewards hit unprecedented levels.",
        content: `<p>Ethereum's proof-of-stake network continues to attract validators as staking rewards hit unprecedented levels. The network's energy efficiency improvements have drawn praise from environmental advocates.</p>
        
        <p>With over 32 million ETH now staked, the network has achieved remarkable security and decentralization milestones.</p>`,
        category: financeCategory._id,
        authorId: author._id,
        publicationDate: now - 1000 * 60 * 60 * 12, // 12 hours ago
        views: 1890,
        trendingScore: 88,
        imageUrl: "/crypto-ethereum.jpg",
        tags: ["cryptocurrency", "ethereum", "staking"],
      },
      {
        title: "Crypto Trading Volume Hits Record $2.3 Trillion Monthly",
        slug: "crypto-trading-volume-record-2-3-trillion",
        summary: "Global cryptocurrency trading volume has reached a new milestone of $2.3 trillion in monthly transactions.",
        content: `<p>Global cryptocurrency trading volume has reached a new milestone of $2.3 trillion in monthly transactions, signaling unprecedented market activity and growing mainstream adoption.</p>
        
        <p>The surge in trading activity spans across all major cryptocurrencies and reflects increased participation from both retail and institutional investors.</p>`,
        category: financeCategory._id,
        authorId: author._id,
        publicationDate: now - 1000 * 60 * 60 * 18, // 18 hours ago
        views: 1650,
        trendingScore: 85,
        imageUrl: "/crypto-phone-trading.jpg",
        tags: ["cryptocurrency", "trading", "volume"],
      },
      {
        title: "Central Bank Digital Currencies Gain Momentum Worldwide",
        slug: "central-bank-digital-currencies-momentum",
        summary: "More than 50 countries are now actively developing or piloting central bank digital currencies (CBDCs).",
        content: `<p>More than 50 countries are now actively developing or piloting central bank digital currencies (CBDCs), marking a significant shift in how governments view digital money and blockchain technology.</p>
        
        <p>The development of CBDCs represents a major evolution in monetary policy and could reshape the global financial system.</p>`,
        category: financeCategory._id,
        authorId: author._id,
        publicationDate: now - 1000 * 60 * 60 * 24, // 1 day ago
        views: 1420,
        trendingScore: 82,
        imageUrl: "/crypto-hand-bitcoin.jpg",
        tags: ["cryptocurrency", "cbdc", "government"],
      },
      {
        title: "DeFi Protocols See $50B in Total Value Locked",
        slug: "defi-protocols-50b-total-value-locked",
        summary: "Decentralized Finance (DeFi) protocols have reached a new milestone with $50 billion in total value locked.",
        content: `<p>Decentralized Finance (DeFi) protocols have reached a new milestone with $50 billion in total value locked, demonstrating the growing trust in decentralized financial services and smart contracts.</p>
        
        <p>The DeFi ecosystem continues to innovate with new lending, borrowing, and yield farming opportunities that challenge traditional financial services.</p>`,
        category: financeCategory._id,
        authorId: author._id,
        publicationDate: now - 1000 * 60 * 60 * 30, // 30 hours ago
        views: 1280,
        trendingScore: 79,
        imageUrl: "/crypto-trading-screen.jpg",
        tags: ["cryptocurrency", "defi", "smart-contracts"],
      }
    ];

    for (const article of cryptoArticles) {
      await ctx.db.insert("articles", article);
    }

    return `Added ${cryptoArticles.length} cryptocurrency articles successfully!`;
  },
});

export const addMoreTechArticles = mutation({
  args: {},
  handler: async (ctx) => {
    // Get the tech category
    const techCategory = await ctx.db
      .query("categories")
      .withIndex("by_slug", (q) => q.eq("slug", "tech"))
      .unique();
    
    if (!techCategory) {
      return "Tech category not found";
    }

    // Get an author
    const author = await ctx.db.query("users").first();
    if (!author) {
      return "No author found";
    }

    const now = Date.now();
    const oneDay = 24 * 60 * 60 * 1000;

    // Add more tech articles
    const techArticles = [
      {
        title: "OpenAI Releases GPT-5 with Revolutionary Capabilities",
        slug: "openai-gpt5-revolutionary-capabilities",
        summary: "The latest iteration of OpenAI's language model demonstrates unprecedented performance in reasoning and code generation.",
        content: `<p>OpenAI has unveiled GPT-5, marking a significant leap forward in artificial intelligence capabilities with revolutionary improvements in reasoning, code generation, and multimodal understanding.</p>
        
        <p>The new model demonstrates enhanced ability to handle complex tasks and shows improved performance across benchmark tests.</p>`,
        category: techCategory._id,
        authorId: author._id,
        publicationDate: now - oneDay * 1,
        views: 2100,
        trendingScore: 92,
        imageUrl: "/placeholder-article.jpg",
        tags: ["ai", "openai", "gpt5", "machine-learning"],
      },
      {
        title: "Apple Unveils Next-Generation M4 Chip Architecture",
        slug: "apple-m4-chip-architecture",
        summary: "Apple's new M4 processor delivers unprecedented performance gains and energy efficiency improvements.",
        content: `<p>Apple has announced its next-generation M4 chip, featuring revolutionary architecture improvements that deliver significant performance gains while maintaining exceptional energy efficiency.</p>
        
        <p>The new chip sets new benchmarks for mobile and desktop computing performance.</p>`,
        category: techCategory._id,
        authorId: author._id,
        publicationDate: now - oneDay * 2,
        views: 1850,
        trendingScore: 88,
        imageUrl: "/placeholder-article.jpg",
        tags: ["apple", "m4", "chip", "hardware"],
      },
      {
        title: "Quantum Computing Breakthrough Promises Faster Processing",
        slug: "quantum-computing-breakthrough-faster-processing",
        summary: "Researchers achieve major milestone in quantum error correction, bringing practical quantum computers closer to reality.",
        content: `<p>Scientists have achieved a major breakthrough in quantum computing, demonstrating significant progress in quantum error correction that brings practical quantum computers closer to reality.</p>
        
        <p>The advancement could accelerate the development of quantum computers capable of solving real-world problems.</p>`,
        category: techCategory._id,
        authorId: author._id,
        publicationDate: now - oneDay * 3,
        views: 1650,
        trendingScore: 85,
        imageUrl: "/placeholder-article.jpg",
        tags: ["quantum-computing", "breakthrough", "research"],
      },
      {
        title: "Next.js 15 Introduces Revolutionary Performance Improvements",
        slug: "nextjs-15-performance-improvements",
        summary: "The latest version of Next.js brings significant performance enhancements and new developer features.",
        content: `<p>Next.js 15 has been released with revolutionary performance improvements that significantly reduce build times and improve runtime performance for web applications.</p>
        
        <p>The new version includes enhanced caching strategies and improved server-side rendering capabilities.</p>`,
        category: techCategory._id,
        authorId: author._id,
        publicationDate: now - oneDay * 4,
        views: 1420,
        trendingScore: 82,
        imageUrl: "/placeholder-article.jpg",
        tags: ["nextjs", "web-development", "performance"],
      },
      {
        title: "GitHub Copilot X Transforms Developer Productivity",
        slug: "github-copilot-x-developer-productivity",
        summary: "GitHub's AI-powered coding assistant reaches new capabilities with Copilot X, revolutionizing software development workflows.",
        content: `<p>GitHub has unveiled Copilot X, an enhanced version of its AI-powered coding assistant that transforms developer productivity through advanced code generation and intelligent suggestions.</p>
        
        <p>The new features enable developers to write code faster and with fewer errors.</p>`,
        category: techCategory._id,
        authorId: author._id,
        publicationDate: now - oneDay * 5,
        views: 1280,
        trendingScore: 79,
        imageUrl: "/placeholder-article.jpg",
        tags: ["github", "ai", "development", "copilot"],
      },
      {
        title: "Cloud-Native Development Patterns Gain Mainstream Adoption",
        slug: "cloud-native-development-patterns-adoption",
        summary: "Enterprises increasingly adopt cloud-native architectures and containerization technologies for scalable applications.",
        content: `<p>Cloud-native development patterns have achieved mainstream adoption across enterprises, with containerization and microservices becoming standard architectural approaches.</p>
        
        <p>Organizations are leveraging these patterns to build more scalable and resilient applications.</p>`,
        category: techCategory._id,
        authorId: author._id,
        publicationDate: now - oneDay * 6,
        views: 1150,
        trendingScore: 76,
        imageUrl: "/placeholder-article.jpg",
        tags: ["cloud", "development", "microservices", "containers"],
      },
      {
        title: "TSMC Announces Breakthrough 2nm Chip Manufacturing Process",
        slug: "tsmc-2nm-chip-manufacturing",
        summary: "Taiwan Semiconductor Manufacturing Company reveals next-generation chip production technology.",
        content: `<p>TSMC has announced a breakthrough in chip manufacturing with its new 2nm process technology, enabling even more powerful and efficient processors.</p>
        
        <p>The advancement represents a significant step forward in semiconductor manufacturing capabilities.</p>`,
        category: techCategory._id,
        authorId: author._id,
        publicationDate: now - oneDay * 7,
        views: 1050,
        trendingScore: 73,
        imageUrl: "/placeholder-article.jpg",
        tags: ["tsmc", "semiconductors", "manufacturing", "2nm"],
      },
      {
        title: "NVIDIA's Next-Gen GPUs Promise 10x AI Performance Boost",
        slug: "nvidia-next-gen-gpu-ai-performance",
        summary: "NVIDIA unveils new GPU architecture designed specifically for artificial intelligence workloads.",
        content: `<p>NVIDIA has revealed its next-generation GPU architecture, promising a 10x performance boost for AI workloads and machine learning applications.</p>
        
        <p>The new GPUs are optimized for training and inference of large language models and other AI applications.</p>`,
        category: techCategory._id,
        authorId: author._id,
        publicationDate: now - oneDay * 8,
        views: 1890,
        trendingScore: 87,
        imageUrl: "/placeholder-article.jpg",
        tags: ["nvidia", "gpu", "ai", "performance"],
      },
      {
        title: "Low-Code Platforms Revolutionize Enterprise Development",
        slug: "low-code-platforms-enterprise-development",
        summary: "Low-code and no-code platforms are transforming how enterprises build and deploy applications.",
        content: `<p>Low-code platforms are revolutionizing enterprise software development by enabling faster application development with reduced coding requirements.</p>
        
        <p>Organizations are leveraging these platforms to accelerate digital transformation initiatives.</p>`,
        category: techCategory._id,
        authorId: author._id,
        publicationDate: now - oneDay * 9,
        views: 1340,
        trendingScore: 77,
        imageUrl: "/placeholder-article.jpg",
        tags: ["low-code", "development", "enterprise", "platforms"],
      },
      {
        title: "Open Source Security Tools Evolve to Meet Enterprise Needs",
        slug: "open-source-security-tools-enterprise",
        summary: "Open source security tools are becoming increasingly sophisticated and enterprise-ready.",
        content: `<p>Open source security tools have evolved significantly to meet the demanding requirements of enterprise environments, offering robust protection and compliance capabilities.</p>
        
        <p>Organizations are increasingly adopting open source security solutions as part of their cybersecurity strategies.</p>`,
        category: techCategory._id,
        authorId: author._id,
        publicationDate: now - oneDay * 10,
        views: 1120,
        trendingScore: 74,
        imageUrl: "/placeholder-article.jpg",
        tags: ["open-source", "security", "enterprise", "tools"],
      }
    ];

    // Insert all articles
    for (const article of techArticles) {
      await ctx.db.insert("articles", article);
    }

    return `Added ${techArticles.length} tech articles successfully`;
  },
});


