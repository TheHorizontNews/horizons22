import { mutation, query } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";
import { api } from "./_generated/api";

// Track article view
export const trackView = mutation({
  args: {
    articleId: v.id("articles"),
    userAgent: v.optional(v.string()),
    referrer: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    // Create analytics event
    await ctx.db.insert("analytics", {
      articleId: args.articleId,
      event: "view",
      timestamp: Date.now(),
      userAgent: args.userAgent,
      referrer: args.referrer,
    });

    // Update article view count
    const article = await ctx.db.get(args.articleId);
    if (article) {
      await ctx.db.patch(args.articleId, {
        views: (article.views || 0) + 1,
        lastViewedAt: Date.now(),
      });
    }
  },
});

// Get analytics dashboard data for admin
export const getDashboardAnalytics = query({
  args: {},
  handler: async (ctx) => {
    const isUserAdmin = await ctx.runQuery(api.authz.isAdmin, {});
    if (!isUserAdmin) {
      return null;
    }

    const now = Date.now();
    const oneDayAgo = now - 24 * 60 * 60 * 1000;
    const oneWeekAgo = now - 7 * 24 * 60 * 60 * 1000;
    const oneMonthAgo = now - 30 * 24 * 60 * 60 * 1000;

    // Total articles
    const totalArticles = await ctx.db.query("articles").collect();
    
    // Total views today
    const viewsToday = await ctx.db.query("analytics")
      .filter((q) => q.and(
        q.eq(q.field("event"), "view"),
        q.gte(q.field("timestamp"), oneDayAgo)
      ))
      .collect();

    // Views this week
    const viewsThisWeek = await ctx.db.query("analytics")
      .filter((q) => q.and(
        q.eq(q.field("event"), "view"),
        q.gte(q.field("timestamp"), oneWeekAgo)
      ))
      .collect();

    // Views this month
    const viewsThisMonth = await ctx.db.query("analytics")
      .filter((q) => q.and(
        q.eq(q.field("event"), "view"),
        q.gte(q.field("timestamp"), oneMonthAgo)
      ))
      .collect();

    // Most viewed articles this week
    const articleViewCounts = new Map<string, number>();
    viewsThisWeek.forEach(view => {
      const count = articleViewCounts.get(view.articleId) || 0;
      articleViewCounts.set(view.articleId, count + 1);
    });

    const topArticleIds = Array.from(articleViewCounts.entries())
      .sort(([,a], [,b]) => b - a)
      .slice(0, 10)
      .map(([id]) => id);

    const topArticles = await Promise.all(
      topArticleIds.map(async (id) => {
        const article = await ctx.db.get(id as any);
        return article ? {
          ...article,
          weeklyViews: articleViewCounts.get(id) || 0
        } : null;
      })
    );

    // Category performance
    const categoryViews = new Map<string, number>();
    for (const view of viewsThisWeek) {
      const article = await ctx.db.get(view.articleId);
      if (article) {
        const category = await ctx.db.get(article.category);
        if (category) {
          const count = categoryViews.get(category.name) || 0;
          categoryViews.set(category.name, count + 1);
        }
      }
    }

    const topCategories = Array.from(categoryViews.entries())
      .sort(([,a], [,b]) => b - a)
      .slice(0, 5)
      .map(([name, views]) => ({ name, views }));

    // Daily views for the last 7 days
    const dailyViews: Array<{ date: string; views: number }> = [];
    for (let i = 6; i >= 0; i--) {
      const dayStart = now - (i + 1) * 24 * 60 * 60 * 1000;
      const dayEnd = now - i * 24 * 60 * 60 * 1000;
      
      const dayViews = await ctx.db.query("analytics")
        .filter((q) => q.and(
          q.eq(q.field("event"), "view"),
          q.gte(q.field("timestamp"), dayStart),
          q.lt(q.field("timestamp"), dayEnd)
        ))
        .collect();

      const date = new Date(dayStart).toLocaleDateString();
      dailyViews.push({
        date,
        views: dayViews.length
      });
    }

    return {
      totalArticles: totalArticles.length,
      totalViews: totalArticles.reduce((sum, article) => sum + (article.views || 0), 0),
      viewsToday: viewsToday.length,
      viewsThisWeek: viewsThisWeek.length,
      viewsThisMonth: viewsThisMonth.length,
      topArticles: topArticles.filter(Boolean),
      topCategories,
      dailyViews,
    };
  },
});

// Get article analytics
export const getArticleAnalytics = query({
  args: { articleId: v.id("articles") },
  handler: async (ctx, args) => {
    const isUserAdmin = await ctx.runQuery(api.authz.isAdmin, {});
    if (!isUserAdmin) {
      return null;
    }

    const now = Date.now();
    const oneWeekAgo = now - 7 * 24 * 60 * 60 * 1000;

    // Get all views for this article
    const views = await ctx.db.query("analytics")
      .filter((q) => q.and(
        q.eq(q.field("articleId"), args.articleId),
        q.eq(q.field("event"), "view")
      ))
      .collect();

    // Views this week
    const viewsThisWeek = views.filter(view => view.timestamp >= oneWeekAgo);

    // Daily breakdown for the last 7 days
    const dailyViews: Array<{ date: string; views: number }> = [];
    for (let i = 6; i >= 0; i--) {
      const dayStart = now - (i + 1) * 24 * 60 * 60 * 1000;
      const dayEnd = now - i * 24 * 60 * 60 * 1000;
      
      const dayViews = views.filter(view => 
        view.timestamp >= dayStart && view.timestamp < dayEnd
      );

      const date = new Date(dayStart).toLocaleDateString();
      dailyViews.push({
        date,
        views: dayViews.length
      });
    }

    // Referrer analysis
    const referrers = new Map<string, number>();
    viewsThisWeek.forEach(view => {
      const referrer = view.referrer || 'Direct';
      const count = referrers.get(referrer) || 0;
      referrers.set(referrer, count + 1);
    });

    const topReferrers = Array.from(referrers.entries())
      .sort(([,a], [,b]) => b - a)
      .slice(0, 5)
      .map(([referrer, views]) => ({ referrer, views }));

    return {
      totalViews: views.length,
      viewsThisWeek: viewsThisWeek.length,
      dailyViews,
      topReferrers,
    };
  },
});

