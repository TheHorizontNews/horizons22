import { query, mutation } from "./_generated/server";
import { v } from "convex/values";
import { getAuthUserId } from "@convex-dev/auth/server";
import { api } from "./_generated/api";

/**
 * Get all categories ordered by their order field
 */
export const getAllCategories = query({
  args: {},
  handler: async (ctx) => {
    const categories = await ctx.db.query("categories").collect();
    return categories.sort((a, b) => (a.order ?? 0) - (b.order ?? 0));
  },
});

/**
 * Backwards-compatible alias for older clients expecting categories.getAll
 */
export const getAll = query({
  args: {},
  handler: async (ctx) => {
    const categories = await ctx.db.query("categories").collect();
    return categories.sort((a, b) => (a.order ?? 0) - (b.order ?? 0));
  },
});

/**
 * Get category by slug
 */
export const getCategoryBySlug = query({
  args: { slug: v.string() },
  handler: async (ctx, args) => {
    return await ctx.db
      .query("categories")
      .withIndex("by_slug", (q) => q.eq("slug", args.slug))
      .unique();
  },
});

/**
 * Create a new category
 */
export const createCategory = mutation({
  args: {
    name: v.string(),
    slug: v.string(),
    description: v.optional(v.string()),
    color: v.optional(v.string()),
    order: v.optional(v.number()),
    isActive: v.optional(v.boolean()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return { ok: false, message: "Must be authenticated" };
    }
    
    const user = await ctx.db.get(userId);
    if (!user || user.role !== "admin") {
      return { ok: false, message: "Must be admin to create categories" };
    }

    try {
      // Check if slug already exists
      const existingCategory = await ctx.db
        .query("categories")
        .withIndex("by_slug", (q) => q.eq("slug", args.slug))
        .unique();
      
      if (existingCategory) {
        return { ok: false, message: "A category with this slug already exists" };
      }

      const categoryId = await ctx.db.insert("categories", {
        name: args.name,
        slug: args.slug,
        description: args.description,
        color: args.color || "#3b82f6",
        order: args.order || 0,
        isActive: args.isActive ?? true,
      });
      
      return { ok: true, message: "Category created successfully", id: categoryId };
    } catch (error) {
      console.error("Error creating category:", error);
      return { ok: false, message: "Failed to create category" };
    }
  },
});

/**
 * Update an existing category
 */
export const updateCategory = mutation({
  args: {
    id: v.id("categories"),
    name: v.optional(v.string()),
    slug: v.optional(v.string()),
    description: v.optional(v.string()),
    color: v.optional(v.string()),
    order: v.optional(v.number()),
    isActive: v.optional(v.boolean()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return { ok: false, message: "Must be authenticated" };
    }
    
    const user = await ctx.db.get(userId);
    if (!user || user.role !== "admin") {
      return { ok: false, message: "Must be admin to update categories" };
    }

    try {
      // Check if category exists
      const existingCategory = await ctx.db.get(args.id);
      if (!existingCategory) {
        return { ok: false, message: "Category not found" };
      }

      // If slug is being updated, check if new slug already exists
      if (args.slug && args.slug !== existingCategory.slug) {
        const slugExists = await ctx.db
          .query("categories")
          .withIndex("by_slug", (q) => q.eq("slug", args.slug!))
          .unique();
        
        if (slugExists) {
          return { ok: false, message: "A category with this slug already exists" };
        }
      }

      const { id, ...updates } = args;
      await ctx.db.patch(id, updates);
      return { ok: true, message: "Category updated successfully" };
    } catch (error) {
      console.error("Error updating category:", error);
      return { ok: false, message: "Failed to update category" };
    }
  },
});

/**
 * Delete a category
 */
export const deleteCategory = mutation({
  args: { id: v.id("categories") },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return { ok: false, message: "Must be authenticated" };
    }
    
    const user = await ctx.db.get(userId);
    if (!user || user.role !== "admin") {
      return { ok: false, message: "Must be admin to delete categories" };
    }

    try {
      // Check if category exists
      const category = await ctx.db.get(args.id);
      if (!category) {
        return { ok: false, message: "Category not found" };
      }

      // Check if category has articles
      const articlesCount = await ctx.db
        .query("articles")
        .withIndex("by_category", (q) => q.eq("category", args.id))
        .collect();

      if (articlesCount.length > 0) {
        return { ok: false, message: "Cannot delete category with existing articles. Please reassign or delete articles first." };
      }

      await ctx.db.delete(args.id);
      return { ok: true, message: "Category deleted successfully" };
    } catch (error) {
      console.error("Error deleting category:", error);
      return { ok: false, message: "Failed to delete category" };
    }
  },
});



