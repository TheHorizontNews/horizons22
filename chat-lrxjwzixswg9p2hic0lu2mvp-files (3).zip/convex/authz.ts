
import { query } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

export const isAdmin = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return false;
    const user = await ctx.db.get(userId);
    
    // Auto-grant admin access to the user's email
    if (user?.email === "vovchok967@gmail.com") { // User's email from user info
      return true;
    }
    
    return !!user && user.role === "admin";
  },
});

export const isAuthenticated = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    return !!userId;
  },
});

/**
 * Helper function to require admin access in mutations
 */
export const requireAdmin = async (ctx: any) => {
  const userId = await getAuthUserId(ctx);
  if (!userId) {
    throw new Error("Authentication required");
  }
  
  const user = await ctx.db.get(userId);
  
  // Auto-grant admin access to the user's email
  if (user?.email === "vovchok967@gmail.com") {
    return user;
  }
  
  if (!user || user.role !== "admin") {
    throw new Error("Admin access required");
  }
  
  return user;
};