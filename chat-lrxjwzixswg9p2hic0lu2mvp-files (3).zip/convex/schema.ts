

import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

export default defineSchema({
  // Auth tables (users, authSessions, etc.)
  ...authTables,

  // Users table (augment auth users with profile fields; use role === "author")
  users: defineTable({
    name: v.optional(v.string()),
    image: v.optional(v.string()),
    bio: v.optional(v.string()),
    email: v.optional(v.string()),
    emailVerificationTime: v.optional(v.number()),
    isAnonymous: v.optional(v.boolean()),
    role: v.optional(v.string()), // e.g., "author", "editor", "admin"
    socialLinks: v.optional(v.record(v.string(), v.string())),
  }).index("email", ["email"]),

  categories: defineTable({
    name: v.string(),
    slug: v.string(), // e.g., "politics", "tech"
    description: v.optional(v.string()),
    order: v.optional(v.number()), // for UI ordering
    color: v.optional(v.string()), // hex color for category styling
    isActive: v.optional(v.boolean()), // whether category is active
  }).index("by_slug", ["slug"]),

  articles: defineTable({
    title: v.string(),
    slug: v.string(), // SEO-friendly unique slug
    summary: v.optional(v.string()),
    content: v.string(), // main HTML or rich text
    category: v.id("categories"),
    authorId: v.id("users"),
    publicationDate: v.number(), // epoch ms (use for sorting & SEO timestamps)
    featuredImageStorageId: v.optional(v.id("_storage")),
    imageUrl: v.optional(v.string()), // Direct image URL for articles

    // Featured support
    isFeatured: v.optional(v.boolean()),
    featuredPosition: v.optional(v.number()), // lower => higher priority
    featuredUntil: v.optional(v.number()), // epoch ms; featured expires automatically

    // Trending / metrics
    views: v.optional(v.number()),
    trendingScore: v.optional(v.number()),
    lastViewedAt: v.optional(v.number()),

    // SEO metadata object
    seo: v.optional(
      v.object({
        title: v.optional(v.string()),
        description: v.optional(v.string()),
        canonicalUrl: v.optional(v.string()),
        keywords: v.optional(v.array(v.string())),
        ogImageStorageId: v.optional(v.id("_storage")),
      })
    ),

    tags: v.optional(v.array(v.string())),
    lang: v.optional(v.string()), // e.g., "en-US"
  })
    .index("by_slug", ["slug"])
    .index("by_category", ["category"]) // Add this index for category queries
    .index("by_category_and_publicationDate", ["category", "publicationDate"])
    .index("by_author", ["authorId"])
    .index("by_isFeatured_and_publicationDate", ["isFeatured", "publicationDate"])
    .index("by_trendingScore", ["trendingScore"])
    .searchIndex("search_articles", {
      searchField: "content",
      filterFields: ["category", "authorId", "tags"],
    }),

  // Media files table for file uploads
  media: defineTable({
    storageId: v.id("_storage"),
    filename: v.string(),
    contentType: v.string(),
    size: v.number(),
    uploadedAt: v.number(),
    uploadedBy: v.id("users"),
    alt: v.optional(v.string()), // Alt text for images
    caption: v.optional(v.string()),
  }).index("by_uploadedBy", ["uploadedBy"]),

  // Analytics table for tracking article views and engagement
  analytics: defineTable({
    articleId: v.id("articles"),
    event: v.string(), // "view", "share", "like", etc.
    timestamp: v.number(),
    userAgent: v.optional(v.string()),
    referrer: v.optional(v.string()),
    ipHash: v.optional(v.string()), // Hashed IP for privacy
  })
    .index("by_article", ["articleId"])
    .index("by_event_and_timestamp", ["event", "timestamp"]),

  // Site settings for homepage and category management
  siteSettings: defineTable({
    key: v.string(), // "homepage_featured", "category_sports_featured", etc.
    value: v.any(), // Flexible value storage
    updatedAt: v.number(),
    updatedBy: v.id("users"),
  }).index("by_key", ["key"]),

  // Homepage sections configuration
  homepageSections: defineTable({
    sectionType: v.string(), // "hero", "featured", "trending", "category"
    title: v.optional(v.string()),
    articleIds: v.array(v.id("articles")),
    order: v.number(),
    isActive: v.boolean(),
    settings: v.optional(v.object({
      maxArticles: v.optional(v.number()),
      layout: v.optional(v.string()), // "grid", "list", "carousel"
      showImages: v.optional(v.boolean()),
    })),
  }).index("by_order", ["order"]),
});
